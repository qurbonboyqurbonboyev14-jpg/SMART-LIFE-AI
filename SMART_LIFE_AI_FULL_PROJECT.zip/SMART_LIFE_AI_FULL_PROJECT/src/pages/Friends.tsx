import { useEffect, useState } from 'react';
import { Check, Copy, MessageCircle, Search, UserMinus, UserPlus, Users, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { useT } from '../lib/i18n';
import { useToast } from '../components/Toast';
import { Avatar, DisplayName, EmptyState, PageHeader } from '../components/ui';
import type { FriendProfile, FriendRequestItem } from '../lib/types';

export default function Friends() {
  const { t } = useT();
  const toast = useToast();
  const me = useAuth((s) => s.user);
  const [code, setCode] = useState('');
  const [result, setResult] = useState<{ user: FriendProfile | null; relation?: string } | null>(null);
  const [friends, setFriends] = useState<FriendProfile[]>([]);
  const [incoming, setIncoming] = useState<FriendRequestItem[]>([]);
  const [outgoing, setOutgoing] = useState<FriendRequestItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState('');

  const load = async () => {
    try {
      const data = await api.friends();
      setFriends(data.friends);
      setIncoming(data.incoming);
      setOutgoing(data.outgoing);
    } catch { /* ignore */ } finally { setLoading(false); }
  };
  useEffect(() => { void load(); }, []);

  const search = async () => {
    const q = code.trim().toUpperCase();
    if (!q) return;
    try {
      const res = await api.searchFriend(q);
      setResult(res);
      if (!res.user) toast({ title: t('friendNotFound'), tone: 'info' });
    } catch (e: any) { toast({ title: e?.message || 'Search failed', tone: 'error' }); }
  };

  const send = async (userCode: string) => {
    setBusy(userCode);
    try {
      const res = await api.sendFriendRequest(userCode);
      toast({ title: res.status === 'friends' ? t('friendNowFriends') : t('friendRequestSent'), tone: 'success' });
      setResult(null); setCode(''); await load();
    } catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); }
    finally { setBusy(''); }
  };

  const respond = async (requestId: string, action: 'accept' | 'reject') => {
    setBusy(requestId);
    try { await api.respondFriendRequest(requestId, action); toast({ title: action==='accept'?t('friendAccepted'):t('friendRejected'), tone: 'success' }); await load(); }
    catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); }
    finally { setBusy(''); }
  };

  const remove = async (friendId: string) => {
    setBusy(friendId);
    try { await api.removeFriend(friendId); toast({ title: t('friendRemoved'), tone: 'info' }); await load(); }
    catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); }
    finally { setBusy(''); }
  };

  const copyId = async () => {
    if (!me?.userCode) return;
    try { await navigator.clipboard.writeText(me.userCode); toast({ title: t('idCopied'), tone: 'success' }); } catch { toast({ title: me.userCode, tone: 'info' }); }
  };

  return (
    <div>
      <PageHeader eyebrow={t('workspace')} title={t('friendsTitle')} subtitle={t('friendsSubtitle')}
        actions={<button type="button" onClick={copyId} className="btn btn-soft"><Copy size={14}/> {t('myId')}: {me?.userCode || '—'}</button>} />

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-4">
          <section className="card card-pad">
            <div className="flex items-center gap-2 mb-3"><Search size={16} className="text-brand"/><h2 className="font-display text-[14px] font-bold">{t('findFriend')}</h2></div>
            <div className="flex gap-2">
              <input className="field" placeholder="SL-123456" value={code} onChange={(e)=>setCode(e.target.value.toUpperCase())} onKeyDown={(e)=>{ if(e.key==='Enter') void search(); }} />
              <button type="button" className="btn btn-primary shrink-0" onClick={()=>void search()}>{t('search')}</button>
            </div>
            <p className="mt-2 text-[10.5px] text-muted">{t('findFriendHint')}</p>
            {result?.user ? (
              <div className="mt-3 flex items-center gap-3 rounded-2xl border border-line/[0.08] bg-line/[0.03] p-3">
                <Avatar emoji={result.user.avatar} size={46} frame={(result.user as any).selectedFrameId || result.user.profileFrame} glowEffect={result.user.glowEffect} borderColor={(result.user as any).borderColor} online={result.user.online} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-semibold"><DisplayName name={result.user.name} isVip={result.user.isVip} isOwner={(result.user as any).isOwner} effect={(result.user as any).selectedNicknameEffect || result.user.usernameEffect} color={(result.user as any).selectedNicknameColor || result.user.usernameColor} /></p>
                  <p className="text-[11px] text-muted">@{result.user.username} · {result.user.userCode}</p>
                </div>
                {result.relation === 'self' ? <span className="chip chip-muted">{t('friendYou')}</span>
                  : result.relation === 'friends' ? <span className="chip chip-success">{t('friendAlready')}</span>
                  : result.relation === 'outgoing' ? <span className="chip chip-brand">{t('friendPending')}</span>
                  : result.relation === 'incoming' ? <span className="chip chip-brand">{t('friendIncoming')}</span>
                  : <button type="button" disabled={busy===result.user.userCode} className="btn btn-primary btn-sm" onClick={()=>void send(result.user!.userCode)}><UserPlus size={13}/> {t('addFriend')}</button>}
              </div>
            ) : null}
          </section>

          <section className="card card-pad">
            <div className="mb-3 flex items-center justify-between"><h2 className="font-display text-[14px] font-bold">{t('friendsList')}</h2><span className="chip chip-muted">{friends.length}</span></div>
            {loading ? <p className="text-[12px] text-muted">{t('loading')}</p> : friends.length === 0 ? <EmptyState icon={Users} title={t('noFriends')} text={t('noFriendsHint')} /> : (
              <div className="space-y-2">
                {friends.map((f) => (
                  <div key={f.id} className="flex items-center gap-3 rounded-2xl border border-line/[0.06] bg-line/[0.02] p-3">
                    <Avatar emoji={f.avatar} size={42} frame={(f as any).selectedFrameId || f.profileFrame} glowEffect={f.glowEffect} borderColor={(f as any).borderColor} online={f.online} />
                    <div className="min-w-0 flex-1"><p className="truncate text-[12.5px] font-semibold"><DisplayName name={f.name} isVip={f.isVip} isOwner={(f as any).isOwner} effect={(f as any).selectedNicknameEffect || f.usernameEffect} color={(f as any).selectedNicknameColor || f.usernameColor} /></p><p className="truncate text-[10.5px] text-muted">@{f.username} · {f.userCode} · {f.online ? <span className="text-emerald-400">Online</span> : 'Offline'}</p></div>
                    <Link to={`/messages?with=${f.id}`} className="icon-btn h-8 w-8 text-violet-300 hover:text-violet-200" title="Message"><MessageCircle size={14}/></Link>
                    <button type="button" disabled={busy===f.id} onClick={()=>void remove(f.id)} className="icon-btn h-8 w-8 text-muted hover:text-rose-400" aria-label={t('removeFriend')} title={t('removeFriend')}><UserMinus size={14}/></button>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <div className="space-y-4">
          <section className="card card-pad">
            <div className="mb-3 flex items-center justify-between"><h2 className="font-display text-[14px] font-bold">{t('friendRequests')}</h2><span className="chip chip-brand">{incoming.length}</span></div>
            {incoming.length === 0 ? <p className="text-[12px] text-muted">{t('noRequests')}</p> : (
              <div className="space-y-2">
                {incoming.map((r) => (
                  <div key={r.requestId} className="rounded-2xl border border-line/[0.06] bg-line/[0.02] p-3">
                    <div className="flex items-center gap-2.5"><Avatar emoji={r.avatar} size={36} frame={(r as any).selectedFrameId || (r as any).profileFrame} glowEffect={(r as any).glowEffect} borderColor={(r as any).borderColor} /><div className="min-w-0 flex-1"><p className="truncate text-[12px] font-semibold"><DisplayName name={r.name} isVip={(r as any).isVip} isOwner={(r as any).isOwner} effect={(r as any).selectedNicknameEffect || (r as any).usernameEffect} color={(r as any).selectedNicknameColor || (r as any).usernameColor} /></p><p className="text-[10px] text-muted">@{r.username} · {r.userCode}</p></div></div>
                    <div className="mt-2 flex gap-2">
                      <button type="button" disabled={busy===r.requestId} onClick={()=>void respond(r.requestId,'accept')} className="btn btn-primary btn-sm flex-1"><Check size={13}/> {t('accept')}</button>
                      <button type="button" disabled={busy===r.requestId} onClick={()=>void respond(r.requestId,'reject')} className="btn btn-soft btn-sm flex-1"><X size={13}/> {t('reject')}</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="card card-pad">
            <div className="mb-3 flex items-center justify-between"><h2 className="font-display text-[14px] font-bold">{t('sentRequests')}</h2><span className="chip chip-muted">{outgoing.length}</span></div>
            {outgoing.length === 0 ? <p className="text-[12px] text-muted">{t('noSentRequests')}</p> : (
              <div className="space-y-2">
                {outgoing.map((r) => (
                  <div key={r.requestId} className="flex items-center gap-2.5 rounded-2xl border border-line/[0.06] bg-line/[0.02] p-2.5">
                    <Avatar emoji={r.avatar} size={34} frame={(r as any).selectedFrameId || (r as any).profileFrame} glowEffect={(r as any).glowEffect} borderColor={(r as any).borderColor} /><div className="min-w-0 flex-1"><p className="truncate text-[11.5px] font-semibold"><DisplayName name={r.name} isVip={(r as any).isVip} isOwner={(r as any).isOwner} effect={(r as any).selectedNicknameEffect || (r as any).usernameEffect} color={(r as any).selectedNicknameColor || (r as any).usernameColor} /></p><p className="text-[10px] text-muted">{r.userCode}</p></div><span className="chip chip-muted">{t('friendPending')}</span>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
