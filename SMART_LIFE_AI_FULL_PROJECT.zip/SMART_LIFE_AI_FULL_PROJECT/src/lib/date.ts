import type { Lang } from './types';

const pad = (n: number) => String(n).padStart(2, '0');

export const toISO = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const todayISO = () => toISO(new Date());
export const parseISO = (iso: string) => {
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};
export const addDaysISO = (iso: string, days: number) => {
  const d = parseISO(iso);
  d.setDate(d.getDate() + days);
  return toISO(d);
};
export const diffDays = (a: string, b: string) =>
  Math.round((parseISO(a).getTime() - parseISO(b).getTime()) / 86400000);

/* ------------------------------------------------------------------ */
/*  Locale names                                                       */
/*  Intl's uz-UZ data renders placeholder months ("M11") in Chromium,   */
/*  so month and weekday names are kept explicitly for all three UI     */
/*  languages. They are also much cheaper than constructing formatters. */
/* ------------------------------------------------------------------ */
const MONTHS: Record<Lang, string[]> = {
  uz: ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'],
  ru: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
};

const MONTHS_GENITIVE: Record<Lang, string[]> = {
  uz: MONTHS.uz,
  ru: ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'],
  en: MONTHS.en,
};

const MONTHS_SHORT: Record<Lang, string[]> = {
  uz: ['yan', 'fev', 'mar', 'apr', 'may', 'iyun', 'iyul', 'avg', 'sen', 'okt', 'noy', 'dek'],
  ru: ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'],
  en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
};

const WEEKDAYS: Record<Lang, string[]> = {
  uz: ['dushanba', 'seshanba', 'chorshanba', 'payshanba', 'juma', 'shanba', 'yakshanba'],
  ru: ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье'],
  en: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
};

const WEEKDAYS_SHORT: Record<Lang, string[]> = {
  uz: ['dsh', 'ses', 'chor', 'pay', 'jum', 'shan', 'yak'],
  ru: ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'],
  en: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
};

const mondayIndex = (d: Date) => (d.getDay() + 6) % 7;

export const monthName = (date: Date, lang: Lang, short = false) =>
  (short ? MONTHS_SHORT[lang] : MONTHS[lang])[date.getMonth()];

export const weekdayName = (date: Date, lang: Lang, short = false) =>
  (short ? WEEKDAYS_SHORT[lang] : WEEKDAYS[lang])[mondayIndex(date)];

/* ------------------------------------------------------------------ */
/*  Formatting                                                         */
/* ------------------------------------------------------------------ */
export const formatDate = (
  iso: string,
  lang: Lang,
  opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long' },
) => {
  const date = parseISO(iso);
  const parts: string[] = [];

  if (opts.weekday) {
    parts.push(weekdayName(date, lang, opts.weekday === 'short'));
  }

  let datePart = '';
  if (opts.day && opts.month) {
    const month =
      opts.month === 'short'
        ? MONTHS_SHORT[lang][date.getMonth()]
        : MONTHS_GENITIVE[lang][date.getMonth()];
    datePart = lang === 'uz' ? `${date.getDate()}-${month}` : `${date.getDate()} ${month}`;
  } else if (opts.day) {
    datePart = String(date.getDate());
  } else if (opts.month) {
    datePart =
      opts.month === 'short'
        ? MONTHS_SHORT[lang][date.getMonth()]
        : MONTHS[lang][date.getMonth()];
  }

  if (datePart) parts.push(datePart);
  if (opts.year) parts.push(String(date.getFullYear()));

  return parts.join(', ');
};

export const formatLongDate = (date: Date, lang: Lang) =>
  formatDate(toISO(date), lang, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

export const formatMonthYear = (date: Date, lang: Lang) =>
  `${MONTHS[lang][date.getMonth()]} ${date.getFullYear()}`;

export const formatClock = (date: Date) => `${pad(date.getHours())}:${pad(date.getMinutes())}`;

export const weekdayLabels = (lang: Lang) => WEEKDAYS_SHORT[lang];

export const relativeDay = (
  iso: string,
  lang: Lang,
  labels: { today: string; tomorrow: string; yesterday: string },
) => {
  const diff = diffDays(iso, todayISO());
  if (diff === 0) return labels.today;
  if (diff === 1) return labels.tomorrow;
  if (diff === -1) return labels.yesterday;
  return formatDate(iso, lang, { day: 'numeric', month: 'short' });
};

export const startOfWeek = (date: Date) => {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const day = d.getDay();
  d.setDate(d.getDate() - ((day + 6) % 7));
  return d;
};

export const monthMatrix = (year: number, month: number) => {
  const first = new Date(year, month, 1);
  const start = startOfWeek(first);
  const weeks: Date[][] = [];
  const cursor = new Date(start);
  for (let w = 0; w < 6; w++) {
    const week: Date[] = [];
    for (let d = 0; d < 7; d++) {
      week.push(new Date(cursor));
      cursor.setDate(cursor.getDate() + 1);
    }
    weeks.push(week);
  }
  return weeks;
};

export const timeToMinutes = (time: string) => {
  const [h, m] = time.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
};

export const minutesToTime = (mins: number) =>
  `${pad(Math.floor(mins / 60) % 24)}:${pad(mins % 60)}`;

export const humanDuration = (mins: number) => {
  if (mins <= 0) return '0';
  if (mins < 60) return `${mins}m`;
  return `${Math.floor(mins / 60)}h${mins % 60 ? ` ${mins % 60}m` : ''}`;
};

export const startOfMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth(), 1);
export const endOfMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth() + 1, 0);

export const greetingKey = (hour = new Date().getHours()) => {
  if (hour < 6) return 'greetNight';
  if (hour < 12) return 'greetMorning';
  if (hour < 18) return 'greetAfternoon';
  return 'greetEvening';
};
