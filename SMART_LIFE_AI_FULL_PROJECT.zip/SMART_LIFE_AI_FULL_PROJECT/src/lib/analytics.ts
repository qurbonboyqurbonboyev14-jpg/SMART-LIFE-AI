import type { Category, EventItem, Goal, Lang, Task } from './types';
import { addDaysISO, diffDays, formatDate, monthName, startOfWeek, toISO, todayISO, weekdayName } from './date';

export const CATEGORY_COLORS: Record<Category, string> = {
  study: '#8b5cf6',
  work: '#4f7cff',
  personal: '#2dd4bf',
  other: '#94a3b8',
};

export const PRIORITY_COLORS = {
  low: '#34d399',
  medium: '#fbbf24',
  high: '#fb7185',
} as const;

export const isOverdue = (task: Task) =>
  !task.completed && diffDays(task.due, todayISO()) < 0;

export const tasksForDay = (tasks: Task[], iso: string) => tasks.filter((t) => t.due === iso);

export const completedOn = (tasks: Task[], iso: string) =>
  tasks.filter((t) => t.completed && t.completedAt?.slice(0, 10) === iso).length;

export const dailyProgress = (tasks: Task[]) => {
  const list = tasksForDay(tasks, todayISO());
  if (!list.length) return { total: 0, done: 0, percent: 0 };
  const done = list.filter((t) => t.completed).length;
  return { total: list.length, done, percent: Math.round((done / list.length) * 100) };
};

export const calculateStreak = (tasks: Task[]) => {
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const iso = addDaysISO(todayISO(), -i);
    const count = completedOn(tasks, iso);
    if (count > 0) {
      streak += 1;
    } else if (i === 0) {
      continue; // today may still be in progress
    } else {
      break;
    }
  }
  return streak;
};

export const weekSeries = (tasks: Task[], lang: Lang, days = 7) =>
  Array.from({ length: days }, (_, i) => {
    const iso = addDaysISO(todayISO(), -(days - 1 - i));
    return {
      iso,
      label: weekdayName(new Date(iso + 'T00:00:00'), lang, true),
      value: completedOn(tasks, iso),
    };
  });

export const monthSeries = (tasks: Task[], lang: Lang, days = 30) =>
  Array.from({ length: days }, (_, i) => {
    const iso = addDaysISO(todayISO(), -(days - 1 - i));
    return {
      iso,
      label: formatDate(iso, lang, { day: 'numeric' }),
      value: completedOn(tasks, iso),
    };
  });

export const yearSeries = (tasks: Task[], lang: Lang) => {
  const now = new Date();
  return Array.from({ length: 12 }, (_, i) => {
    const d = new Date(now.getFullYear(), i, 1);
    const label = monthName(d, lang, true);
    const value = tasks.filter(
      (t) =>
        t.completed &&
        t.completedAt &&
        new Date(t.completedAt).getMonth() === i &&
        new Date(t.completedAt).getFullYear() === now.getFullYear(),
    ).length;
    return { iso: toISO(d), label, value };
  });
};

export const weekCompleted = (tasks: Task[]) => {
  const from = addDaysISO(todayISO(), -6);
  return tasks.filter((t) => t.completed && t.completedAt && t.completedAt.slice(0, 10) >= from)
    .length;
};

export const lastWeekCompleted = (tasks: Task[]) => {
  const from = addDaysISO(todayISO(), -13);
  const to = addDaysISO(todayISO(), -7);
  return tasks.filter(
    (t) => t.completed && t.completedAt && t.completedAt.slice(0, 10) >= from && t.completedAt.slice(0, 10) <= to,
  ).length;
};

export const completionRate = (tasks: Task[], fromIso: string, toIso: string) => {
  const list = tasks.filter((t) => t.due >= fromIso && t.due <= toIso);
  if (!list.length) return 0;
  return Math.round((list.filter((t) => t.completed).length / list.length) * 100);
};

export const averageGoalProgress = (goals: Goal[]) => {
  if (!goals.length) return 0;
  return Math.round(goals.reduce((sum, g) => sum + g.progress, 0) / goals.length);
};

export const productivityScore = (tasks: Task[], goals: Goal[]) => {
  const today = dailyProgress(tasks);
  const days = weekSeries(tasks, 'en');
  const activeDays = days.filter((d) => d.value > 0).length;
  const consistency = (activeDays / 7) * 100;
  const goalScore = averageGoalProgress(goals);
  const todayScore = today.total ? today.percent : Math.min(100, completedOn(tasks, todayISO()) * 20);
  return Math.round(todayScore * 0.5 + goalScore * 0.3 + consistency * 0.2);
};

export const categoryCounts = (tasks: Task[]) => {
  const entries = (['study', 'work', 'personal', 'other'] as Category[]).map((cat) => ({
    key: cat,
    value: tasks.filter((t) => t.category === cat).length,
    color: CATEGORY_COLORS[cat],
  }));
  return entries;
};

export const activeCategoryCounts = (tasks: Task[]) => {
  const entries = (['study', 'work', 'personal', 'other'] as Category[]).map((cat) => ({
    key: cat,
    value: tasks.filter((t) => t.category === cat && t.completed).length,
    color: CATEGORY_COLORS[cat],
  }));
  return entries;
};

export const heatmapSeries = (tasks: Task[], days = 70) => {
  const today = todayISO();
  const start = addDaysISO(today, -(days - 1));
  // align to Monday
  const startDate = new Date(start + 'T00:00:00');
  const offset = (startDate.getDay() + 6) % 7;
  const alignedStart = addDaysISO(start, -offset);
  const totalDays = days + offset;
  return Array.from({ length: totalDays }, (_, i) => {
    const iso = addDaysISO(alignedStart, i);
    return { iso, value: completedOn(tasks, iso), future: iso > today };
  });
};

export const bestProductiveDay = (tasks: Task[], lang: Lang, series: { iso: string; value: number }[]) => {
  const best = series.reduce<{ iso: string; value: number } | null>(
    (acc, cur) => (!acc || cur.value > acc.value ? cur : acc),
    null,
  );
  if (!best || best.value === 0) return null;
  return {
    label: formatDate(best.iso, lang, { weekday: 'long', day: 'numeric', month: 'short' }),
    value: best.value,
  };
};

export const upcomingEvents = (events: EventItem[], limit?: number) => {
  const now = new Date();
  const today = todayISO();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const sorted = [...events]
    .filter((e) => e.date > today || (e.date === today && timeMinutes(e.end) >= currentMinutes))
    .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));
  return limit ? sorted.slice(0, limit) : sorted;
};

const timeMinutes = (time: string) => {
  const [h, m] = time.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
};

export const eventsForDay = (events: EventItem[], iso: string) =>
  events.filter((e) => e.date === iso).sort((a, b) => a.start.localeCompare(b.start));

export const weekdayCompletion = (tasks: Task[]) => {
  const start = startOfWeek(new Date());
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const iso = toISO(d);
    return { iso, value: completedOn(tasks, iso) };
  });
};

export const lastNDates = (n: number) =>
  Array.from({ length: n }, (_, i) => addDaysISO(todayISO(), -(n - 1 - i)));
