import { useEffect, useMemo, useState } from 'react';
import { Eye, EyeOff, Loader2, Lock, Mail, Sparkles, User, UserPlus } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { readAuthLanguage, writeAuthLanguage } from '../lib/storage';
import type { Lang } from '../lib/types';

const copy = {
  uz: {
    welcome: 'Xush kelibsiz',
    subtitle: 'Kirish yoki hisob yarating — shundan so‘ng shaxsiy panelingiz ochiladi.',
    login: 'Kirish',
    register: 'Hisob yaratish',
    identifier: 'Email yoki username',
    password: 'Parol',
    name: 'Ism va familiya',
    firstName: 'Ism',
    lastName: 'Familiya',
    username: 'Username',
    email: 'Email',
    bio: 'Qisqa bio',
    interests: 'Qiziqishlar',
    goals: 'Shaxsiy maqsadlar',
    avatar: 'Profil rasmi (ixtiyoriy)',
    loginBtn: 'Kirish',
    registerBtn: 'Ro‘yxatdan o‘tish',
    google: 'Google orqali davom etish',
    or: 'yoki',
    hint: 'Ma’lumotlaringiz hisobingizga xavfsiz saqlanadi va faqat sizga ko‘rinadi.',
    photoHint: 'Rasmni keyin profil sahifasida ham yuklab, qirqib saqlashingiz mumkin.',
    creating: 'Yaratilmoqda...',
    signing: 'Kirilmoqda...',
  },
  ru: {
    welcome: 'Добро пожаловать',
    subtitle: 'Войдите или создайте аккаунт — после этого откроется ваша личная панель.',
    login: 'Вход',
    register: 'Создать аккаунт',
    identifier: 'Email или username',
    password: 'Пароль',
    name: 'Имя и фамилия',
    firstName: 'Имя',
    lastName: 'Фамилия',
    username: 'Username',
    email: 'Email',
    bio: 'Коротко о себе',
    interests: 'Интересы',
    goals: 'Личные цели',
    avatar: 'Фото профиля (необязательно)',
    loginBtn: 'Войти',
    registerBtn: 'Зарегистрироваться',
    google: 'Продолжить с Google',
    or: 'или',
    hint: 'Ваши данные безопасно сохраняются в аккаунте и видны только вам.',
    photoHint: 'Фото можно загрузить и обрезать позже в профиле.',
    creating: 'Создаём...',
    signing: 'Входим...',
  },
  en: {
    welcome: 'Welcome',
    subtitle: 'Sign in or create an account — your personal dashboard opens right after.',
    login: 'Login',
    register: 'Create account',
    identifier: 'Email or username',
    password: 'Password',
    name: 'Full name',
    firstName: 'First name',
    lastName: 'Last name',
    username: 'Username',
    email: 'Email',
    bio: 'Short bio',
    interests: 'Interests',
    goals: 'Personal goals',
    avatar: 'Profile picture (optional)',
    loginBtn: 'Sign in',
    registerBtn: 'Create account',
    google: 'Continue with Google',
    or: 'or',
    hint: 'Your data is stored securely in your account and is private to you.',
    photoHint: 'You can upload and crop your photo later in Profile.',
    creating: 'Creating...',
    signing: 'Signing in...',
  },
} as const;

declare global {
  interface Window { google?: any; }
}

const GOOGLE_CLIENT_ID = (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID as string | undefined;

export default function AuthPage() {
  const [lang, setLang] = useState<Lang>(() => readAuthLanguage());
  const t = copy[lang];
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [error, setError] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [busyLocal, setBusyLocal] = useState(false);

  const login = useAuth((s) => s.login);
  const loginGoogle = useAuth((s) => s.loginGoogle);
  const register = useAuth((s) => s.register);
  const bootError = useAuth((s) => s.bootError);
  const busy = useAuth((s) => s.busy);

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [bio, setBio] = useState('');
  const [interests, setInterests] = useState('');
  const [rGoals, setRGoals] = useState('');
  const [avatar, setAvatar] = useState('');

  useEffect(() => { writeAuthLanguage(lang); }, [lang]);

  // Load Google Identity Services and render button when configured.
  useEffect(() => {
    if (!GOOGLE_CLIENT_ID) return;
    const id = 'google-gsi';
    if (!document.getElementById(id)) {
      const s = document.createElement('script');
      s.src = 'https://accounts.google.com/gsi/client';
      s.async = true; s.defer = true; s.id = id;
      s.onload = () => renderGoogle();
      document.head.appendChild(s);
    } else {
      renderGoogle();
    }
    function renderGoogle() {
      const el = document.getElementById('google-btn');
      if (!el || !window.google?.accounts?.id) return;
      el.innerHTML = '';
      window.google.accounts.id.initialize({
        client_id: GOOGLE_CLIENT_ID,
        callback: async (resp: any) => {
          if (!resp?.credential) return;
          setError('');
          try { await loginGoogle(resp.credential); } catch (e: any) { setError(e?.message || 'Google sign-in failed'); }
        },
      });
      window.google.accounts.id.renderButton(el, { theme: 'filled_black', size: 'large', shape: 'pill', width: 320, text: 'continue_with' });
    }
  }, [loginGoogle, mode]);

  const onLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try { await login(identifier, password); } catch (e: any) { setError(e?.message || 'Sign in failed'); }
  };

  const onRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const fullName = [firstName.trim(), lastName.trim()].filter(Boolean).join(' ').trim();
    if (!fullName || !username.trim() || !email.trim() || password.length < 8) {
      setError(lang === 'uz' ? 'Iltimos, barcha majburiy maydonlarni to‘g‘ri to‘ldiring (parol kamida 8 ta belgi).' : lang === 'ru' ? 'Заполните все обязательные поля (пароль минимум 8 символов).' : 'Please fill all required fields (password at least 8 characters).');
      return;
    }
    try {
      await register({ name: fullName, firstName: firstName.trim(), lastName: lastName.trim(), username: username.trim(), email: email.trim(), password, bio, interests, goals: rGoals, avatar: avatar || '🦋' }, lang);
    } catch (e: any) { setError(e?.message || 'Registration failed'); }
  };

  const onAvatar = (file?: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAvatar(typeof reader.result === 'string' ? reader.result : '');
    reader.readAsDataURL(file);
  };

  return (
    <div className="auth-screen">
      <div className="app-bg" aria-hidden>
        <span className="orb orb-1" /><span className="orb orb-2" /><span className="orb orb-3" />
      </div>
      <div className="auth-wrap">
        <div className="auth-brand card">
          <span className="logo-mark h-12 w-12"><Sparkles size={22} /></span>
          <h1 className="mt-4 font-display text-3xl font-extrabold leading-tight">SMART LIFE <span className="grad-text">AI</span></h1>
          <p className="mt-2 text-sm text-muted">{t.welcome}</p>
          <p className="mt-1 max-w-sm text-sm leading-relaxed text-muted">{t.subtitle}</p>
          <div className="mt-6 space-y-2 text-[12px] text-muted">
            <p>• Tasks · Calendar · Goals · Notes · AI · Analytics</p>
            <p>• {t.hint}</p>
          </div>
          <div className="mt-6 flex gap-1.5">
            {(['uz','ru','en'] as Lang[]).map((l) => (
              <button key={l} type="button" onClick={() => setLang(l)} className={`chip ${lang===l?'chip-brand':'chip-muted'}`}>{l.toUpperCase()}</button>
            ))}
          </div>
        </div>

        <div className="auth-card card">
          <div className="flex items-center gap-1 rounded-2xl border border-line/[0.08] bg-line/[0.03] p-1">
            <button type="button" onClick={() => { setMode('login'); setError(''); }} className={`btn flex-1 ${mode==='login'?'btn-primary':'btn-ghost'}`}>{t.login}</button>
            <button type="button" onClick={() => { setMode('register'); setError(''); }} className={`btn flex-1 ${mode==='register'?'btn-primary':'btn-ghost'}`}>{t.register}</button>
          </div>

          {(error || bootError) ? <div className="mt-3 rounded-xl border border-rose-400/25 bg-rose-500/10 px-3 py-2 text-[12px] text-rose-300">{error || bootError}</div> : null}

          {mode === 'login' ? (
            <form className="mt-4 space-y-3" onSubmit={onLogin}>
              <label className="block">
                <span className="field-label">{t.identifier}</span>
                <div className="relative"><Mail size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="field pl-9" value={identifier} onChange={(e)=>setIdentifier(e.target.value)} autoComplete="username" required /></div>
              </label>
              <label className="block">
                <span className="field-label">{t.password}</span>
                <div className="relative">
                  <Lock size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
                  <input className="field pl-9 pr-10" type={showPass?'text':'password'} value={password} onChange={(e)=>setPassword(e.target.value)} autoComplete="current-password" required />
                  <button type="button" onClick={()=>setShowPass(v=>!v)} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1 text-muted hover:text-ink">{showPass?<EyeOff size={14}/>:<Eye size={14}/>}</button>
                </div>
              </label>
              <button type="submit" disabled={busy} className="btn btn-primary w-full">{busy?<><Loader2 size={14} className="animate-spin"/> {t.signing}</>:t.loginBtn}</button>
              {GOOGLE_CLIENT_ID ? <><div className="auth-divider"><span>{t.or}</span></div><div id="google-btn" className="flex justify-center min-h-[44px]" /></> : null}
            </form>
          ) : (
            <form className="mt-4 space-y-3" onSubmit={onRegister}>
              <div className="grid grid-cols-2 gap-2.5">
                <label className="block"><span className="field-label">{t.firstName} *</span><input className="field" value={firstName} onChange={(e)=>setFirstName(e.target.value)} required /></label>
                <label className="block"><span className="field-label">{t.lastName}</span><input className="field" value={lastName} onChange={(e)=>setLastName(e.target.value)} /></label>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <label className="block"><span className="field-label">{t.username} *</span><div className="relative"><User size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="field pl-9" value={username} onChange={(e)=>setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g,''))} placeholder="aziza_01" required /></div></label>
                <label className="block"><span className="field-label">{t.email} *</span><input className="field" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required /></label>
              </div>
              <label className="block"><span className="field-label">{t.password} *</span><div className="relative"><Lock size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="field pl-9" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} minLength={8} required /></div></label>
              <label className="block"><span className="field-label">{t.bio}</span><input className="field" value={bio} onChange={(e)=>setBio(e.target.value)} /></label>
              <div className="grid grid-cols-2 gap-2.5">
                <label className="block"><span className="field-label">{t.interests}</span><input className="field" value={interests} onChange={(e)=>setInterests(e.target.value)} /></label>
                <label className="block"><span className="field-label">{t.goals}</span><input className="field" value={rGoals} onChange={(e)=>setRGoals(e.target.value)} /></label>
              </div>
              <label className="block">
                <span className="field-label">{t.avatar}</span>
                <div className="flex items-center gap-3">
                  <span className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-xl border border-line/[0.1] bg-line/[0.03] text-lg">
                    {avatar?.startsWith('data:image') ? <img src={avatar} alt="" className="h-full w-full object-cover" /> : (avatar || '🦋')}
                  </span>
                  <input type="file" accept="image/*" onChange={(e)=>onAvatar(e.target.files?.[0])} className="text-[11px] text-muted file:mr-2 file:rounded-lg file:border-0 file:bg-brand/15 file:px-3 file:py-1.5 file:text-[11px] file:font-semibold file:text-violet-200" />
                </div>
                <p className="mt-1 text-[10px] text-muted">{t.photoHint}</p>
              </label>
              <button type="submit" disabled={busy} className="btn btn-primary w-full">{busy?<><Loader2 size={14} className="animate-spin"/> {t.creating}</>:<><UserPlus size={14}/> {t.registerBtn}</>}</button>
              {GOOGLE_CLIENT_ID ? <><div className="auth-divider"><span>{t.or}</span></div><div id="google-btn" className="flex justify-center min-h-[44px]" /><p className="text-center text-[10px] text-muted">{t.google}</p></> : null}
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
