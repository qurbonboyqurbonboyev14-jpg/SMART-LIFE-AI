import { useEffect, useMemo, useState } from 'react';
import {
  FileText,
  NotebookPen,
  Pencil,
  Pin,
  PinOff,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { useApp, type NewNote } from '../lib/store';
import { useT } from '../lib/i18n';
import { cn } from '../lib/cn';
import { formatDate } from '../lib/date';
import type { Category, Note } from '../lib/types';
import { CATEGORIES } from '../lib/types';
import { CATEGORY_COLORS } from '../lib/analytics';
import {
  CategoryTag,
  ConfirmDialog,
  EmptyState,
  Modal,
  PageHeader,
} from '../components/ui';
import { useToast } from '../components/Toast';

export default function Notes() {
  const { t, lang } = useT();
  const toast = useToast();

  const notes = useApp((s) => s.notes);
  const addNote = useApp((s) => s.addNote);
  const updateNote = useApp((s) => s.updateNote);
  const deleteNote = useApp((s) => s.deleteNote);
  const toggleNotePin = useApp((s) => s.toggleNotePin);

  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<Category | 'all'>('all');
  const [editor, setEditor] = useState<{ mode: 'new' | 'edit'; note?: Note } | null>(null);
  const [deleting, setDeleting] = useState<Note | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return notes
      .filter((note) => {
        if (category !== 'all' && note.category !== category) return false;
        if (q && !`${note.title} ${note.content}`.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt));
  }, [notes, category, query]);

  const handleSave = (values: NewNote) => {
    if (editor?.mode === 'edit' && editor.note) {
      updateNote(editor.note.id, values);
      toast({ title: t('noteUpdatedToast'), description: values.title });
    } else {
      addNote(values);
      toast({ title: t('noteAddedToast'), description: values.title });
    }
    setEditor(null);
  };

  return (
    <div>
      <PageHeader
        eyebrow={t('workspace')}
        title={t('notesTitle')}
        subtitle={t('notesSubtitle')}
        actions={
          <button type="button" className="btn btn-primary" onClick={() => setEditor({ mode: 'new' })}>
            <Plus size={15} />
            {t('newNote')}
          </button>
        }
      />

      <div className="card mb-4 p-3.5 sm:p-4">
        <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t('searchNotes')}
              className="field pl-9"
              aria-label={t('searchNotes')}
            />
          </div>
          <div className="scroll-thin -mx-1 flex gap-1.5 overflow-x-auto px-1">
            <button
              type="button"
              onClick={() => setCategory('all')}
              className={cn(
                'whitespace-nowrap rounded-full border px-3 py-1.5 text-[11px] font-medium transition',
                category === 'all'
                  ? 'border-brand/40 bg-brand/15 text-violet-200'
                  : 'border-line/[0.08] text-muted hover:text-ink',
              )}
            >
              {t('all')}
            </button>
            {CATEGORIES.map((c) => {
              const color = CATEGORY_COLORS[c];
              const isActive = category === c;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCategory(c)}
                  className="flex items-center gap-1.5 whitespace-nowrap rounded-full border px-3 py-1.5 text-[11px] font-medium transition"
                  style={{
                    borderColor: isActive ? `${color}88` : 'var(--glass-border)',
                    background: isActive ? `${color}1c` : 'transparent',
                    color: isActive ? color : 'rgb(var(--muted))',
                  }}
                >
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
                  {t(c)}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {notes.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={NotebookPen}
            title={t('noNotesTitle')}
            text={t('noNotesText')}
            action={
              <button type="button" className="btn btn-primary" onClick={() => setEditor({ mode: 'new' })}>
                <Plus size={14} />
                {t('addFirstNote')}
              </button>
            }
          />
        </div>
      ) : filtered.length === 0 ? (
        <div className="card">
          <EmptyState icon={Search} title={t('noResultsTitle')} text={t('noResultsText')} />
        </div>
      ) : (
        <div className="grid gap-3.5 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((note) => {
            const color = CATEGORY_COLORS[note.category];
            return (
              <article
                key={note.id}
                onClick={() => setEditor({ mode: 'edit', note })}
                className="card card-hover group relative cursor-pointer overflow-hidden p-4"
              >
                <span
                  className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-70"
                  style={{ background: `linear-gradient(90deg, ${color}, transparent 75%)` }}
                />
                <div className="flex items-start justify-between gap-2">
                  <CategoryTag category={note.category} />
                  <div className="flex items-center gap-0.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleNotePin(note.id);
                        toast({
                          title: note.pinned ? t('noteUnpinnedToast') : t('notePinnedToast'),
                          tone: 'info',
                        });
                      }}
                      className={cn(
                        'rounded-lg p-1.5 transition',
                        note.pinned
                          ? 'bg-brand/15 text-brand'
                          : 'text-muted hover:bg-line/[0.07] hover:text-ink',
                      )}
                      aria-label={note.pinned ? t('unpin') : t('pin')}
                      title={note.pinned ? t('unpin') : t('pin')}
                    >
                      {note.pinned ? <Pin size={13} /> : <PinOff size={13} />}
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleting(note);
                      }}
                      className="rounded-lg p-1.5 text-muted opacity-100 transition hover:bg-rose-500/10 hover:text-rose-400 sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100"
                      aria-label={t('delete')}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                <h3 className="mt-2.5 line-clamp-1 font-display text-[14px] font-bold">
                  {note.title || t('untitled')}
                </h3>
                <p className="mt-1.5 line-clamp-5 min-h-[76px] whitespace-pre-line text-[11.5px] leading-relaxed text-muted">
                  {note.content || t('emptyNote')}
                </p>

                <div className="mt-3 flex items-center justify-between border-t border-line/[0.06] pt-2.5">
                  <span className="text-[9.5px] text-muted/70">
                    {t('editedAt', {
                      date: formatDate(note.updatedAt.slice(0, 10), lang, {
                        day: 'numeric',
                        month: 'short',
                      }),
                    })}
                  </span>
                  <span className="flex items-center gap-1 text-[9.5px] font-medium text-muted opacity-0 transition group-hover:opacity-100">
                    <Pencil size={10} />
                    {t('edit')}
                  </span>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <NoteEditor
        open={Boolean(editor)}
        mode={editor?.mode ?? 'new'}
        note={editor?.note}
        onClose={() => setEditor(null)}
        onSave={handleSave}
      />

      <ConfirmDialog
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={() => {
          if (deleting) {
            deleteNote(deleting.id);
            toast({ title: t('noteDeletedToast'), tone: 'info' });
          }
        }}
        title={t('deleteNoteTitle')}
        text={t('deleteNoteText', { title: deleting?.title || t('untitled') })}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Note editor                                                        */
/* ------------------------------------------------------------------ */
function NoteEditor({
  open,
  mode,
  note,
  onClose,
  onSave,
}: {
  open: boolean;
  mode: 'new' | 'edit';
  note?: Note;
  onClose: () => void;
  onSave: (values: NewNote) => void;
}) {
  const { t } = useT();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<Category>('personal');

  useEffect(() => {
    if (!open) return;
    setTitle(note?.title ?? '');
    setContent(note?.content ?? '');
    setCategory(note?.category ?? 'personal');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, note?.id]);

  const submit = () => {
    if (!content.trim() && !title.trim()) return;
    onSave({ title: title.trim() || t('untitled'), content: content.trim(), category });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={mode === 'edit' ? t('editNote') : t('newNote')}
      subtitle={t('notesSubtitle')}
      maxWidth="max-w-2xl"
      footer={
        <>
          <span className="mr-auto text-[10px] text-muted">
            <FileText size={11} className="mr-1 inline" />
            {content.length}
          </span>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            {t('cancel')}
          </button>
          <button type="button" className="btn btn-primary" onClick={submit}>
            <NotebookPen size={14} />
            {t('saveNoteBtn')}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="field-label" htmlFor="note-title">{t('noteTitleLabel')}</label>
          <input
            id="note-title"
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('noteTitlePlaceholder')}
            className="field font-display text-base font-semibold"
          />
        </div>

        <div>
          <label className="field-label" htmlFor="note-content">{t('noteContent')}</label>
          <textarea
            id="note-content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={t('noteContentPlaceholder')}
            rows={11}
            className="field min-h-[220px] leading-relaxed"
          />
        </div>

        <div>
          <span className="field-label">{t('noteCategory')}</span>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {CATEGORIES.map((c) => {
              const color = CATEGORY_COLORS[c];
              const active = category === c;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCategory(c)}
                  className="flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2 text-[11.5px] font-medium transition"
                  style={{
                    borderColor: active ? `${color}88` : 'var(--glass-border)',
                    background: active ? `${color}1f` : 'var(--input-bg)',
                    color: active ? color : 'rgb(var(--muted))',
                  }}
                >
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
                  {t(c)}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </Modal>
  );
}
