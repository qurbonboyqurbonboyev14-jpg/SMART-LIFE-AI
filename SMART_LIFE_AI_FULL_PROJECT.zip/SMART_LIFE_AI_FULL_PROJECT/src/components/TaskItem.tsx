import { CalendarClock, Check, Pencil, Trash2 } from 'lucide-react';
import { cn } from '../lib/cn';
import type { Task } from '../lib/types';
import { useT } from '../lib/i18n';
import { relativeDay, todayISO } from '../lib/date';
import { isOverdue } from '../lib/analytics';
import { CategoryTag, PriorityTag } from './ui';

export function TaskItem({
  task,
  onToggle,
  onEdit,
  onDelete,
  dense = false,
}: {
  task: Task;
  onToggle: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  dense?: boolean;
}) {
  const { t, lang } = useT();
  const overdue = isOverdue(task);
  const isToday = task.due === todayISO();

  return (
    <div
      className={cn(
        'group relative flex items-start gap-3 rounded-2xl px-2 py-2.5 transition-colors hover:bg-line/[0.035] sm:px-3',
        task.completed && 'opacity-60',
      )}
    >
      <button
        type="button"
        onClick={onToggle}
        aria-label={task.completed ? t('markActive') : t('markDone')}
        className={cn('task-check mt-0.5', task.completed && 'task-check-done')}
      >
        <Check size={11} strokeWidth={3.5} />
      </button>

      <div className="min-w-0 flex-1">
        <div className="flex items-start gap-2">
          <p
            className={cn(
              'min-w-0 flex-1 text-[13.5px] font-medium leading-snug transition-colors',
              task.completed && 'text-muted line-through decoration-line/30',
            )}
          >
            {task.title}
          </p>
          {!dense ? (
            <div className="flex shrink-0 items-center gap-0.5 opacity-100 transition-opacity sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100">
              {onEdit ? (
                <button
                  type="button"
                  onClick={onEdit}
                  className="rounded-lg p-1.5 text-muted transition hover:bg-line/[0.07] hover:text-ink"
                  aria-label={t('edit')}
                >
                  <Pencil size={13} />
                </button>
              ) : null}
              {onDelete ? (
                <button
                  type="button"
                  onClick={onDelete}
                  className="rounded-lg p-1.5 text-muted transition hover:bg-rose-500/10 hover:text-rose-400"
                  aria-label={t('delete')}
                >
                  <Trash2 size={13} />
                </button>
              ) : null}
            </div>
          ) : null}
        </div>

        {task.description && !dense ? (
          <p className="mt-0.5 line-clamp-1 text-[11.5px] text-muted">{task.description}</p>
        ) : null}

        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
          <CategoryTag category={task.category} />
          <PriorityTag priority={task.priority} />
          {!task.completed ? (
            <span
              className={cn(
                'chip chip-muted gap-1',
                overdue && 'chip-danger',
                isToday && !overdue && 'chip-brand',
              )}
            >
              <CalendarClock size={10} />
              {overdue
                ? t('overdue')
                : relativeDay(task.due, lang, {
                    today: t('today'),
                    tomorrow: t('tomorrow'),
                    yesterday: t('yesterday'),
                  })}
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
