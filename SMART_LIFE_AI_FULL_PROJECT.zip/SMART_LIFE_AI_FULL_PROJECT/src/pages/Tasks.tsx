import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  AlertCircle,
  CalendarClock,
  CheckCircle2,
  FilterX,
  ListChecks,
  Pencil,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { useApp, type NewTask } from '../lib/store';
import { useT, type TranslationKey } from '../lib/i18n';
import { cn } from '../lib/cn';
import { isOverdue } from '../lib/analytics';
import { todayISO } from '../lib/date';
import type { Category, Priority, Task } from '../lib/types';
import { CATEGORIES, PRIORITIES } from '../lib/types';
import { CATEGORY_COLORS, PRIORITY_COLORS } from '../lib/analytics';
import {
  CategoryTag,
  ConfirmDialog,
  EmptyState,
  Modal,
  PageHeader,
  PriorityTag,
  ProgressBar,
  Segmented,
} from '../components/ui';
import { TaskItem } from '../components/TaskItem';
import { useToast } from '../components/Toast';

type StatusFilter = 'all' | 'active' | 'done';
type SortKey = 'due' | 'priority' | 'created' | 'alpha';

const priorityRank: Record<Priority, number> = { high: 0, medium: 1, low: 2 };

export default function Tasks() {
  const { t } = useT();
  const toast = useToast();
  const [searchParams, setSearchParams] = useSearchParams();

  const tasks = useApp((s) => s.tasks);
  const addTask = useApp((s) => s.addTask);
  const updateTask = useApp((s) => s.updateTask);
  const toggleTask = useApp((s) => s.toggleTask);
  const deleteTask = useApp((s) => s.deleteTask);

  const [status, setStatus] = useState<StatusFilter>('all');
  const [category, setCategory] = useState<Category | 'all'>('all');
  const [priority, setPriority] = useState<Priority | 'all'>('all');
  const [sort, setSort] = useState<SortKey>('due');
  const [query, setQuery] = useState('');

  const [editor, setEditor] = useState<{ mode: 'new' | 'edit'; task?: Task } | null>(null);
  const [deleting, setDeleting] = useState<Task | null>(null);

  useEffect(() => {
    if (searchParams.get('new')) {
      setEditor({ mode: 'new' });
      setSearchParams({}, { replace: true });
    } else {
      const editId = searchParams.get('edit');
      if (editId) {
        const task = tasks.find((x) => x.id === editId);
        if (task) setEditor({ mode: 'edit', task });
        setSearchParams({}, { replace: true });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const today = todayISO();
  const overdueCount = tasks.filter(isOverdue).length;
  const todayDone = tasks.filter((x) => x.completed && x.completedAt?.slice(0, 10) === today).length;
  const activeTasks = useMemo(() => tasks.filter((x) => !x.completed), [tasks]);
  const completedTasks = useMemo(
    () => [...tasks].filter((x) => x.completed).sort((a, b) => (b.completedAt || b.createdAt).localeCompare(a.completedAt || a.createdAt)),
    [tasks],
  );
  const activeCount = activeTasks.length;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = tasks.filter((task) => {
      // Manage active tasks primarily; completed history shown in separate section
      if (task.completed) return false;
      if (status === 'done') return false;
      if (status === 'active' && task.completed) return false;
      if (category !== 'all' && task.category !== category) return false;
      if (priority !== 'all' && task.priority !== priority) return false;
      if (q && !`${task.title} ${task.description}`.toLowerCase().includes(q)) return false;
      return true;
    });

    list.sort((a, b) => {
      if (sort === 'due') return a.due.localeCompare(b.due) || priorityRank[a.priority] - priorityRank[b.priority];
      if (sort === 'priority') return priorityRank[a.priority] - priorityRank[b.priority] || a.due.localeCompare(b.due);
      if (sort === 'created') return b.createdAt.localeCompare(a.createdAt);
      return a.title.localeCompare(b.title);
    });
    return list;
  }, [tasks, status, category, priority, sort, query]);

  const filtersActive = status !== 'all' || category !== 'all' || priority !== 'all' || Boolean(query);

  const handleToggle = (task: Task) => {
    toggleTask(task.id);
    toast({
      title: task.completed ? t('taskReopenedToast') : t('taskDoneToast'),
      description: task.title,
      tone: task.completed ? 'info' : 'success',
    });
  };

  const handleSave = (values: NewTask) => {
    if (editor?.mode === 'edit' && editor.task) {
      updateTask(editor.task.id, values);
      toast({ title: t('taskUpdatedToast'), description: values.title });
    } else {
      addTask(values);
      toast({ title: t('taskAddedToast'), description: values.title });
    }
    setEditor(null);
  };

  return (
    <div>
      <PageHeader
        eyebrow={t('workspace')}
        title={t('tasksTitle')}
        subtitle={t('tasksSubtitle')}
        actions={
          <button type="button" className="btn btn-primary" onClick={() => setEditor({ mode: 'new' })}>
            <Plus size={15} />
            {t('newTask')}
          </button>
        }
      />

      {/* summary */}
      <div className="mb-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {[
          { label: t('tasksTotal'), value: tasks.length, icon: ListChecks, tone: 'text-violet-300 bg-violet-500/12' },
          { label: t('active'), value: activeCount, icon: CalendarClock, tone: 'text-sky-300 bg-sky-500/12' },
          { label: t('tasksOverdue'), value: overdueCount, icon: AlertCircle, tone: 'text-rose-300 bg-rose-500/12' },
          { label: t('tasksCompletedToday'), value: todayDone, icon: CheckCircle2, tone: 'text-emerald-300 bg-emerald-500/12' },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="card flex items-center gap-3 px-3.5 py-3">
              <span className={cn('grid h-9 w-9 shrink-0 place-items-center rounded-xl', item.tone)}>
                <Icon size={16} />
              </span>
              <div className="min-w-0">
                <p className="text-[9.5px] uppercase tracking-wider text-muted">{item.label}</p>
                <p className="mt-0.5 font-display text-lg font-bold leading-none">{item.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="card p-3.5 sm:p-4">
        {/* toolbar */}
        <div className="flex flex-col gap-2.5 xl:flex-row xl:items-center">
          <div className="relative flex-1">
            <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t('searchTasks')}
              className="field pl-9"
              aria-label={t('searchTasks')}
            />
            {query ? (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1 text-muted transition hover:bg-line/[0.06] hover:text-ink"
                aria-label={t('close')}
              >
                <FilterX size={13} />
              </button>
            ) : null}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Segmented
              options={[
                { value: 'all', label: t('filterAll') },
                { value: 'active', label: t('filterActive') },
                { value: 'done', label: t('filterDone') },
              ]}
              value={status}
              onChange={setStatus}
            />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as Category | 'all')}
              className="field w-auto min-w-[120px] py-2 text-[12px]"
              aria-label={t('taskCategory')}
            >
              <option value="all">{t('allCategories')}</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {t(c)}
                </option>
              ))}
            </select>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority | 'all')}
              className="field w-auto min-w-[104px] py-2 text-[12px]"
              aria-label={t('taskPriority')}
            >
              <option value="all">{t('all')} · {t('taskPriority').toLowerCase()}</option>
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {t(p)}
                </option>
              ))}
            </select>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="field w-auto min-w-[120px] py-2 text-[12px]"
              aria-label={t('sortBy')}
            >
              <option value="due">{t('sortDue')}</option>
              <option value="priority">{t('sortPriority')}</option>
              <option value="created">{t('sortCreated')}</option>
              <option value="alpha">{t('sortAlpha')}</option>
            </select>
            {filtersActive ? (
              <button
                type="button"
                onClick={() => {
                  setStatus('all');
                  setCategory('all');
                  setPriority('all');
                  setQuery('');
                }}
                className="icon-btn h-9 w-9"
                aria-label={t('reset')}
                title={t('reset')}
              >
                <FilterX size={15} />
              </button>
            ) : null}
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between border-t border-line/[0.06] pt-3">
          <p className="text-[11px] text-muted">
            {t('tasksTotal')}: <span className="font-semibold text-ink">{filtered.length}</span>
          </p>
          <div className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            <span className="text-[10.5px] text-muted">
              {t('todaySummary', {
                done: tasks.filter((x) => x.due === today && x.completed).length,
                total: tasks.filter((x) => x.due === today).length,
              })}
            </span>
          </div>
        </div>

        {tasks.length === 0 ? (
          <EmptyState
            icon={ListChecks}
            title="No tasks yet"
            text="You have no tasks yet. Create your first task."
            action={
              <button type="button" className="btn btn-primary" onClick={() => setEditor({ mode: 'new' })}>
                <Plus size={14} />
                {t('addFirstTask')}
              </button>
            }
          />
        ) : filtered.length === 0 && activeTasks.length > 0 ? (
          <EmptyState icon={Search} title={t('noResultsTitle')} text={t('noResultsText')} />
        ) : filtered.length === 0 && activeTasks.length === 0 ? (
          <div className="mt-4 rounded-2xl border border-line/[0.07] bg-line/[0.02] p-4 text-center text-sm text-muted">
            No active tasks. Create a new task when you're ready.
          </div>
        ) : (
          <div className="mt-1 divide-y divide-line/[0.045]">
            {filtered.map((task) => (
              <TaskItem
                key={task.id}
                task={task}
                onToggle={() => handleToggle(task)}
                onEdit={() => setEditor({ mode: 'edit', task })}
                onDelete={() => setDeleting(task)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Completed Tasks history (separate section) */}
      <div className="card mt-4 p-3.5 sm:p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-base font-bold">Completed Tasks</h2>
            <p className="mt-0.5 text-[11.5px] text-muted">Your achievements and completed task history. Completed tasks are never removed automatically.</p>
          </div>
          <span className="rounded-xl border border-emerald-400/20 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-300">{completedTasks.length}</span>
        </div>
        {completedTasks.length === 0 ? (
          <p className="text-[13px] text-muted">No completed tasks yet. When you finish a task, it will appear here with its completion date.</p>
        ) : (
          <div className="divide-y divide-line/[0.045]">
            {completedTasks.map((task) => (
              <div key={task.id} className="flex items-start gap-3 py-3">
                <button
                  type="button"
                  onClick={() => handleToggle(task)}
                  aria-label={t('markActive')}
                  className="task-check task-check-done mt-0.5"
                  title="Reopen task"
                >
                  <CheckCircle2 size={12} />
                </button>
                <div className="min-w-0 flex-1">
                  <p className="text-[13.5px] font-medium leading-snug text-muted line-through decoration-line/30">{task.title}</p>
                  <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                    <CategoryTag category={task.category} />
                    <span className="chip chip-muted">Completed: {task.completedAt ? new Date(task.completedAt).toLocaleString() : '—'}</span>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <button type="button" onClick={() => handleToggle(task)} className="rounded-lg px-2 py-1.5 text-[11px] font-semibold text-emerald-300 hover:bg-emerald-500/10" title="Reopen">Reopen</button>
                  <button type="button" onClick={() => setDeleting(task)} className="rounded-lg p-1.5 text-muted hover:bg-rose-500/10 hover:text-rose-400" aria-label={t('delete')}><Trash2 size={13} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <TaskEditor
        open={Boolean(editor)}
        mode={editor?.mode ?? 'new'}
        task={editor?.task}
        onClose={() => setEditor(null)}
        onSave={handleSave}
      />

      <ConfirmDialog
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={() => {
          if (deleting) {
            deleteTask(deleting.id);
            toast({ title: t('taskDeletedToast'), tone: 'info' });
          }
        }}
        title={t('deleteTaskTitle')}
        text={t('deleteTaskText', { title: deleting?.title ?? '' })}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Task editor                                                        */
/* ------------------------------------------------------------------ */
function TaskEditor({
  open,
  mode,
  task,
  onClose,
  onSave,
}: {
  open: boolean;
  mode: 'new' | 'edit';
  task?: Task;
  onClose: () => void;
  onSave: (values: NewTask) => void;
}) {
  const { t } = useT();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Category>('study');
  const [priority, setPriority] = useState<Priority>('medium');
  const [due, setDue] = useState(todayISO());
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTitle(task?.title ?? '');
    setDescription(task?.description ?? '');
    setCategory(task?.category ?? 'study');
    setPriority(task?.priority ?? 'medium');
    setDue(task?.due ?? todayISO());
    setError(false);
  }, [open, task]);

  const submit = () => {
    if (!title.trim()) {
      setError(true);
      return;
    }
    onSave({ title: title.trim(), description: description.trim(), category, priority, due });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={mode === 'edit' ? t('editTask') : t('newTaskBtn')}
      subtitle={t('taskFormHint')}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            {t('cancel')}
          </button>
          <button type="button" className="btn btn-primary" onClick={submit}>
            <CheckCircle2 size={14} />
            {mode === 'edit' ? t('updateTaskBtn') : t('addTaskBtn')}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="field-label" htmlFor="task-title">
            {t('taskName')} *
          </label>
          <input
            id="task-title"
            autoFocus
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              if (e.target.value.trim()) setError(false);
            }}
            placeholder={t('taskNamePlaceholder')}
            className={cn('field', error && 'border-rose-400/60 focus:shadow-[0_0_0_4px_rgba(244,63,94,.12)]')}
          />
          {error ? <p className="mt-1.5 text-[11px] text-rose-400">{t('taskName')} *</p> : null}
        </div>

        <div>
          <label className="field-label" htmlFor="task-desc">
            {t('taskDesc')} <span className="normal-case tracking-normal opacity-60">({t('optional')})</span>
          </label>
          <textarea
            id="task-desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={t('taskDescPlaceholder')}
            rows={3}
            className="field"
          />
        </div>

        <div>
          <span className="field-label">{t('taskCategory')}</span>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {CATEGORIES.map((c) => {
              const color = CATEGORY_COLORS[c];
              const active = category === c;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCategory(c)}
                  className="flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2 text-[11.5px] font-medium transition"
                  style={{
                    borderColor: active ? `${color}88` : 'var(--glass-border)',
                    background: active ? `${color}1f` : 'var(--input-bg)',
                    color: active ? color : 'rgb(var(--muted))',
                  }}
                >
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
                  {t(c)}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <span className="field-label">{t('taskPriority')}</span>
            <div className="flex gap-2">
              {PRIORITIES.map((p) => {
                const color = PRIORITY_COLORS[p];
                const active = priority === p;
                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border px-2 py-2 text-[11.5px] font-medium transition"
                    style={{
                      borderColor: active ? `${color}88` : 'var(--glass-border)',
                      background: active ? `${color}1a` : 'var(--input-bg)',
                      color: active ? color : 'rgb(var(--muted))',
                    }}
                  >
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
                    {t(p)}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <label className="field-label" htmlFor="task-due">
              {t('taskDeadline')}
            </label>
            <input
              id="task-due"
              type="date"
              value={due}
              onChange={(e) => setDue(e.target.value || todayISO())}
              className="field"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 rounded-xl border border-line/[0.06] bg-line/[0.02] px-3 py-2.5">
          <div className="flex flex-wrap items-center gap-1.5">
            <CategoryTag category={category} />
            <PriorityTag priority={priority} />
          </div>
          <div className="ml-auto w-20">
            <ProgressBar value={priority === 'high' ? 90 : priority === 'medium' ? 55 : 25} height={4} showGlow={false} />
          </div>
        </div>
      </div>
    </Modal>
  );
}
