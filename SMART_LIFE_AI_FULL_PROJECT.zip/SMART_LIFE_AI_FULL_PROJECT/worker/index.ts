/**
 * SMART LIFE AI — Cloudflare Worker API
 *
 * Real authentication (password + Google), per-user workspaces, unique SL IDs,
 * friends, notifications and owner-only administration on D1.
 * Secrets stay server-side; the browser only receives HttpOnly session cookies.
 */

interface Env {
  DB: D1Database;
  ASSETS: Fetcher;
  MEDIA_BUCKET?: R2Bucket;
  ADMIN_KEY?: string;
  ADMIN_PASSWORD_HASH?: string;
  GOOGLE_CLIENT_ID?: string;
}

interface UserRow {
  id: string;
  user_code: string;
  name: string;
  first_name: string;
  last_name: string;
  username: string;
  email: string;
  password_hash: string;
  bio: string;
  interests: string;
  goals: string;
  avatar: string;
  status: string;
  auth_provider: string;
  google_sub: string;
  is_vip: number;
  vip_permanent: number;
  profile_frame: string;
  username_effect: string;
  username_color: string;
  border_color: string;
  glow_effect: string;
  profile_theme: string;
  customization_updated_at: number;
  is_owner: number;
  cover_url: string;
  cover_type: string;
  cover_pos_x: number;
  cover_pos_y: number;
  cover_scale: number;
  bg_url: string;
  bg_type: string;
  bg_pos_x: number;
  bg_pos_y: number;
  bg_scale: number;
  bg_blur: number;
  bg_overlay: number;
  last_seen_at: number;
  typing_to: string;
  typing_at: number;
  created_at: number;
  updated_at: number;
  last_login_at: number | null;
}

const SESSION_COOKIE = 'sl_session';
const ADMIN_COOKIE = 'sl_admin';
const SESSION_DAYS = 30;
const ADMIN_HOURS = 8;
const PBKDF2_ITERATIONS = 100_000;
const MAX_BODY = 4_000_000;
const MAX_WORKSPACE = 1_500_000;
const MAX_AVATAR = 2_200_000;

const VIP_EMAIL = 'qurbonboyqurbonboyev14@gmail.com';
const OWNER_EMAIL = VIP_EMAIL;
const FRAME_STYLES = ['none', 'neon-purple', 'electric-blue', 'golden-vip', 'rainbow-glow', 'cyber-frame', 'diamond-frame', 'premium-black'] as const;
const VIP_ONLY_FRAMES = new Set(['golden-vip', 'rainbow-glow', 'diamond-frame', 'premium-black']);
const USERNAME_EFFECTS = ['none', 'rainbow', 'purple-neon', 'blue-electric', 'golden-vip', 'red-glow', 'green-glow', 'smooth', 'static'] as const;
const VIP_ONLY_EFFECTS = new Set(['rainbow', 'golden-vip']);
const GLOW_EFFECTS = ['none', 'purple', 'blue', 'gold', 'rainbow', 'cyan'] as const;
const PROFILE_THEMES = ['default', 'violet', 'ocean', 'sunset', 'emerald', 'midnight'] as const;

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    user_code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    first_name TEXT NOT NULL DEFAULT '',
    last_name TEXT NOT NULL DEFAULT '',
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL DEFAULT '',
    bio TEXT NOT NULL DEFAULT '',
    interests TEXT NOT NULL DEFAULT '',
    goals TEXT NOT NULL DEFAULT '',
    avatar TEXT NOT NULL DEFAULT '🦋',
    status TEXT NOT NULL DEFAULT 'active',
    auth_provider TEXT NOT NULL DEFAULT 'local',
    google_sub TEXT NOT NULL DEFAULT '',
    is_vip INTEGER NOT NULL DEFAULT 0,
    vip_permanent INTEGER NOT NULL DEFAULT 0,
    profile_frame TEXT NOT NULL DEFAULT 'none',
    username_effect TEXT NOT NULL DEFAULT 'none',
    username_color TEXT NOT NULL DEFAULT '',
    border_color TEXT NOT NULL DEFAULT '',
    glow_effect TEXT NOT NULL DEFAULT 'none',
    profile_theme TEXT NOT NULL DEFAULT 'default',
    customization_updated_at INTEGER NOT NULL DEFAULT 0,
    is_owner INTEGER NOT NULL DEFAULT 0,
    cover_url TEXT NOT NULL DEFAULT '',
    cover_type TEXT NOT NULL DEFAULT '',
    cover_pos_x INTEGER NOT NULL DEFAULT 50,
    cover_pos_y INTEGER NOT NULL DEFAULT 50,
    cover_scale INTEGER NOT NULL DEFAULT 100,
    bg_url TEXT NOT NULL DEFAULT '',
    bg_type TEXT NOT NULL DEFAULT '',
    bg_pos_x INTEGER NOT NULL DEFAULT 50,
    bg_pos_y INTEGER NOT NULL DEFAULT 50,
    bg_scale INTEGER NOT NULL DEFAULT 100,
    bg_blur INTEGER NOT NULL DEFAULT 0,
    bg_overlay INTEGER NOT NULL DEFAULT 45,
    last_seen_at INTEGER NOT NULL DEFAULT 0,
    typing_to TEXT NOT NULL DEFAULT '',
    typing_at INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    last_login_at INTEGER
  )`,
  `CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    user_agent TEXT NOT NULL DEFAULT '',
    ip TEXT NOT NULL DEFAULT ''
  )`,
  'CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id)',
  `CREATE TABLE IF NOT EXISTS workspaces (
    user_id TEXT PRIMARY KEY,
    data TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    action TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT '',
    ip TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL
  )`,
  'CREATE INDEX IF NOT EXISTS idx_activity_created ON activity(created_at DESC)',
  `CREATE TABLE IF NOT EXISTS admin_sessions (
    token_hash TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS auth_attempts (
    key TEXT PRIMARY KEY,
    count INTEGER NOT NULL,
    reset_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS friend_requests (
    id TEXT PRIMARY KEY,
    from_user_id TEXT NOT NULL,
    to_user_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    UNIQUE(from_user_id, to_user_id)
  )`,
  'CREATE INDEX IF NOT EXISTS idx_friend_req_to ON friend_requests(to_user_id, status)',
  'CREATE INDEX IF NOT EXISTS idx_friend_req_from ON friend_requests(from_user_id, status)',
  `CREATE TABLE IF NOT EXISTS friendships (
    id TEXT PRIMARY KEY,
    user_a TEXT NOT NULL,
    user_b TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE(user_a, user_b)
  )`,
  'CREATE INDEX IF NOT EXISTS idx_friend_a ON friendships(user_a)',
  'CREATE INDEX IF NOT EXISTS idx_friend_b ON friendships(user_b)',
  `CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL,
    message TEXT NOT NULL,
    data TEXT NOT NULL DEFAULT '{}',
    read INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  )`,
  'CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, read, created_at DESC)',
  `CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    user_a TEXT NOT NULL,
    user_b TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    last_message_at INTEGER NOT NULL DEFAULT 0,
    last_message_text TEXT NOT NULL DEFAULT '',
    UNIQUE(user_a, user_b)
  )`,
  'CREATE INDEX IF NOT EXISTS idx_conv_a ON conversations(user_a, updated_at DESC)',
  'CREATE INDEX IF NOT EXISTS idx_conv_b ON conversations(user_b, updated_at DESC)',
  `CREATE TABLE IF NOT EXISTS chat_messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    deleted_for_all INTEGER NOT NULL DEFAULT 0,
    deleted_by TEXT NOT NULL DEFAULT ''
  )`,
  'CREATE INDEX IF NOT EXISTS idx_chat_conv ON chat_messages(conversation_id, created_at)',
  `CREATE TABLE IF NOT EXISTS message_reads (
    user_id TEXT NOT NULL,
    conversation_id TEXT NOT NULL,
    last_read_at INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, conversation_id)
  )`,
  `CREATE TABLE IF NOT EXISTS blocks (
    blocker_id TEXT NOT NULL,
    blocked_id TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    PRIMARY KEY (blocker_id, blocked_id)
  )`,
  `CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    reporter_id TEXT NOT NULL,
    reported_id TEXT NOT NULL,
    conversation_id TEXT NOT NULL DEFAULT '',
    reason TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL
  )`,
];

let schemaPromise: Promise<void> | null = null;
let schemaPatched = false;

async function ensureSchema(db: D1Database): Promise<void> {
  if (!schemaPromise) {
    schemaPromise = (async () => {
      await db.batch(SCHEMA.map((sql) => db.prepare(sql)));
      if (!schemaPatched) {
        // Best-effort migration for databases created before the new columns/tables.
        const alters = [
          "ALTER TABLE users ADD COLUMN user_code TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN first_name TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN last_name TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN auth_provider TEXT NOT NULL DEFAULT 'local'",
          "ALTER TABLE users ADD COLUMN google_sub TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN is_vip INTEGER NOT NULL DEFAULT 0",
          "ALTER TABLE users ADD COLUMN vip_permanent INTEGER NOT NULL DEFAULT 0",
          "ALTER TABLE users ADD COLUMN profile_frame TEXT NOT NULL DEFAULT 'none'",
          "ALTER TABLE users ADD COLUMN username_effect TEXT NOT NULL DEFAULT 'none'",
          "ALTER TABLE users ADD COLUMN username_color TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN border_color TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN glow_effect TEXT NOT NULL DEFAULT 'none'",
          "ALTER TABLE users ADD COLUMN profile_theme TEXT NOT NULL DEFAULT 'default'",
          "ALTER TABLE users ADD COLUMN customization_updated_at INTEGER NOT NULL DEFAULT 0",
          "ALTER TABLE users ADD COLUMN is_owner INTEGER NOT NULL DEFAULT 0",
          "ALTER TABLE users ADD COLUMN cover_url TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN cover_type TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN cover_pos_x INTEGER NOT NULL DEFAULT 50",
          "ALTER TABLE users ADD COLUMN cover_pos_y INTEGER NOT NULL DEFAULT 50",
          "ALTER TABLE users ADD COLUMN cover_scale INTEGER NOT NULL DEFAULT 100",
          "ALTER TABLE users ADD COLUMN bg_url TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN bg_type TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN bg_pos_x INTEGER NOT NULL DEFAULT 50",
          "ALTER TABLE users ADD COLUMN bg_pos_y INTEGER NOT NULL DEFAULT 50",
          "ALTER TABLE users ADD COLUMN bg_scale INTEGER NOT NULL DEFAULT 100",
          "ALTER TABLE users ADD COLUMN bg_blur INTEGER NOT NULL DEFAULT 0",
          "ALTER TABLE users ADD COLUMN bg_overlay INTEGER NOT NULL DEFAULT 45",
          "ALTER TABLE users ADD COLUMN last_seen_at INTEGER NOT NULL DEFAULT 0",
          "ALTER TABLE users ADD COLUMN typing_to TEXT NOT NULL DEFAULT ''",
          "ALTER TABLE users ADD COLUMN typing_at INTEGER NOT NULL DEFAULT 0",
        ];
        for (const sql of alters) {
          try { await db.prepare(sql).run(); } catch { /* column exists */ }
        }
        // Ensure any legacy user has a code (codes are immutable once set).
        const missing = await db.prepare(
          "SELECT id FROM users WHERE user_code = '' OR user_code IS NULL",
        ).all<{ id: string }>();
        for (const row of missing.results ?? []) {
          const code = await generateUniqueCode(db);
          await db.prepare('UPDATE users SET user_code = ? WHERE id = ? AND (user_code = "" OR user_code IS NULL)')
            .bind(code, row.id).run();
        }
        try { await db.prepare('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_code ON users(user_code)').run(); } catch { /* */ }
        // Auto-grant permanent VIP to the designated account (server-side, by verified email).
        try { await db.prepare('UPDATE users SET is_vip = 1, vip_permanent = 1, is_owner = 1 WHERE LOWER(email) = ?').bind(OWNER_EMAIL).run(); } catch { /* */ }
        try { await db.prepare('UPDATE users SET is_owner = 1 WHERE LOWER(email) = ?').bind(OWNER_EMAIL).run(); } catch { /* */ }
        schemaPatched = true;
      }
    })().catch((error) => {
      schemaPromise = null;
      throw error;
    });
  }
  return schemaPromise;
}

/* ------------------------------------------------------------------ */
/*  Utilities                                                          */
/* ------------------------------------------------------------------ */

const encoder = new TextEncoder();

class HttpError extends Error {
  status: number;
  code?: string;
  constructor(status: number, message: string, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function json(data: unknown, status = 200, extraHeaders?: HeadersInit): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...(extraHeaders ?? {}),
    },
  });
}

function fail(message: string, status = 400, code?: string): Response {
  return json({ error: message, ...(code ? { code } : {}) }, status);
}

function now(): number { return Date.now(); }
function dayISO(ms: number): string { return new Date(ms).toISOString().slice(0, 10); }

function base64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function fromBase64(value: string): Uint8Array {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function base64Url(bytes: Uint8Array): string {
  return base64(bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function randomToken(byteLength = 32): string {
  return base64Url(crypto.getRandomValues(new Uint8Array(byteLength)));
}

async function sha256(value: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(value));
  return base64(new Uint8Array(digest));
}

async function hashPassword(
  password: string,
  salt?: Uint8Array,
  iterations = PBKDF2_ITERATIONS,
): Promise<string> {
  const saltBytes = salt ?? crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const derived = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: saltBytes, iterations, hash: 'SHA-256' },
    key,
    256,
  );
  return `pbkdf2$${iterations}$${base64(saltBytes)}$${base64(new Uint8Array(derived))}`;
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function verifyPassword(password: string, stored: string): Promise<boolean> {
  try {
    const [scheme, iterationsRaw, saltRaw, hashRaw] = stored.split('$');
    if (scheme !== 'pbkdf2' || !saltRaw || !hashRaw) return false;
    const iterations = Number(iterationsRaw);
    if (!Number.isFinite(iterations) || iterations < 10_000 || iterations > 1_000_000) return false;
    const candidate = await hashPassword(password, fromBase64(saltRaw), iterations);
    return safeEqual(candidate, stored);
  } catch {
    return false;
  }
}

function parseCookies(request: Request): Record<string, string> {
  const header = request.headers.get('Cookie') ?? '';
  const out: Record<string, string> = {};
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    const key = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    if (key) out[key] = decodeURIComponent(value);
  }
  return out;
}

function isSecure(request: Request): boolean {
  const proto = request.headers.get('X-Forwarded-Proto');
  if (proto) return proto.split(',')[0].trim() === 'https';
  return new URL(request.url).protocol === 'https:';
}

function cookie(name: string, value: string, maxAge: number, secure: boolean): string {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure ? '; Secure' : ''}`;
}

function sameOrigin(request: Request): boolean {
  if (request.method === 'GET' || request.method === 'HEAD') return true;
  const origin = request.headers.get('Origin');
  if (!origin) return true;
  const url = new URL(request.url);
  const host = request.headers.get('Host') ?? url.host;
  const proto = request.headers.get('X-Forwarded-Proto')?.split(',')[0].trim() ?? url.protocol.replace(':', '');
  if (origin === `${proto}://${host}`) return true;
  const localHost = url.hostname === 'localhost' || url.hostname === '127.0.0.1';
  return localHost && /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
}

function clientIp(request: Request): string {
  return request.headers.get('CF-Connecting-IP') ?? request.headers.get('X-Forwarded-For')?.split(',')[0].trim() ?? 'unknown';
}

async function readBody(request: Request): Promise<Record<string, unknown>> {
  const raw = await request.text();
  if (raw.length > MAX_BODY) throw new HttpError(413, 'Request is too large', 'body_too_large');
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('not an object');
    return parsed as Record<string, unknown>;
  } catch {
    throw new HttpError(400, 'Invalid JSON body', 'invalid_json');
  }
}

function str(value: unknown, max: number): string {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function isValidEmail(value: string): boolean {
  return value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
}
function isValidUsername(value: string): boolean {
  return /^[a-zA-Z0-9_]{3,20}$/.test(value);
}
function isValidCode(value: string): boolean {
  return /^SL-\d{6}$/i.test(value.trim());
}

function normalizeAvatar(value: unknown): string | null {
  const avatar = typeof value === 'string' ? value.trim() : '';
  if (!avatar) return '🦋';
  // App-hosted uploaded media URL (cloud-stored profile photo).
  if (avatar.length <= 800 && /^\/api\/media\/[A-Za-z0-9._\-\/]+$/.test(avatar)) return avatar;
  // Allow emoji/small tokens or image data URLs (uploaded/cropped photos).
  if (Array.from(avatar).length <= 8 && !avatar.startsWith('data:') && !avatar.startsWith('/')) return avatar;
  if (
    avatar.length <= MAX_AVATAR &&
    /^data:image\/(png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=\s]+$/.test(avatar)
  ) {
    return avatar.replace(/\s+/g, '');
  }
  return null;
}

async function generateUniqueCode(db: D1Database): Promise<string> {
  for (let i = 0; i < 12; i += 1) {
    const code = `SL-${String(100000 + Math.floor(Math.random() * 900000))}`;
    const exists = await db.prepare('SELECT 1 FROM users WHERE user_code = ?').bind(code).first();
    if (!exists) return code;
  }
  // Extremely unlikely; fallback to time-based suffix uniqueness.
  return `SL-${String(Date.now()).slice(-6)}`;
}

function displayName(first: string, last: string, fallback: string): string {
  const full = [first, last].map((s) => s.trim()).filter(Boolean).join(' ');
  return full || fallback.trim();
}

function isOwnerRow(row: Pick<UserRow, 'email' | 'is_owner'>): boolean {
  return row.email.toLowerCase() === OWNER_EMAIL || Number(row.is_owner || 0) === 1;
}

function isVipRow(row: Pick<UserRow, 'email' | 'is_vip' | 'vip_permanent'>): boolean {
  return Boolean(row.is_vip) || Boolean(row.vip_permanent) || row.email.toLowerCase() === VIP_EMAIL || row.email.toLowerCase() === OWNER_EMAIL;
}
function isOnline(lastSeen: number): boolean {
  return lastSeen > 0 && now() - lastSeen < 45_000;
}
function hexColor(value: string): string {
  const v = value.trim();
  return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(v) ? v : '';
}

function publicUser(row: UserRow) {
  const vip = isVipRow(row);
  const owner = isOwnerRow(row);
  const frame = row.profile_frame || 'none';
  const effect = row.username_effect || 'none';
  const ncolor = row.username_color || '';
  const cu = row.customization_updated_at || row.updated_at || row.created_at;
  return {
    id: row.id,
    userCode: row.user_code,
    name: row.name,
    firstName: row.first_name || '',
    lastName: row.last_name || '',
    username: row.username,
    email: row.email,
    bio: row.bio,
    interests: row.interests,
    goals: row.goals,
    avatar: row.avatar,
    status: row.status,
    authProvider: row.auth_provider || 'local',
    isVip: vip,
    isOwner: owner,
    profileFrame: frame,
    usernameEffect: effect,
    usernameColor: ncolor,
    borderColor: row.border_color || '',
    glowEffect: row.glow_effect || 'none',
    profileTheme: row.profile_theme || 'default',
    selectedFrameId: frame,
    selectedNicknameEffect: effect,
    selectedNicknameColor: ncolor,
    customizationUpdatedAt: new Date(cu).toISOString(),
    coverUrl: row.cover_url || '',
    coverType: row.cover_type || '',
    coverPosX: Number.isFinite(row.cover_pos_x) ? row.cover_pos_x : 50,
    coverPosY: Number.isFinite(row.cover_pos_y) ? row.cover_pos_y : 50,
    coverScale: Number.isFinite(row.cover_scale) ? row.cover_scale : 100,
    bgUrl: row.bg_url || '',
    bgType: row.bg_type || '',
    bgPosX: Number.isFinite(row.bg_pos_x) ? row.bg_pos_x : 50,
    bgPosY: Number.isFinite(row.bg_pos_y) ? row.bg_pos_y : 50,
    bgScale: Number.isFinite(row.bg_scale) ? row.bg_scale : 100,
    bgBlur: Number.isFinite(row.bg_blur) ? row.bg_blur : 0,
    bgOverlay: Number.isFinite(row.bg_overlay) ? row.bg_overlay : 45,
    online: isOnline(row.last_seen_at || 0),
    lastSeenAt: row.last_seen_at ? new Date(row.last_seen_at).toISOString() : null,
    joinedAt: dayISO(row.created_at),
    createdAt: new Date(row.created_at).toISOString(),
    lastLoginAt: row.last_login_at ? new Date(row.last_login_at).toISOString() : null,
  };
}

function publicProfile(row: any) {
  const vip = isVipRow(row as UserRow);
  const owner = isOwnerRow(row as UserRow);
  const frame = row.profile_frame || 'none';
  const effect = row.username_effect || 'none';
  const ncolor = row.username_color || '';
  const cu = (row as any).customization_updated_at || (row as any).updated_at || (row as any).created_at || now();
  return {
    id: row.id,
    userCode: row.user_code,
    name: row.name,
    username: row.username,
    avatar: row.avatar,
    bio: row.bio,
    interests: row.interests,
    isVip: vip,
    isOwner: owner,
    profileFrame: frame,
    usernameEffect: effect,
    usernameColor: ncolor,
    borderColor: row.border_color || '',
    glowEffect: row.glow_effect || 'none',
    profileTheme: row.profile_theme || 'default',
    selectedFrameId: frame,
    selectedNicknameEffect: effect,
    selectedNicknameColor: ncolor,
    customizationUpdatedAt: new Date(cu).toISOString(),
    coverUrl: row.cover_url || '',
    coverType: row.cover_type || '',
    coverPosX: Number.isFinite(row.cover_pos_x) ? row.cover_pos_x : 50,
    coverPosY: Number.isFinite(row.cover_pos_y) ? row.cover_pos_y : 50,
    coverScale: Number.isFinite(row.cover_scale) ? row.cover_scale : 100,
    bgUrl: row.bg_url || '',
    bgType: row.bg_type || '',
    bgPosX: Number.isFinite(row.bg_pos_x) ? row.bg_pos_x : 50,
    bgPosY: Number.isFinite(row.bg_pos_y) ? row.bg_pos_y : 50,
    bgScale: Number.isFinite(row.bg_scale) ? row.bg_scale : 100,
    bgBlur: Number.isFinite(row.bg_blur) ? row.bg_blur : 0,
    bgOverlay: Number.isFinite(row.bg_overlay) ? row.bg_overlay : 45,
    online: isOnline(row.last_seen_at || 0),
    lastSeenAt: row.last_seen_at ? new Date(row.last_seen_at).toISOString() : null,
  };
}

async function logActivity(env: Env, request: Request, userId: string | null, action: string, detail = ''): Promise<void> {
  try {
    await env.DB.prepare('INSERT INTO activity (user_id, action, detail, ip, created_at) VALUES (?, ?, ?, ?, ?)')
      .bind(userId, action, detail.slice(0, 300), clientIp(request), now()).run();
  } catch { /* never block */ }
}

async function addNotification(env: Env, userId: string, type: string, message: string, data: Record<string, unknown> = {}) {
  try {
    await env.DB.prepare(
      'INSERT INTO notifications (id, user_id, type, message, data, read, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)',
    ).bind(crypto.randomUUID(), userId, type, message.slice(0, 300), JSON.stringify(data), now()).run();
  } catch { /* best effort */ }
}

/* ------------------------------------------------------------------ */
/*  Sessions                                                           */
/* ------------------------------------------------------------------ */

async function createSession(env: Env, request: Request, userId: string, days = SESSION_DAYS): Promise<string> {
  const token = randomToken();
  const tokenHash = await sha256(token);
  const created = now();
  await env.DB.prepare(
    'INSERT INTO sessions (token_hash, user_id, created_at, expires_at, user_agent, ip) VALUES (?, ?, ?, ?, ?, ?)',
  ).bind(tokenHash, userId, created, created + days * 86_400_000, (request.headers.get('User-Agent') ?? '').slice(0, 300), clientIp(request)).run();
  return token;
}

async function currentUser(request: Request, env: Env): Promise<UserRow | null> {
  const token = parseCookies(request)[SESSION_COOKIE];
  if (!token) return null;
  const tokenHash = await sha256(token);
  const row = await env.DB.prepare(
    `SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ? LIMIT 1`,
  ).bind(tokenHash, now()).first<UserRow>();
  if (!row) return null;
  if (row.status !== 'active') {
    await env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(row.id).run();
    return null;
  }
  return row;
}

async function createAdminSession(env: Env): Promise<string> {
  const token = randomToken();
  const tokenHash = await sha256(token);
  const created = now();
  await env.DB.prepare('INSERT INTO admin_sessions (token_hash, created_at, expires_at) VALUES (?, ?, ?)')
    .bind(tokenHash, created, created + ADMIN_HOURS * 3_600_000).run();
  return token;
}

async function isAdmin(request: Request, env: Env): Promise<boolean> {
  const token = parseCookies(request)[ADMIN_COOKIE];
  if (token) {
    const tokenHash = await sha256(token);
    const row = await env.DB.prepare('SELECT token_hash FROM admin_sessions WHERE token_hash = ? AND expires_at > ? LIMIT 1')
      .bind(tokenHash, now()).first<{ token_hash: string }>();
    if (row) return true;
  }
  // Permanent owner access: verified owner account session (server-side)
  const user = await currentUser(request, env);
  if (user && isOwnerRow(user)) return true;
  return false;
}

/* ------------------------------------------------------------------ */
/*  Rate limiting                                                      */
/* ------------------------------------------------------------------ */

async function isRateLimited(env: Env, key: string, limit: number, windowMs: number): Promise<boolean> {
  const row = await env.DB.prepare('SELECT count, reset_at FROM auth_attempts WHERE key = ?').bind(key).first<{ count: number; reset_at: number }>();
  if (!row) return false;
  if (row.reset_at <= now()) {
    await env.DB.prepare('DELETE FROM auth_attempts WHERE key = ?').bind(key).run();
    return false;
  }
  return row.count >= limit;
}
async function recordFailure(env: Env, key: string, windowMs: number): Promise<void> {
  const current = now();
  await env.DB.prepare(
    `INSERT INTO auth_attempts (key, count, reset_at) VALUES (?, 1, ?)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN auth_attempts.reset_at <= ? THEN 1 ELSE auth_attempts.count + 1 END,
       reset_at = CASE WHEN auth_attempts.reset_at <= ? THEN ? ELSE auth_attempts.reset_at END`,
  ).bind(key, current + windowMs, current, current, current + windowMs).run();
}
async function clearFailures(env: Env, key: string): Promise<void> {
  await env.DB.prepare('DELETE FROM auth_attempts WHERE key = ?').bind(key).run();
}

/* ------------------------------------------------------------------ */
/*  Workspace                                                          */
/* ------------------------------------------------------------------ */

function sanitizeWorkspace(input: unknown) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new HttpError(400, 'Invalid workspace data', 'invalid_workspace');
  const data = input as Record<string, unknown>;
  const array = (value: unknown, max: number) => (Array.isArray(value) ? value.slice(0, max) : []);
  const settingsRaw = data.settings && typeof data.settings === 'object' ? (data.settings as Record<string, unknown>) : {};
  const settings = {
    theme: settingsRaw.theme === 'light' ? 'light' : 'dark',
    language: ['uz', 'ru', 'en'].includes(String(settingsRaw.language)) ? String(settingsRaw.language) : 'uz',
    notifications: Boolean(settingsRaw.notifications),
    dailySummary: Boolean(settingsRaw.dailySummary),
    sound: Boolean(settingsRaw.sound),
    reminderLead: [5, 10, 15, 30, 60].includes(Number(settingsRaw.reminderLead)) ? Number(settingsRaw.reminderLead) : 15,
    aiKey: '',
    aiBase: str(settingsRaw.aiBase, 300) || 'https://api.openai.com/v1',
    aiModel: str(settingsRaw.aiModel, 100) || 'gpt-4o-mini',
  };
  const workspace = {
    tasks: array(data.tasks, 5000),
    events: array(data.events, 3000),
    goals: array(data.goals, 1000),
    notes: array(data.notes, 3000),
    messages: array(data.messages, 1000),
    settings,
  };
  const serialized = JSON.stringify(workspace);
  if (serialized.length > MAX_WORKSPACE) throw new HttpError(413, 'Workspace is too large', 'workspace_too_large');
  return serialized;
}

/* ------------------------------------------------------------------ */
/*  Google auth                                                        */
/* ------------------------------------------------------------------ */

interface GoogleTokenInfo {
  aud?: string; sub?: string; email?: string; email_verified?: string; name?: string; given_name?: string; family_name?: string; picture?: string;
}

async function verifyGoogleCredential(env: Env, credential: string): Promise<GoogleTokenInfo> {
  const res = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
  if (!res.ok) throw new HttpError(401, 'Google sign-in could not be verified', 'google_invalid');
  const info = (await res.json()) as GoogleTokenInfo;
  if (!info.sub || !info.email) throw new HttpError(401, 'Google account information is incomplete', 'google_incomplete');
  if (info.email_verified !== 'true') throw new HttpError(401, 'Google email is not verified', 'google_email_unverified');
  if (env.GOOGLE_CLIENT_ID) {
    const audiences = env.GOOGLE_CLIENT_ID.split(',').map((s) => s.trim()).filter(Boolean);
    if (audiences.length && !audiences.includes(info.aud ?? '')) {
      throw new HttpError(401, 'Google sign-in is not configured for this app', 'google_audience');
    }
  }
  return info;
}

function suggestUsername(base: string): string {
  const clean = base.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 16) || 'user';
  return clean.length >= 3 ? clean : `${clean}ai`;
}

/* ------------------------------------------------------------------ */
/*  Auth routes                                                        */
/* ------------------------------------------------------------------ */

async function register(request: Request, env: Env): Promise<Response> {
  const body = await readBody(request);
  const firstName = str(body.firstName, 40);
  const lastName = str(body.lastName, 40);
  const name = str(body.name, 80) || displayName(firstName, lastName, '');
  const username = str(body.username, 20).toLowerCase();
  const email = str(body.email, 254).toLowerCase();
  const password = typeof body.password === 'string' ? body.password : '';
  const bio = str(body.bio, 500);
  const interests = str(body.interests, 400);
  const goals = str(body.goals, 600);
  const avatar = normalizeAvatar(body.avatar);

  if (name.length < 2) throw new HttpError(422, 'Please enter your full name', 'name_invalid');
  if (!isValidUsername(username)) throw new HttpError(422, 'Username must be 3–20 letters, numbers or underscores', 'username_invalid');
  if (!isValidEmail(email)) throw new HttpError(422, 'Please enter a valid email', 'email_invalid');
  if (password.length < 8 || password.length > 128) throw new HttpError(422, 'Password must be at least 8 characters', 'password_short');
  if (avatar === null) throw new HttpError(422, 'Invalid profile picture', 'avatar_invalid');

  const existing = await env.DB.prepare('SELECT username, email FROM users WHERE username = ? OR email = ? LIMIT 1')
    .bind(username, email).first<{ username: string; email: string }>();
  if (existing) {
    if (existing.email.toLowerCase() === email) throw new HttpError(409, 'An account with this email already exists', 'email_taken');
    throw new HttpError(409, 'This username is already taken', 'username_taken');
  }

  const id = crypto.randomUUID();
  const userCode = await generateUniqueCode(env.DB);
  const timestamp = now();
  const passwordHash = await hashPassword(password);
  const isVip = email.toLowerCase() === VIP_EMAIL ? 1 : 0;
  const vipPermanent = isVip;

  const isOwner = email.toLowerCase() === OWNER_EMAIL ? 1 : 0;
  await env.DB.prepare(
    `INSERT INTO users
      (id, user_code, name, first_name, last_name, username, email, password_hash, bio, interests, goals, avatar, status, auth_provider, google_sub, is_vip, vip_permanent, profile_frame, username_effect, username_color, border_color, glow_effect, profile_theme, customization_updated_at, is_owner, last_seen_at, typing_to, typing_at, created_at, updated_at, last_login_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 'local', '', ?, ?, 'none', 'none', '', '', 'none', 'default', 0, ?, 0, '', 0, ?, ?, ?)`,
  ).bind(id, userCode, name, firstName, lastName, username, email, passwordHash, bio, interests, goals, avatar, isVip, vipPermanent, isOwner, timestamp, timestamp, timestamp).run();

  const token = await createSession(env, request, id);
  await logActivity(env, request, id, 'register', 'Account created');
  await addNotification(env, id, 'welcome', `Welcome to SMART LIFE AI, ${name.split(' ')[0] || 'there'}! Your unique ID is ${userCode}.`, { userCode });

  const row = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(id).first<UserRow>();
  return json({ user: row ? publicUser(row) : null }, 201, { 'Set-Cookie': cookie(SESSION_COOKIE, token, SESSION_DAYS * 86_400, isSecure(request)) });
}

async function login(request: Request, env: Env): Promise<Response> {
  const body = await readBody(request);
  const identifier = str(body.identifier, 254).toLowerCase();
  const password = typeof body.password === 'string' ? body.password : '';
  if (!identifier || !password) throw new HttpError(422, 'Enter your email/username and password', 'credentials_required');

  const attemptKey = `login:${identifier}`;
  if (await isRateLimited(env, attemptKey, 8, 15 * 60_000)) throw new HttpError(429, 'Too many attempts. Try again in 15 minutes.', 'rate_limited');

  const row = await env.DB.prepare('SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1')
    .bind(identifier, identifier).first<UserRow>();
  const valid = row && row.password_hash ? await verifyPassword(password, row.password_hash) : false;
  if (!row || !valid) {
    await recordFailure(env, attemptKey, 15 * 60_000);
    throw new HttpError(401, 'Incorrect email/username or password', 'invalid_credentials');
  }
  if (row.status !== 'active') throw new HttpError(403, 'This account has been suspended by the owner', 'account_suspended');

  await clearFailures(env, attemptKey);
  await env.DB.prepare('DELETE FROM sessions WHERE expires_at <= ?').bind(now()).run();
  const isOwnerEmail = row.email.toLowerCase() === OWNER_EMAIL;
  const vipNow = isOwnerEmail ? 1 : (row.is_vip ? 1 : 0);
  const vipPerm = isOwnerEmail ? 1 : (row.vip_permanent ? 1 : 0);
  const ownerNow = isOwnerEmail ? 1 : (row.is_owner ? 1 : 0);
  await env.DB.prepare('UPDATE users SET last_login_at = ?, updated_at = ?, last_seen_at = ?, is_vip = ?, vip_permanent = ?, is_owner = ? WHERE id = ?')
    .bind(now(), now(), now(), vipNow, vipPerm, ownerNow, row.id).run();
  const token = await createSession(env, request, row.id);
  await logActivity(env, request, row.id, 'login', 'Signed in');

  const fresh = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(row.id).first<UserRow>();
  return json({ user: fresh ? publicUser(fresh) : null }, 200, { 'Set-Cookie': cookie(SESSION_COOKIE, token, SESSION_DAYS * 86_400, isSecure(request)) });
}

async function loginWithGoogle(request: Request, env: Env): Promise<Response> {
  const body = await readBody(request);
  const credential = typeof body.credential === 'string' ? body.credential : '';
  if (!credential) throw new HttpError(422, 'Google credential is missing', 'google_missing');

  const info = await verifyGoogleCredential(env, credential);
  const email = (info.email ?? '').toLowerCase();
  const sub = info.sub ?? '';
  let row = await env.DB.prepare('SELECT * FROM users WHERE google_sub = ? OR email = ? LIMIT 1')
    .bind(sub, email).first<UserRow>();

  const timestamp = now();
  if (row) {
    if (row.status !== 'active') throw new HttpError(403, 'This account has been suspended by the owner', 'account_suspended');
    // Link Google to existing email account and keep user-edited profile fields.
    const firstName = row.first_name || str(info.given_name, 40);
    const lastName = row.last_name || str(info.family_name, 40);
    const name = row.name && row.name.trim() ? row.name : displayName(firstName, lastName, str(info.name, 80) || email.split('@')[0]);
    const avatar = row.avatar && row.avatar !== '🦋' ? row.avatar : (str(info.picture, 500) || row.avatar);
    const ownerNow = email === OWNER_EMAIL ? 1 : (row.is_owner ? 1 : 0);
    const vipNow = email === OWNER_EMAIL ? 1 : (row.is_vip ? 1 : 0);
    const vipPerm = email === OWNER_EMAIL ? 1 : (row.vip_permanent ? 1 : 0);
    await env.DB.prepare(
      `UPDATE users SET google_sub = ?, auth_provider = CASE WHEN auth_provider = 'local' THEN 'google' ELSE auth_provider END,
        first_name = ?, last_name = ?, name = ?, avatar = ?, last_login_at = ?, updated_at = ?, last_seen_at = ?, is_vip = ?, vip_permanent = ?, is_owner = ? WHERE id = ?`,
    ).bind(sub || row.google_sub, firstName, lastName, name, avatar, timestamp, timestamp, timestamp, vipNow, vipPerm, ownerNow, row.id).run();
    row = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(row.id).first<UserRow>();
  } else {
    // Create a new account from Google profile.
    const firstName = str(info.given_name, 40);
    const lastName = str(info.family_name, 40);
    const name = displayName(firstName, lastName, str(info.name, 80) || email.split('@')[0]);
    let base = suggestUsername(email.split('@')[0] || firstName || 'user');
    let username = base;
    for (let i = 0; i < 10; i += 1) {
      const exists = await env.DB.prepare('SELECT 1 FROM users WHERE username = ?').bind(username).first();
      if (!exists) break;
      username = `${base.slice(0, 14)}${Math.floor(100 + Math.random() * 900)}`;
    }
    const id = crypto.randomUUID();
    const userCode = await generateUniqueCode(env.DB);
    const avatar = str(info.picture, 500) || '🦋';
    const isOwner = email === OWNER_EMAIL ? 1 : 0;
    const isVip = isOwner ? 1 : 0;
    const vipPermanent = isVip;
    await env.DB.prepare(
      `INSERT INTO users (id, user_code, name, first_name, last_name, username, email, password_hash, bio, interests, goals, avatar, status, auth_provider, google_sub, is_vip, vip_permanent, profile_frame, username_effect, username_color, border_color, glow_effect, profile_theme, customization_updated_at, is_owner, last_seen_at, typing_to, typing_at, created_at, updated_at, last_login_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, '', '', '', '', ?, 'active', 'google', ?, ?, ?, 'none', 'none', '', '', 'none', 'default', 0, ?, 0, '', 0, ?, ?, ?)`,
    ).bind(id, userCode, name, firstName, lastName, username, email, avatar, sub, isVip, vipPermanent, isOwner, timestamp, timestamp, timestamp).run();
    row = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(id).first<UserRow>();
    if (row) await addNotification(env, row.id, 'welcome', `Welcome to SMART LIFE AI, ${name.split(' ')[0] || 'there'}! Your unique ID is ${userCode}.`, { userCode });
    await logActivity(env, request, id, 'register_google', 'Account created via Google');
  }

  if (!row) throw new HttpError(500, 'Could not complete Google sign-in', 'google_failed');
  await env.DB.prepare('DELETE FROM sessions WHERE expires_at <= ?').bind(now()).run();
  const token = await createSession(env, request, row.id);
  await logActivity(env, request, row.id, 'login_google', 'Signed in with Google');
  return json({ user: publicUser(row) }, 200, { 'Set-Cookie': cookie(SESSION_COOKIE, token, SESSION_DAYS * 86_400, isSecure(request)) });
}

async function logout(request: Request, env: Env): Promise<Response> {
  const token = parseCookies(request)[SESSION_COOKIE];
  if (token) {
    const tokenHash = await sha256(token);
    const row = await env.DB.prepare('SELECT user_id FROM sessions WHERE token_hash = ?').bind(tokenHash).first<{ user_id: string }>();
    await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(tokenHash).run();
    if (row) await logActivity(env, request, row.user_id, 'logout', 'Signed out');
  }
  return json({ ok: true }, 200, { 'Set-Cookie': cookie(SESSION_COOKIE, '', 0, isSecure(request)) });
}

async function me(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  return json({ user: publicUser(user) });
}

async function updateProfile(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);

  const firstName = body.firstName === undefined ? user.first_name : str(body.firstName, 40);
  const lastName = body.lastName === undefined ? user.last_name : str(body.lastName, 40);
  const name = body.name !== undefined
    ? str(body.name, 80)
    : (body.firstName !== undefined || body.lastName !== undefined)
      ? displayName(firstName, lastName, user.name)
      : user.name;
  const username = body.username === undefined ? user.username : str(body.username, 20).toLowerCase();
  const email = body.email === undefined ? user.email : str(body.email, 254).toLowerCase();
  const bio = body.bio === undefined ? user.bio : str(body.bio, 500);
  const interests = body.interests === undefined ? user.interests : str(body.interests, 400);
  const goals = body.goals === undefined ? user.goals : str(body.goals, 600);
  const avatar = body.avatar === undefined ? user.avatar : normalizeAvatar(body.avatar);

  // Profile appearance (server-side VIP enforcement)
  const vip = isVipRow(user);
  const owner = isOwnerRow(user);
  const profileFrame = body.profileFrame !== undefined ? str(body.profileFrame, 40) : body.selectedFrameId !== undefined ? str(body.selectedFrameId, 40) : (user.profile_frame || 'none');
  const usernameEffect = body.usernameEffect !== undefined ? str(body.usernameEffect, 40) : body.selectedNicknameEffect !== undefined ? str(body.selectedNicknameEffect, 40) : (user.username_effect || 'none');
  const usernameColor = body.usernameColor !== undefined ? hexColor(String(body.usernameColor ?? '')) : body.selectedNicknameColor !== undefined ? hexColor(String(body.selectedNicknameColor ?? '')) : (user.username_color || '');
  const borderColor = body.borderColor === undefined ? (user.border_color || '') : hexColor(String(body.borderColor ?? ''));
  const glowEffect = body.glowEffect === undefined ? (user.glow_effect || 'none') : str(body.glowEffect, 40);
  const profileTheme = body.profileTheme === undefined ? (user.profile_theme || 'default') : str(body.profileTheme, 40);

  if (!(FRAME_STYLES as readonly string[]).includes(profileFrame)) throw new HttpError(422, 'Invalid profile frame', 'invalid_frame');
  if (!(USERNAME_EFFECTS as readonly string[]).includes(usernameEffect)) throw new HttpError(422, 'Invalid username effect', 'invalid_username_effect');
  if (!(GLOW_EFFECTS as readonly string[]).includes(glowEffect)) throw new HttpError(422, 'Invalid glow effect', 'invalid_glow');
  if (!(PROFILE_THEMES as readonly string[]).includes(profileTheme)) throw new HttpError(422, 'Invalid profile theme', 'invalid_theme');
  if (!vip && VIP_ONLY_FRAMES.has(profileFrame)) throw new HttpError(403, 'This frame is available to VIP members only', 'vip_required');
  if (!vip && VIP_ONLY_EFFECTS.has(usernameEffect)) throw new HttpError(403, 'This username effect is available to VIP members only', 'vip_required');
  if (!vip && profileTheme !== 'default' && !['default', 'violet', 'ocean'].includes(profileTheme)) {
    // allow a few themes for all, reserve special ones for VIP
  }

  if (name.length < 2) throw new HttpError(422, 'Please enter your full name', 'name_invalid');
  if (!isValidUsername(username)) throw new HttpError(422, 'Username must be 3–20 letters, numbers or underscores', 'username_invalid');
  if (!isValidEmail(email)) throw new HttpError(422, 'Please enter a valid email', 'email_invalid');
  if (avatar === null) throw new HttpError(422, 'Invalid profile picture', 'avatar_invalid');

  const conflict = await env.DB.prepare('SELECT id, email, username FROM users WHERE (email = ? OR username = ?) AND id != ? LIMIT 1')
    .bind(email, username, user.id).first<{ id: string; email: string; username: string }>();
  if (conflict) {
    if (conflict.email.toLowerCase() === email) throw new HttpError(409, 'This email is already in use', 'email_taken');
    throw new HttpError(409, 'This username is already in use', 'username_taken');
  }

  let passwordHash = user.password_hash;
  let passwordChanged = false;
  const newPassword = typeof body.newPassword === 'string' ? body.newPassword : '';
  if (newPassword) {
    if (user.password_hash) {
      const currentPassword = typeof body.currentPassword === 'string' ? body.currentPassword : '';
      if (!(await verifyPassword(currentPassword, user.password_hash))) {
        throw new HttpError(422, 'Your current password is incorrect', 'password_incorrect');
      }
    }
    if (newPassword.length < 8 || newPassword.length > 128) throw new HttpError(422, 'New password must be at least 8 characters', 'password_short');
    passwordHash = await hashPassword(newPassword);
    passwordChanged = true;
  }

  // Ensure designated owner/VIP email keeps privileges (cannot be downgraded by self-edit path)
  const vipNow = email.toLowerCase() === OWNER_EMAIL ? 1 : (user.is_vip ? 1 : 0);
  const vipPerm = email.toLowerCase() === OWNER_EMAIL ? 1 : (user.vip_permanent ? 1 : 0);
  const ownerNow = email.toLowerCase() === OWNER_EMAIL ? 1 : (isOwnerRow(user) ? 1 : 0);
  const clamp = (v: any, min: number, max: number, def: number) => { const n = Number(v); return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.round(n))) : def; };
  let coverUrl = body.coverUrl !== undefined ? str(body.coverUrl, 800) : (user.cover_url || '');
  let coverType = body.coverType !== undefined ? (str(body.coverType, 20) || '') : (user.cover_type || '');
  if (coverType && coverType !== 'image' && coverType !== 'video') throw new HttpError(422, 'Invalid cover media type', 'invalid_media_type');
  if (!coverUrl) coverType = '';
  const coverPosX = body.coverPosX !== undefined ? clamp(body.coverPosX, 0, 100, 50) : (Number.isFinite(user.cover_pos_x) ? user.cover_pos_x : 50);
  const coverPosY = body.coverPosY !== undefined ? clamp(body.coverPosY, 0, 100, 50) : (Number.isFinite(user.cover_pos_y) ? user.cover_pos_y : 50);
  const coverScale = body.coverScale !== undefined ? clamp(body.coverScale, 50, 300, 100) : (Number.isFinite(user.cover_scale) ? user.cover_scale : 100);
  let bgUrl = body.bgUrl !== undefined ? str(body.bgUrl, 800) : (user.bg_url || '');
  let bgType = body.bgType !== undefined ? (str(body.bgType, 20) || '') : (user.bg_type || '');
  if (bgType && bgType !== 'image' && bgType !== 'video') throw new HttpError(422, 'Invalid background media type', 'invalid_media_type');
  if (!bgUrl) bgType = '';
  const bgPosX = body.bgPosX !== undefined ? clamp(body.bgPosX, 0, 100, 50) : (Number.isFinite(user.bg_pos_x) ? user.bg_pos_x : 50);
  const bgPosY = body.bgPosY !== undefined ? clamp(body.bgPosY, 0, 100, 50) : (Number.isFinite(user.bg_pos_y) ? user.bg_pos_y : 50);
  const bgScale = body.bgScale !== undefined ? clamp(body.bgScale, 50, 300, 100) : (Number.isFinite(user.bg_scale) ? user.bg_scale : 100);
  const bgBlur = body.bgBlur !== undefined ? clamp(body.bgBlur, 0, 40, 0) : (Number.isFinite(user.bg_blur) ? user.bg_blur : 0);
  const bgOverlay = body.bgOverlay !== undefined ? clamp(body.bgOverlay, 0, 90, 45) : (Number.isFinite(user.bg_overlay) ? user.bg_overlay : 45);

  const settingCoverMedia = coverUrl && coverUrl !== (user.cover_url || '');
  const settingBgMedia = bgUrl && bgUrl !== (user.bg_url || '');
  if (!vip && (settingCoverMedia || settingBgMedia)) throw new HttpError(403, 'Custom cover and background media are available to VIP members only', 'vip_required');
  const origin = new URL(request.url).origin;
  const mediaOk = (u: string) => !u || /^\/api\/media\//.test(u) || u.startsWith(origin + '/api/media/');
  if (!mediaOk(coverUrl) || !mediaOk(bgUrl)) throw new HttpError(422, 'Invalid media URL', 'invalid_media_url');

  const customizationChanged = profileFrame !== (user.profile_frame || 'none') || usernameEffect !== (user.username_effect || 'none') || usernameColor !== (user.username_color || '') || borderColor !== (user.border_color || '') || glowEffect !== (user.glow_effect || 'none') || profileTheme !== (user.profile_theme || 'default') || coverUrl !== (user.cover_url || '') || coverType !== (user.cover_type || '') || coverPosX !== (Number.isFinite(user.cover_pos_x)?user.cover_pos_x:50) || coverPosY !== (Number.isFinite(user.cover_pos_y)?user.cover_pos_y:50) || coverScale !== (Number.isFinite(user.cover_scale)?user.cover_scale:100) || bgUrl !== (user.bg_url || '') || bgType !== (user.bg_type || '') || bgPosX !== (Number.isFinite(user.bg_pos_x)?user.bg_pos_x:50) || bgPosY !== (Number.isFinite(user.bg_pos_y)?user.bg_pos_y:50) || bgScale !== (Number.isFinite(user.bg_scale)?user.bg_scale:100) || bgBlur !== (Number.isFinite(user.bg_blur)?user.bg_blur:0) || bgOverlay !== (Number.isFinite(user.bg_overlay)?user.bg_overlay:45);
  const customizationUpdatedAt = customizationChanged ? now() : (user.customization_updated_at || 0);

  await env.DB.prepare(
    `UPDATE users SET name = ?, first_name = ?, last_name = ?, username = ?, email = ?, bio = ?, interests = ?, goals = ?,
      avatar = ?, password_hash = ?, profile_frame = ?, username_effect = ?, username_color = ?, border_color = ?, glow_effect = ?, profile_theme = ?,
      customization_updated_at = ?, is_owner = ?, is_vip = ?, vip_permanent = ?,
      cover_url = ?, cover_type = ?, cover_pos_x = ?, cover_pos_y = ?, cover_scale = ?,
      bg_url = ?, bg_type = ?, bg_pos_x = ?, bg_pos_y = ?, bg_scale = ?, bg_blur = ?, bg_overlay = ?,
      updated_at = ? WHERE id = ?`,
  ).bind(name, firstName, lastName, username, email, bio, interests, goals, avatar, passwordHash, profileFrame, usernameEffect, usernameColor, borderColor, glowEffect, profileTheme, customizationUpdatedAt, ownerNow, vipNow, vipPerm, coverUrl, coverType, coverPosX, coverPosY, coverScale, bgUrl, bgType, bgPosX, bgPosY, bgScale, bgBlur, bgOverlay, now(), user.id).run();

  await logActivity(env, request, user.id, passwordChanged ? 'password_changed' : 'profile_updated', passwordChanged ? 'Password changed' : 'Profile/appearance updated');
  const row = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(user.id).first<UserRow>();
  if (!row) throw new HttpError(404, 'Account not found', 'not_found');
  return json({ user: publicUser(row) });
}

async function deleteAccount(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const confirm = str(body.confirm, 40);
  if (confirm !== 'DELETE') throw new HttpError(422, 'Please confirm account deletion', 'confirm_required');

  // Verify identity: local accounts must provide password; Google-only accounts must re-auth (or provide nothing if no password set).
  if (user.password_hash) {
    const password = typeof body.password === 'string' ? body.password : '';
    if (!(await verifyPassword(password, user.password_hash))) {
      throw new HttpError(401, 'Incorrect password', 'invalid_credentials');
    }
  }

  // Remove chat data and social data for this user
  const convs = await env.DB.prepare('SELECT id FROM conversations WHERE user_a = ? OR user_b = ?').bind(user.id, user.id).all<{ id: string }>();
  const convIds = (convs.results ?? []).map((c) => c.id);
  const stmts: D1PreparedStatement[] = [
    env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(user.id),
    env.DB.prepare('DELETE FROM workspaces WHERE user_id = ?').bind(user.id),
    env.DB.prepare('DELETE FROM notifications WHERE user_id = ?').bind(user.id),
    env.DB.prepare('DELETE FROM friend_requests WHERE from_user_id = ? OR to_user_id = ?').bind(user.id, user.id),
    env.DB.prepare('DELETE FROM friendships WHERE user_a = ? OR user_b = ?').bind(user.id, user.id),
    env.DB.prepare('DELETE FROM conversations WHERE user_a = ? OR user_b = ?').bind(user.id, user.id),
    env.DB.prepare('DELETE FROM message_reads WHERE user_id = ?').bind(user.id),
    env.DB.prepare('DELETE FROM blocks WHERE blocker_id = ? OR blocked_id = ?').bind(user.id, user.id),
    env.DB.prepare('DELETE FROM reports WHERE reporter_id = ? OR reported_id = ?').bind(user.id, user.id),
  ];
  for (const cid of convIds) {
    stmts.push(env.DB.prepare('DELETE FROM chat_messages WHERE conversation_id = ?').bind(cid));
    stmts.push(env.DB.prepare('DELETE FROM message_reads WHERE conversation_id = ?').bind(cid));
  }
  stmts.push(env.DB.prepare('DELETE FROM users WHERE id = ?').bind(user.id));
  // D1 batch has limits; chunk if needed
  for (let i = 0; i < stmts.length; i += 50) await env.DB.batch(stmts.slice(i, i + 50));
  await logActivity(env, request, null, 'account_deleted', `Account ${user.user_code} deleted`);
  return json({ ok: true }, 200, { 'Set-Cookie': cookie(SESSION_COOKIE, '', 0, isSecure(request)) });
}

/* ------------------------------------------------------------------ */
/*  Workspace routes                                                   */
/* ------------------------------------------------------------------ */

async function getWorkspace(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const row = await env.DB.prepare('SELECT data, updated_at FROM workspaces WHERE user_id = ?').bind(user.id).first<{ data: string; updated_at: number }>();
  if (!row) return json({ workspace: null, updatedAt: null });
  try { return json({ workspace: JSON.parse(row.data), updatedAt: new Date(row.updated_at).toISOString() }); }
  catch { return json({ workspace: null, updatedAt: null }); }
}

async function saveWorkspace(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const serialized = sanitizeWorkspace(body.workspace ?? body);
  const timestamp = now();
  await env.DB.prepare(
    `INSERT INTO workspaces (user_id, data, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`,
  ).bind(user.id, serialized, timestamp).run();
  return json({ ok: true, updatedAt: new Date(timestamp).toISOString() });
}

/* ------------------------------------------------------------------ */
/*  Friends & notifications                                            */
/* ------------------------------------------------------------------ */

function pair(a: string, b: string): [string, string] { return a < b ? [a, b] : [b, a]; }

async function findUserByCode(env: Env, code: string): Promise<UserRow | null> {
  return env.DB.prepare('SELECT * FROM users WHERE UPPER(user_code) = UPPER(?) LIMIT 1').bind(code.trim()).first<UserRow>();
}

async function friendsSearch(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const url = new URL(request.url);
  const code = (url.searchParams.get('code') ?? '').trim().toUpperCase();
  if (!isValidCode(code)) return json({ user: null });
  const found = await findUserByCode(env, code);
  if (!found || found.status !== 'active') return json({ user: null });
  if (found.id === user.id) return json({ user: publicProfile(found), relation: 'self' });
  const [a, b] = pair(user.id, found.id);
  const friendship = await env.DB.prepare('SELECT id FROM friendships WHERE user_a = ? AND user_b = ?').bind(a, b).first();
  if (friendship) return json({ user: publicProfile(found), relation: 'friends' });
  const outgoing = await env.DB.prepare("SELECT id FROM friend_requests WHERE from_user_id = ? AND to_user_id = ? AND status = 'pending'").bind(user.id, found.id).first();
  if (outgoing) return json({ user: publicProfile(found), relation: 'outgoing' });
  const incoming = await env.DB.prepare("SELECT id FROM friend_requests WHERE from_user_id = ? AND to_user_id = ? AND status = 'pending'").bind(found.id, user.id).first();
  if (incoming) return json({ user: publicProfile(found), relation: 'incoming' });
  return json({ user: publicProfile(found), relation: 'none' });
}

async function friendsRequest(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const code = str(body.code, 20).toUpperCase();
  if (!isValidCode(code)) throw new HttpError(422, 'Enter a valid SMART LIFE ID (SL-123456)', 'invalid_code');
  const target = await findUserByCode(env, code);
  if (!target || target.status !== 'active') throw new HttpError(404, 'No user found with this ID', 'user_not_found');
  if (target.id === user.id) throw new HttpError(400, 'You cannot send a friend request to yourself', 'self_request');

  const [a, b] = pair(user.id, target.id);
  const friendship = await env.DB.prepare('SELECT id FROM friendships WHERE user_a = ? AND user_b = ?').bind(a, b).first();
  if (friendship) throw new HttpError(409, 'You are already friends', 'already_friends');

  const existing = await env.DB.prepare(
    "SELECT id, from_user_id, status FROM friend_requests WHERE (from_user_id = ? AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = ?)",
  ).bind(user.id, target.id, target.id, user.id).first<{ id: string; from_user_id: string; status: string }>();
  if (existing && existing.status === 'pending') {
    if (existing.from_user_id === user.id) throw new HttpError(409, 'Friend request already sent', 'duplicate_request');
    // They already requested us — accept automatically.
    await env.DB.batch([
      env.DB.prepare("UPDATE friend_requests SET status = 'accepted', updated_at = ? WHERE id = ?").bind(now(), existing.id),
      env.DB.prepare('INSERT OR IGNORE INTO friendships (id, user_a, user_b, created_at) VALUES (?, ?, ?, ?)').bind(crypto.randomUUID(), a, b, now()),
    ]);
    await addNotification(env, target.id, 'friend_accepted', `${user.name} accepted your friend request.`, { fromId: user.id, fromCode: user.user_code });
    await addNotification(env, user.id, 'friend_accepted', `You and ${target.name} are now friends.`, { fromId: target.id, fromCode: target.user_code });
    return json({ ok: true, status: 'friends' });
  }

  // Upsert: allow re-sending if previously rejected/cancelled.
  const reqId = crypto.randomUUID();
  await env.DB.prepare(
    `INSERT INTO friend_requests (id, from_user_id, to_user_id, status, created_at, updated_at) VALUES (?, ?, ?, 'pending', ?, ?)
     ON CONFLICT(from_user_id, to_user_id) DO UPDATE SET status = 'pending', updated_at = excluded.updated_at`,
  ).bind(reqId, user.id, target.id, now(), now()).run();
  await addNotification(env, target.id, 'friend_request', `${user.name} (${user.user_code}) sent you a friend request.`, { requestId: reqId, fromId: user.id, fromCode: user.user_code, fromName: user.name });
  await logActivity(env, request, user.id, 'friend_request', `Sent request to ${target.user_code}`);
  return json({ ok: true, status: 'outgoing' }, 201);
}

async function friendsRespond(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const requestId = str(body.requestId, 64);
  const action = str(body.action, 20);
  if (!requestId || !['accept', 'reject'].includes(action)) throw new HttpError(422, 'Invalid request', 'invalid_request');

  const req = await env.DB.prepare("SELECT * FROM friend_requests WHERE id = ? AND to_user_id = ? AND status = 'pending'")
    .bind(requestId, user.id).first<{ id: string; from_user_id: string; to_user_id: string }>();
  if (!req) throw new HttpError(404, 'Friend request not found', 'not_found');

  if (action === 'accept') {
    const [a, b] = pair(req.from_user_id, req.to_user_id);
    await env.DB.batch([
      env.DB.prepare("UPDATE friend_requests SET status = 'accepted', updated_at = ? WHERE id = ?").bind(now(), requestId),
      env.DB.prepare('INSERT OR IGNORE INTO friendships (id, user_a, user_b, created_at) VALUES (?, ?, ?, ?)').bind(crypto.randomUUID(), a, b, now()),
    ]);
    await addNotification(env, req.from_user_id, 'friend_accepted', `${user.name} accepted your friend request.`, { fromId: user.id, fromCode: user.user_code });
  } else {
    await env.DB.prepare("UPDATE friend_requests SET status = 'rejected', updated_at = ? WHERE id = ?").bind(now(), requestId).run();
  }
  return json({ ok: true });
}

async function friendsRemove(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const friendId = str(body.friendId, 64);
  if (!friendId) throw new HttpError(422, 'Missing friend', 'invalid_request');
  const [a, b] = pair(user.id, friendId);
  await env.DB.batch([
    env.DB.prepare('DELETE FROM friendships WHERE user_a = ? AND user_b = ?').bind(a, b),
    env.DB.prepare("DELETE FROM friend_requests WHERE (from_user_id = ? AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = ?)").bind(user.id, friendId, friendId, user.id),
  ]);
  return json({ ok: true });
}

async function friendsList(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');

  const friends = await env.DB.prepare(
    `SELECT u.id, u.user_code, u.name, u.username, u.avatar, u.bio, u.interests, u.email, u.is_vip, u.vip_permanent,
            u.profile_frame, u.username_effect, u.username_color, u.border_color, u.glow_effect, u.profile_theme, u.customization_updated_at, u.is_owner, u.updated_at, u.created_at, u.last_seen_at, f.created_at
     FROM friendships f JOIN users u ON u.id = CASE WHEN f.user_a = ? THEN f.user_b ELSE f.user_a END
     WHERE f.user_a = ? OR f.user_b = ? ORDER BY f.created_at DESC`,
  ).bind(user.id, user.id, user.id).all<any>();

  const incoming = await env.DB.prepare(
    `SELECT r.id as request_id, u.id, u.user_code, u.name, u.username, u.avatar, u.email, u.is_vip, u.vip_permanent,
            u.profile_frame, u.username_effect, u.username_color, u.border_color, u.glow_effect, u.profile_theme, u.customization_updated_at, u.is_owner, u.updated_at, u.created_at, u.last_seen_at, r.created_at
     FROM friend_requests r JOIN users u ON u.id = r.from_user_id
     WHERE r.to_user_id = ? AND r.status = 'pending' ORDER BY r.created_at DESC`,
  ).bind(user.id).all<any>();

  const outgoing = await env.DB.prepare(
    `SELECT r.id as request_id, u.id, u.user_code, u.name, u.username, u.avatar, u.email, u.is_vip, u.vip_permanent,
            u.profile_frame, u.username_effect, u.username_color, u.border_color, u.glow_effect, u.profile_theme, u.customization_updated_at, u.is_owner, u.updated_at, u.created_at, u.last_seen_at, r.created_at
     FROM friend_requests r JOIN users u ON u.id = r.to_user_id
     WHERE r.from_user_id = ? AND r.status = 'pending' ORDER BY r.created_at DESC`,
  ).bind(user.id).all<any>();

  const mapP = (r: any) => {
    const vip = isVipRow({ email: r.email || '', is_vip: r.is_vip || 0, vip_permanent: r.vip_permanent || 0 } as any);
    const owner = isOwnerRow({ email: r.email || '', is_owner: r.is_owner || 0 } as any);
    const cu = r.customization_updated_at || r.updated_at || r.created_at || now();
    return {
      id: r.id, userCode: r.user_code, name: r.name, username: r.username, avatar: r.avatar, bio: r.bio ?? '', interests: r.interests ?? '',
      isVip: vip, isOwner: owner,
      profileFrame: r.profile_frame || 'none', usernameEffect: r.username_effect || 'none', usernameColor: r.username_color || '',
      borderColor: r.border_color || '', glowEffect: r.glow_effect || 'none', profileTheme: r.profile_theme || 'default',
      selectedFrameId: r.profile_frame || 'none', selectedNicknameEffect: r.username_effect || 'none', selectedNicknameColor: r.username_color || '', customizationUpdatedAt: new Date(cu).toISOString(),
      online: isOnline(r.last_seen_at || 0), lastSeenAt: r.last_seen_at ? new Date(r.last_seen_at).toISOString() : null,
    };
  };

  return json({
    friends: (friends.results ?? []).map((r: any) => ({ ...mapP(r), since: new Date(r.created_at).toISOString() })),
    incoming: (incoming.results ?? []).map((r: any) => ({ requestId: r.request_id, ...mapP(r), createdAt: new Date(r.created_at).toISOString() })),
    outgoing: (outgoing.results ?? []).map((r: any) => ({ requestId: r.request_id, ...mapP(r), createdAt: new Date(r.created_at).toISOString() })),
  });
}

async function notificationsList(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const rows = await env.DB.prepare(
    'SELECT id, type, message, data, read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 60',
  ).bind(user.id).all<{ id: string; type: string; message: string; data: string; read: number; created_at: number }>();
  const unread = await env.DB.prepare('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND read = 0').bind(user.id).first<{ count: number }>();
  return json({
    notifications: (rows.results ?? []).map((r) => {
      let data: unknown = {};
      try { data = JSON.parse(r.data); } catch { data = {}; }
      return { id: r.id, type: r.type, message: r.message, data, read: Boolean(r.read), createdAt: new Date(r.created_at).toISOString() };
    }),
    unread: unread?.count ?? 0,
  });
}

async function notificationsRead(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  await env.DB.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').bind(user.id).run();
  return json({ ok: true });
}

/* ------------------------------------------------------------------ */
/*  Admin                                                              */
/* ------------------------------------------------------------------ */

async function adminLogin(request: Request, env: Env): Promise<Response> {
  if (!env.ADMIN_KEY || !env.ADMIN_PASSWORD_HASH) return fail('Owner access is not configured on this deployment yet.', 503, 'admin_not_configured');
  const ipKey = `admin:${clientIp(request)}`;
  if (await isRateLimited(env, ipKey, 6, 15 * 60_000)) throw new HttpError(429, 'Too many attempts. Try again in 15 minutes.', 'rate_limited');
  const body = await readBody(request);
  const adminKey = typeof body.adminKey === 'string' ? body.adminKey.trim() : '';
  const password = typeof body.password === 'string' ? body.password : '';
  const keyOk = Boolean(adminKey) && safeEqual(adminKey, env.ADMIN_KEY);
  const passwordOk = Boolean(password) && (await verifyPassword(password, env.ADMIN_PASSWORD_HASH));
  if (!keyOk || !passwordOk) {
    await recordFailure(env, ipKey, 15 * 60_000);
    throw new HttpError(401, 'Invalid owner key or password', 'invalid_admin_credentials');
  }
  await clearFailures(env, ipKey);
  await env.DB.prepare('DELETE FROM admin_sessions WHERE expires_at <= ?').bind(now()).run();
  const token = await createAdminSession(env);
  await logActivity(env, request, null, 'admin_login', 'Owner signed in');
  return json({ ok: true, expiresAt: new Date(now() + ADMIN_HOURS * 3_600_000).toISOString() }, 200, { 'Set-Cookie': cookie(ADMIN_COOKIE, token, ADMIN_HOURS * 3_600, isSecure(request)) });
}

async function adminLogout(request: Request, env: Env): Promise<Response> {
  const token = parseCookies(request)[ADMIN_COOKIE];
  if (token) await env.DB.prepare('DELETE FROM admin_sessions WHERE token_hash = ?').bind(await sha256(token)).run();
  await logActivity(env, request, null, 'admin_logout', 'Owner signed out');
  return json({ ok: true }, 200, { 'Set-Cookie': cookie(ADMIN_COOKIE, '', 0, isSecure(request)) });
}

async function adminStats(request: Request, env: Env): Promise<Response> {
  if (!(await isAdmin(request, env))) return fail('Owner authentication required', 401, 'admin_required');
  const users = await env.DB.prepare(
    `SELECT COUNT(*) AS total,
      SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active,
      SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspended,
      SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END) AS new_week
     FROM users`,
  ).bind(now() - 7 * 86_400_000).first<{ total: number; active: number; suspended: number; new_week: number }>();
  const sessions = await env.DB.prepare('SELECT COUNT(*) AS count FROM sessions WHERE expires_at > ?').bind(now()).first<{ count: number }>();
  const logins = await env.DB.prepare("SELECT COUNT(*) AS count FROM activity WHERE action LIKE 'login%' AND created_at >= ?").bind(now() - 86_400_000).first<{ count: number }>();
  const friendships = await env.DB.prepare('SELECT COUNT(*) AS count FROM friendships').first<{ count: number }>();
  const workspaces = await env.DB.prepare('SELECT data FROM workspaces').all<{ data: string }>();
  const totals = { tasks: 0, events: 0, goals: 0, notes: 0, messages: 0 };
  for (const row of workspaces.results ?? []) {
    try {
      const data = JSON.parse(row.data) as Record<string, unknown>;
      for (const key of Object.keys(totals) as (keyof typeof totals)[]) {
        const value = data[key];
        if (Array.isArray(value)) totals[key] += value.length;
      }
    } catch { /* ignore */ }
  }
  const since = now() - 13 * 86_400_000;
  const registrations = await env.DB.prepare(
    `SELECT strftime('%Y-%m-%d', created_at / 1000, 'unixepoch') AS day, COUNT(*) AS count
     FROM users WHERE created_at >= ? GROUP BY day ORDER BY day`,
  ).bind(since).all<{ day: string; count: number }>();
  const byDay: { day: string; count: number }[] = [];
  for (let i = 13; i >= 0; i -= 1) {
    const day = dayISO(now() - i * 86_400_000);
    byDay.push({ day, count: registrations.results?.find((e) => e.day === day)?.count ?? 0 });
  }
  return json({
    totalUsers: users?.total ?? 0, activeUsers: users?.active ?? 0, suspendedUsers: users?.suspended ?? 0,
    newUsers7d: users?.new_week ?? 0, activeSessions: sessions?.count ?? 0, logins24h: logins?.count ?? 0,
    totalFriendships: friendships?.count ?? 0, totals, registrations: byDay, generatedAt: new Date().toISOString(),
  });
}

async function adminUsers(request: Request, env: Env): Promise<Response> {
  if (!(await isAdmin(request, env))) return fail('Owner authentication required', 401, 'admin_required');
  const url = new URL(request.url);
  const query = (url.searchParams.get('query') ?? '').trim().slice(0, 80);
  const status = url.searchParams.get('status') ?? 'all';
  const page = Math.max(1, Math.min(10_000, Number(url.searchParams.get('page') ?? 1) || 1));
  const pageSize = 20;

  const where: string[] = [];
  const values: unknown[] = [];
  if (query) {
    where.push('(name LIKE ? OR username LIKE ? OR email LIKE ? OR user_code LIKE ?)');
    const pattern = `%${query.replace(/[%_]/g, '')}%`;
    values.push(pattern, pattern, pattern, pattern);
  }
  if (status === 'active' || status === 'suspended') { where.push('status = ?'); values.push(status); }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const totalRow = await env.DB.prepare(`SELECT COUNT(*) AS count FROM users ${whereSql}`).bind(...values).first<{ count: number }>();
  const total = totalRow?.count ?? 0;
  const offset = (page - 1) * pageSize;
  const rows = await env.DB.prepare(
    `SELECT id, user_code, name, username, email, bio, interests, goals, status, auth_provider, is_vip, vip_permanent, profile_frame, username_effect, created_at, last_login_at
     FROM users ${whereSql} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
  ).bind(...values, pageSize, offset).all<any>();

  const ids = (rows.results ?? []).map((r: any) => r.id as string);
  const counts = new Map<string, { tasks: number; goals: number; notes: number }>();
  if (ids.length) {
    const placeholders = ids.map(() => '?').join(',');
    const workspaces = await env.DB.prepare(`SELECT user_id, data FROM workspaces WHERE user_id IN (${placeholders})`).bind(...ids).all<{ user_id: string; data: string }>();
    for (const ws of workspaces.results ?? []) {
      try {
        const data = JSON.parse(ws.data) as Record<string, unknown>;
        counts.set(ws.user_id, { tasks: Array.isArray(data.tasks) ? data.tasks.length : 0, goals: Array.isArray(data.goals) ? data.goals.length : 0, notes: Array.isArray(data.notes) ? data.notes.length : 0 });
      } catch { counts.set(ws.user_id, { tasks: 0, goals: 0, notes: 0 }); }
    }
  }

  return json({
    users: (rows.results ?? []).map((row: any) => ({
      id: row.id, userCode: row.user_code, name: row.name, username: row.username, email: row.email,
      bio: row.bio, interests: row.interests, goals: row.goals, status: row.status, authProvider: row.auth_provider,
      isVip: Boolean(row.is_vip) || Boolean(row.vip_permanent) || String(row.email||'').toLowerCase() === VIP_EMAIL,
      vipPermanent: Boolean(row.vip_permanent) || String(row.email||'').toLowerCase() === VIP_EMAIL,
      profileFrame: row.profile_frame || 'none', usernameEffect: row.username_effect || 'none',
      joinedAt: new Date(row.created_at).toISOString(), lastLoginAt: row.last_login_at ? new Date(row.last_login_at).toISOString() : null,
      counts: counts.get(row.id) ?? { tasks: 0, goals: 0, notes: 0 },
    })),
    page, pageSize, total, pages: Math.max(1, Math.ceil(total / pageSize)),
  });
}

async function adminUpdateUser(request: Request, env: Env, userId: string): Promise<Response> {
  if (!(await isAdmin(request, env))) return fail('Owner authentication required', 401, 'admin_required');
  const body = await readBody(request);
  const status = body.status === 'suspended' ? 'suspended' : body.status === 'active' ? 'active' : null;
  if (!status) throw new HttpError(422, 'Status must be active or suspended', 'invalid_status');
  const target = await env.DB.prepare('SELECT id, username FROM users WHERE id = ?').bind(userId).first<{ id: string; username: string }>();
  if (!target) throw new HttpError(404, 'User not found', 'not_found');
  await env.DB.prepare('UPDATE users SET status = ?, updated_at = ? WHERE id = ?').bind(status, now(), userId).run();
  if (status === 'suspended') await env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId).run();
  await logActivity(env, request, userId, status === 'suspended' ? 'admin_suspend' : 'admin_activate', `${status === 'suspended' ? 'Suspended' : 'Activated'} by owner`);
  return json({ ok: true, status });
}

async function adminActivity(request: Request, env: Env): Promise<Response> {
  if (!(await isAdmin(request, env))) return fail('Owner authentication required', 401, 'admin_required');
  const url = new URL(request.url);
  const limit = Math.max(1, Math.min(100, Number(url.searchParams.get('limit') ?? 60) || 60));
  const rows = await env.DB.prepare(
    `SELECT a.id, a.action, a.detail, a.created_at, u.name, u.username, u.user_code
     FROM activity a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC LIMIT ?`,
  ).bind(limit).all<any>();
  return json({
    activity: (rows.results ?? []).map((row: any) => ({
      id: row.id, action: row.action, detail: row.detail, createdAt: new Date(row.created_at).toISOString(),
      name: row.name, username: row.username, userCode: row.user_code,
    })),
  });
}

/* ------------------------------------------------------------------ */
/*  Chat, presence, blocks, reports                                     */
/* ------------------------------------------------------------------ */

function conversationId(a: string, b: string): string {
  const [x, y] = pair(a, b);
  return x + '__' + y;
}

async function ensureFriendship(env: Env, userId: string, otherId: string): Promise<void> {
  const [a, b] = pair(userId, otherId);
  const row = await env.DB.prepare('SELECT id FROM friendships WHERE user_a = ? AND user_b = ?').bind(a, b).first();
  if (!row) throw new HttpError(403, 'You can only message accepted friends', 'not_friends');
}

async function blockState(env: Env, userId: string, otherId: string): Promise<{ blockedByMe: boolean; blockedMe: boolean }> {
  const [byMe, me] = await Promise.all([
    env.DB.prepare('SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ?').bind(userId, otherId).first(),
    env.DB.prepare('SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ?').bind(otherId, userId).first(),
  ]);
  return { blockedByMe: Boolean(byMe), blockedMe: Boolean(me) };
}

async function presencePing(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  await env.DB.prepare("UPDATE users SET last_seen_at = ?, typing_to = CASE WHEN typing_at < ? THEN '' ELSE typing_to END, typing_at = CASE WHEN typing_at < ? THEN 0 ELSE typing_at END WHERE id = ?")
    .bind(now(), now() - 6000, now() - 6000, user.id).run();
  return json({ ok: true, now: new Date().toISOString() });
}

async function chatTyping(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const to = str(body.to, 64);
  const typing = Boolean(body.typing);
  if (!to) throw new HttpError(422, 'Missing recipient', 'invalid_request');
  await ensureFriendship(env, user.id, to);
  const bs = await blockState(env, user.id, to);
  if (bs.blockedByMe || bs.blockedMe) throw new HttpError(403, 'Messaging is not available for this conversation', 'blocked');
  if (typing) {
    await env.DB.prepare('UPDATE users SET typing_to = ?, typing_at = ?, last_seen_at = ? WHERE id = ?').bind(to, now(), now(), user.id).run();
  } else {
    await env.DB.prepare("UPDATE users SET typing_to = CASE WHEN typing_to = ? THEN '' ELSE typing_to END, typing_at = CASE WHEN typing_to = ? THEN 0 ELSE typing_at END, last_seen_at = ? WHERE id = ?")
      .bind(to, to, now(), user.id).run();
  }
  return json({ ok: true });
}

async function chatConversations(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  await env.DB.prepare('UPDATE users SET last_seen_at = ? WHERE id = ?').bind(now(), user.id).run();

  const friends = await env.DB.prepare(
    "SELECT u.id, u.user_code, u.name, u.username, u.avatar, u.email, u.is_vip, u.vip_permanent, " +
    "u.profile_frame, u.username_effect, u.username_color, u.border_color, u.glow_effect, u.profile_theme, " +
    "u.last_seen_at, u.typing_to, u.typing_at, f.created_at " +
    "FROM friendships f JOIN users u ON u.id = CASE WHEN f.user_a = ? THEN f.user_b ELSE f.user_a END " +
    "WHERE f.user_a = ? OR f.user_b = ? ORDER BY f.created_at DESC"
  ).bind(user.id, user.id, user.id).all();

  const blocks = await env.DB.prepare('SELECT blocker_id, blocked_id FROM blocks WHERE blocker_id = ? OR blocked_id = ?').bind(user.id, user.id).all();
  const blockedByMe = new Set((blocks.results || []).filter((b: any) => b.blocker_id === user.id).map(b => b.blocked_id));
  const blockedMe = new Set((blocks.results || []).filter((b: any) => b.blocked_id === user.id).map(b => b.blocker_id));

  const out = [];
  for (const f of (friends.results || []) as any[]) {
    const cid = conversationId(user.id, f.id);
    const conv = await env.DB.prepare('SELECT id, last_message_at, last_message_text, updated_at FROM conversations WHERE id = ?').bind(cid).first<any>();
    const read = await env.DB.prepare('SELECT last_read_at FROM message_reads WHERE user_id = ? AND conversation_id = ?').bind(user.id, cid).first<any>();
    const lastReadAt = Number(read?.last_read_at || 0);
    const unreadRow = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM chat_messages WHERE conversation_id = ? AND sender_id != ? AND created_at > ? AND deleted_for_all = 0 AND (deleted_by = '' OR deleted_by != ?)"
    ).bind(cid, user.id, lastReadAt, user.id).first<any>();
    const isTyping = (f.typing_to === user.id) && (Number(f.typing_at || 0) > now() - 6000);
    out.push({
      conversationId: cid,
      friend: {
        id: f.id, userCode: f.user_code, name: f.name, username: f.username, avatar: f.avatar,
        isVip: isVipRow({ email: f.email || '', is_vip: f.is_vip || 0, vip_permanent: f.vip_permanent || 0 } as any),
        profileFrame: f.profile_frame || 'none', usernameEffect: f.username_effect || 'none', usernameColor: f.username_color || '',
        borderColor: f.border_color || '', glowEffect: f.glow_effect || 'none', profileTheme: f.profile_theme || 'default',
        online: isOnline(Number(f.last_seen_at || 0)), lastSeenAt: f.last_seen_at ? new Date(Number(f.last_seen_at)).toISOString() : null,
      },
      lastMessage: conv ? { text: String(conv.last_message_text || ''), at: conv.last_message_at ? new Date(Number(conv.last_message_at)).toISOString() : null } : null,
      unread: Number((unreadRow as any)?.count || 0),
      typing: isTyping,
      blockedByMe: blockedByMe.has(f.id),
      blockedMe: blockedMe.has(f.id),
      updatedAt: conv?.updated_at ? new Date(Number(conv.updated_at)).toISOString() : new Date(Number(f.created_at)).toISOString(),
    });
  }
  out.sort((a, b) => String(b.lastMessage && b.lastMessage.at || b.updatedAt || '').localeCompare(String(a.lastMessage && a.lastMessage.at || a.updatedAt || '')));
  return json({ conversations: out });
}

async function chatMessages(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const url = new URL(request.url);
  const withId = (url.searchParams.get('with') || '').trim();
  const limit = Math.max(1, Math.min(100, Number(url.searchParams.get('limit') || 80)));
  const before = Number(url.searchParams.get('before') || 0) || 0;
  if (!withId) throw new HttpError(422, 'Missing conversation', 'invalid_request');
  await ensureFriendship(env, user.id, withId);
  const cid = conversationId(user.id, withId);

  await env.DB.prepare(
    "INSERT INTO message_reads (user_id, conversation_id, last_read_at) VALUES (?, ?, ?) " +
    "ON CONFLICT(user_id, conversation_id) DO UPDATE SET last_read_at = MAX(message_reads.last_read_at, excluded.last_read_at)"
  ).bind(user.id, cid, now()).run();

  const q = before
    ? env.DB.prepare("SELECT id, sender_id, text, created_at, deleted_for_all, deleted_by FROM chat_messages WHERE conversation_id = ? AND created_at < ? ORDER BY created_at DESC LIMIT ?").bind(cid, before, limit)
    : env.DB.prepare("SELECT id, sender_id, text, created_at, deleted_for_all, deleted_by FROM chat_messages WHERE conversation_id = ? ORDER BY created_at DESC LIMIT ?").bind(cid, limit);
  const rows = await q.all();
  const msgs = (rows.results || []).reduce((acc: any[], m: any) => {
    if (m.deleted_by === user.id) return acc;
    const deletedForAll = Boolean(m.deleted_for_all);
    acc.push({
      id: m.id,
      senderId: m.sender_id,
      text: deletedForAll ? '' : m.text,
      createdAt: new Date(m.created_at).toISOString(),
      deleted: deletedForAll,
      deletedForAll,
    });
    return acc;
  }, []).reverse();

  const peer = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(withId).first<any>();
  const bs = await blockState(env, user.id, withId);
  const typing = peer ? (peer.typing_to === user.id && Number(peer.typing_at || 0) > now() - 6000) : false;
  return json({
    conversationId: cid,
    messages: msgs,
    peer: peer ? publicProfile(peer as any) : null,
    typing,
    blockedByMe: bs.blockedByMe,
    blockedMe: bs.blockedMe,
  });
}

async function chatSend(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const to = str(body.to, 64);
  const text = str(body.text, 2000);
  if (!to || !text) throw new HttpError(422, 'Message text is required', 'invalid_message');
  await ensureFriendship(env, user.id, to);
  const bs = await blockState(env, user.id, to);
  if (bs.blockedByMe || bs.blockedMe) throw new HttpError(403, 'You cannot send messages in this conversation', 'blocked');
  const cid = conversationId(user.id, to);
  const [a, b] = pair(user.id, to);
  const ts = now();
  const id = crypto.randomUUID();
  await env.DB.prepare(
    "INSERT INTO conversations (id, user_a, user_b, created_at, updated_at, last_message_at, last_message_text) VALUES (?, ?, ?, ?, ?, ?, ?) " +
    "ON CONFLICT(id) DO UPDATE SET updated_at = excluded.updated_at, last_message_at = excluded.last_message_at, last_message_text = excluded.last_message_text"
  ).bind(cid, a, b, ts, ts, ts, text.slice(0, 200)).run();
  await env.DB.prepare("INSERT INTO chat_messages (id, conversation_id, sender_id, text, created_at, deleted_for_all, deleted_by) VALUES (?, ?, ?, ?, ?, 0, '')")
    .bind(id, cid, user.id, text, ts).run();
  await env.DB.prepare(
    "INSERT INTO message_reads (user_id, conversation_id, last_read_at) VALUES (?, ?, ?) " +
    "ON CONFLICT(user_id, conversation_id) DO UPDATE SET last_read_at = MAX(message_reads.last_read_at, excluded.last_read_at)"
  ).bind(user.id, cid, ts).run();
  await env.DB.prepare("UPDATE users SET last_seen_at = ?, typing_to = '', typing_at = 0 WHERE id = ?").bind(ts, user.id).run();
  await addNotification(env, to, 'new_message', user.name + ' sent you a message.', { fromId: user.id, fromCode: user.user_code, fromName: user.name, conversationId: cid });
  return json({ ok: true, message: { id, senderId: user.id, text, createdAt: new Date(ts).toISOString(), deleted: false, deletedForAll: false } }, 201);
}

async function chatDelete(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const messageId = str(body.messageId, 64);
  const mode = str(body.mode, 10);
  if (!messageId) throw new HttpError(422, 'Missing message', 'invalid_request');
  const msg = await env.DB.prepare('SELECT * FROM chat_messages WHERE id = ?').bind(messageId).first();
  if (!msg) throw new HttpError(404, 'Message not found', 'not_found');
  const conv = await env.DB.prepare('SELECT * FROM conversations WHERE id = ?').bind(msg.conversation_id).first();
  if (!conv || (conv.user_a !== user.id && conv.user_b !== user.id)) throw new HttpError(403, 'Forbidden', 'forbidden');
  if (mode === 'all') {
    if (msg.sender_id !== user.id) throw new HttpError(403, 'Only the sender can delete for everyone', 'forbidden');
    await env.DB.prepare("UPDATE chat_messages SET deleted_for_all = 1, text = '' WHERE id = ?").bind(messageId).run();
  } else {
    await env.DB.prepare("UPDATE chat_messages SET deleted_by = CASE WHEN deleted_by = '' OR deleted_by = ? THEN ? ELSE deleted_by END WHERE id = ?")
      .bind(user.id, user.id, messageId).run();
  }
  return json({ ok: true });
}

async function chatSearch(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const q = (new URL(request.url).searchParams.get('q') || '').trim().slice(0, 80);
  if (q.length < 1) return json({ results: [] });
  const pattern = '%' + q.replace(/[%_]/g, '') + '%';
  const rows = await env.DB.prepare(
    "SELECT m.id, m.conversation_id, m.sender_id, m.text, m.created_at, m.deleted_for_all, m.deleted_by, c.user_a, c.user_b " +
    "FROM chat_messages m JOIN conversations c ON c.id = m.conversation_id " +
    "WHERE (c.user_a = ? OR c.user_b = ?) AND m.deleted_for_all = 0 AND m.text LIKE ? ORDER BY m.created_at DESC LIMIT 50"
  ).bind(user.id, user.id, pattern).all<any>();
  const results: any[] = [];
  for (const m of (rows.results || []) as any[]) {
    if (m.deleted_by === user.id) continue;
    const otherId = m.user_a === user.id ? m.user_b : m.user_a;
    const peer = await env.DB.prepare('SELECT id, user_code, name, username, avatar, email, is_vip, vip_permanent, profile_frame, username_effect, username_color, border_color, glow_effect, profile_theme, last_seen_at, bio, interests FROM users WHERE id = ?').bind(otherId).first<any>();
    results.push({
      messageId: m.id,
      conversationId: m.conversation_id,
      senderId: m.sender_id,
      text: m.text,
      createdAt: new Date(Number(m.created_at)).toISOString(),
      peer: peer ? publicProfile(peer as any) : null,
    });
  }
  return json({ results });
}

async function chatBlock(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const userId = str(body.userId, 64);
  const block = Boolean(body.block);
  if (!userId || userId === user.id) throw new HttpError(422, 'Invalid user', 'invalid_request');
  if (block) {
    await env.DB.prepare('INSERT OR IGNORE INTO blocks (blocker_id, blocked_id, created_at) VALUES (?, ?, ?)').bind(user.id, userId, now()).run();
  } else {
    await env.DB.prepare('DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?').bind(user.id, userId).run();
  }
  await logActivity(env, request, user.id, block ? 'block_user' : 'unblock_user', userId);
  return json({ ok: true, blocked: block });
}

async function chatReport(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  const body = await readBody(request);
  const reportedId = str(body.userId, 64);
  const conversationIdIn = str(body.conversationId, 128);
  const reason = str(body.reason, 120) || 'abuse';
  const detail = str(body.detail, 1000);
  if (!reportedId || reportedId === user.id) throw new HttpError(422, 'Invalid report', 'invalid_request');
  await env.DB.prepare('INSERT INTO reports (id, reporter_id, reported_id, conversation_id, reason, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .bind(crypto.randomUUID(), user.id, reportedId, conversationIdIn, reason, detail, now()).run();
  await logActivity(env, request, user.id, 'report_user', reportedId + ': ' + reason);
  return json({ ok: true });
}

/* ------------------------------------------------------------------ */
/*  Admin VIP                                                          */
/* ------------------------------------------------------------------ */

async function adminVipList(request: Request, env: Env): Promise<Response> {
  if (!(await isAdmin(request, env))) return fail('Owner authentication required', 401, 'admin_required');
  const rows = await env.DB.prepare(
    "SELECT id, user_code, name, username, email, avatar, is_vip, vip_permanent, profile_frame, username_effect, status, created_at, last_login_at " +
    "FROM users WHERE is_vip = 1 OR vip_permanent = 1 ORDER BY vip_permanent DESC, created_at DESC"
  ).all();
  return json({
    vips: (rows.results || []).map((r: any) => ({
      id: r.id, userCode: r.user_code, name: r.name, username: r.username, email: r.email, avatar: r.avatar,
      isVip: Boolean(r.is_vip) || Boolean(r.vip_permanent) || String(r.email || '').toLowerCase() === VIP_EMAIL,
      vipPermanent: Boolean(r.vip_permanent) || String(r.email || '').toLowerCase() === VIP_EMAIL,
      profileFrame: r.profile_frame || 'none', usernameEffect: r.username_effect || 'none',
      status: r.status, joinedAt: new Date(Number(r.created_at)).toISOString(), lastLoginAt: r.last_login_at ? new Date(Number(r.last_login_at as any)).toISOString() : null,
    })),
  });
}

async function adminSetVip(request: Request, env: Env): Promise<Response> {
  if (!(await isAdmin(request, env))) return fail('Owner authentication required', 401, 'admin_required');
  const body = await readBody(request);
  const userId = str(body.userId, 64);
  const email = str(body.email, 254).toLowerCase();
  const code = str(body.code, 20).toUpperCase();
  const isVipIn = body.isVip === undefined ? undefined : Boolean(body.isVip);
  const profileFrame = body.profileFrame === undefined ? undefined : str(body.profileFrame, 40);
  const usernameEffect = body.usernameEffect === undefined ? undefined : str(body.usernameEffect, 40);
  let target: any = null;
  if (userId) target = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(userId).first();
  else if (code) target = await env.DB.prepare('SELECT * FROM users WHERE UPPER(user_code) = ?').bind(code).first();
  else if (email) target = await env.DB.prepare('SELECT * FROM users WHERE LOWER(email) = ?').bind(email).first();
  if (!target) throw new HttpError(404, 'User not found', 'not_found');

  let nextVip = isVipIn === undefined ? (target.is_vip ? 1 : 0) : (isVipIn ? 1 : 0);
  let nextPerm = target.vip_permanent ? 1 : 0;
  if (String(target.email || '').toLowerCase() === VIP_EMAIL) { nextVip = 1; nextPerm = 1; }

  let frame = target.profile_frame || 'none';
  if (profileFrame !== undefined) {
    if (!(FRAME_STYLES as readonly string[]).includes(profileFrame)) throw new HttpError(422, 'Invalid frame', 'invalid_frame');
    frame = profileFrame;
  }
  let effect = target.username_effect || 'none';
  if (usernameEffect !== undefined) {
    if (!(USERNAME_EFFECTS as readonly string[]).includes(usernameEffect)) throw new HttpError(422, 'Invalid effect', 'invalid_username_effect');
    effect = usernameEffect;
  }
  if (!nextVip) {
    if (VIP_ONLY_FRAMES.has(frame as any)) frame = 'none';
    if (VIP_ONLY_EFFECTS.has(effect as any)) effect = 'none';
  }
  await env.DB.prepare('UPDATE users SET is_vip = ?, vip_permanent = ?, profile_frame = ?, username_effect = ?, updated_at = ? WHERE id = ?')
    .bind(nextVip, nextPerm, frame, effect, now(), target.id).run();
  await logActivity(env, request, target.id, nextVip ? 'admin_vip_grant' : 'admin_vip_remove', 'VIP ' + (nextVip ? 'granted' : 'removed') + ' by owner');
  return json({ ok: true, isVip: Boolean(nextVip), vipPermanent: Boolean(nextPerm) });
}


/* ------------------------------------------------------------------ */
/*  VIP media (cover/background)                                       */
/* ------------------------------------------------------------------ */
const MEDIA_TYPES: Record<string, string> = {
  'image/jpeg': 'image', 'image/jpg': 'image', 'image/png': 'image', 'image/webp': 'image',
  'video/mp4': 'video', 'video/webm': 'video',
};
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const MAX_VIDEO_BYTES = 30 * 1024 * 1024;

async function uploadMedia(request: Request, env: Env): Promise<Response> {
  const user = await currentUser(request, env);
  if (!user) return fail('Not authenticated', 401, 'auth_required');
  if (!env.MEDIA_BUCKET) return fail('Media storage is not configured on this deployment', 503, 'media_unavailable');
  const ct = request.headers.get('content-type') || '';
  if (!ct.includes('multipart/form-data')) return fail('Upload must be multipart/form-data', 415, 'invalid_upload');
  let form: FormData;
  try { form = await request.formData(); } catch { return fail('Invalid upload', 400, 'invalid_upload'); }
  const purpose = String(form.get('purpose') || 'avatar').toLowerCase();
  const file = form.get('file') as any;
  if (!file || typeof file.arrayBuffer !== 'function' || typeof file.size !== 'number') return fail('No file uploaded', 422, 'file_required');
  const mime = (file.type || '').toLowerCase();
  const mediaType = MEDIA_TYPES[mime];
  if (!mediaType) return fail('Unsupported file type. Allowed: JPG, PNG, WEBP, MP4, WEBM.', 422, 'invalid_file_type');
  // Videos and cover/background uploads are VIP-only; authenticated users may upload images (e.g. avatars).
  if ((mediaType === 'video' || purpose === 'cover' || purpose === 'background') && !isVipRow(user)) {
    return fail('Video and VIP cover/background uploads are available to VIP members only', 403, 'vip_required');
  }
  const limit = mediaType === 'image' ? MAX_IMAGE_BYTES : MAX_VIDEO_BYTES;
  if (file.size <= 0) return fail('Empty file', 422, 'empty_file');
  if (file.size > limit) return fail(mediaType === 'image' ? 'Image is too large (max 8 MB)' : 'Video is too large (max 30 MB)', 413, 'file_too_large');
  const ext = mime === 'image/jpeg' ? 'jpg' : mime === 'image/jpg' ? 'jpg' : mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : mime === 'video/mp4' ? 'mp4' : 'webm';
  const key = 'media/' + user.id + '/' + Date.now() + '-' + crypto.randomUUID() + '.' + ext;
  await env.MEDIA_BUCKET.put(key, file.stream(), { httpMetadata: { contentType: mime }, customMetadata: { owner: user.id, type: mediaType, purpose } });
  const url = '/api/media/' + key;
  await logActivity(env, request, user.id, 'media_upload', mediaType + ':' + mime + ':' + purpose);
  return json({ ok: true, url, type: mediaType, contentType: mime, size: file.size });
}

async function serveMedia(env: Env, key: string): Promise<Response> {
  if (!env.MEDIA_BUCKET) return fail('Media storage is not configured', 503, 'media_unavailable');
  const obj = await env.MEDIA_BUCKET.get(key);
  if (!obj) return fail('Media not found', 404, 'not_found');
  const headers = new Headers();
  const ct = obj.httpMetadata?.contentType || 'application/octet-stream';
  headers.set('Content-Type', ct);
  headers.set('Cache-Control', 'public, max-age=31536000, immutable');
  headers.set('X-Content-Type-Options', 'nosniff');
  return new Response(obj.body, { status: 200, headers });
}

/* ------------------------------------------------------------------ */
/*  Router                                                             */
/* ------------------------------------------------------------------ */

async function handleApi(request: Request, env: Env): Promise<Response> {
  if (!sameOrigin(request)) return fail('Cross-origin request blocked', 403, 'bad_origin');
  await ensureSchema(env.DB);

  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, '') || '/api';
  const method = request.method.toUpperCase();

  if (path === '/api/health' && method === 'GET') return json({ ok: true, service: 'smart-life-ai', time: new Date().toISOString() });

  if (path === '/api/auth/register' && method === 'POST') return register(request, env);
  if (path === '/api/auth/login' && method === 'POST') return login(request, env);
  if (path === '/api/auth/google' && method === 'POST') return loginWithGoogle(request, env);
  if (path === '/api/auth/logout' && method === 'POST') return logout(request, env);
  if (path === '/api/auth/me' && method === 'GET') return me(request, env);

  if (path === '/api/profile' && method === 'PATCH') return updateProfile(request, env);
  if (path === '/api/media/upload' && method === 'POST') return uploadMedia(request, env);
  if (path.startsWith('/api/media/') && method === 'GET') return serveMedia(env, decodeURIComponent(path.slice('/api/media/'.length)));
  if (path === '/api/account' && method === 'DELETE') return deleteAccount(request, env);

  if (path === '/api/workspace' && method === 'GET') return getWorkspace(request, env);
  if (path === '/api/workspace' && method === 'PUT') return saveWorkspace(request, env);

  if (path === '/api/friends' && method === 'GET') return friendsList(request, env);
  if (path === '/api/friends/search' && method === 'GET') return friendsSearch(request, env);
  if (path === '/api/friends/request' && method === 'POST') return friendsRequest(request, env);
  if (path === '/api/friends/respond' && method === 'POST') return friendsRespond(request, env);
  if (path === '/api/friends/remove' && method === 'POST') return friendsRemove(request, env);

  if (path === '/api/notifications' && method === 'GET') return notificationsList(request, env);
  if (path === '/api/notifications/read' && method === 'POST') return notificationsRead(request, env);

  if (path === '/api/presence/ping' && method === 'POST') return presencePing(request, env);
  if (path === '/api/chat/conversations' && method === 'GET') return chatConversations(request, env);
  if (path === '/api/chat/messages' && method === 'GET') return chatMessages(request, env);
  if (path === '/api/chat/messages' && method === 'POST') return chatSend(request, env);
  if (path === '/api/chat/messages/delete' && method === 'POST') return chatDelete(request, env);
  if (path === '/api/chat/typing' && method === 'POST') return chatTyping(request, env);
  if (path === '/api/chat/search' && method === 'GET') return chatSearch(request, env);
  if (path === '/api/chat/block' && method === 'POST') return chatBlock(request, env);
  if (path === '/api/chat/report' && method === 'POST') return chatReport(request, env);

  if (path === '/api/admin/login' && method === 'POST') return adminLogin(request, env);
  if (path === '/api/admin/logout' && method === 'POST') return adminLogout(request, env);
  if (path === '/api/admin/me' && method === 'GET') {
    const ok = await isAdmin(request, env);
    if (!ok) return fail('Owner authentication required', 401, 'admin_required');
    const u = await currentUser(request, env);
    return json({ admin: true, owner: u ? isOwnerRow(u) : true });
  }
  if (path === '/api/admin/stats' && method === 'GET') return adminStats(request, env);
  if (path === '/api/admin/users' && method === 'GET') return adminUsers(request, env);
  if (path === '/api/admin/activity' && method === 'GET') return adminActivity(request, env);
  if (path === '/api/admin/vips' && method === 'GET') return adminVipList(request, env);
  if (path === '/api/admin/vip' && method === 'POST') return adminSetVip(request, env);
  const userMatch = path.match(/^\/api\/admin\/users\/([0-9a-fA-F-]{36})$/);
  if (userMatch && method === 'PATCH') return adminUpdateUser(request, env, userMatch[1]);

  return fail('Not found', 404, 'not_found');
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) {
      try {
        return await handleApi(request, env);
      } catch (error) {
        if (error instanceof HttpError) return fail(error.message, error.status, error.code);
        console.error('Unhandled API error', error);
        return fail('Internal server error', 500, 'internal_error');
      }
    }
    const asset = await env.ASSETS.fetch(request);
    if (asset.status === 404 && request.method === 'GET' && !url.pathname.includes('.')) {
      return env.ASSETS.fetch(new Request(new URL('/', url).toString(), request));
    }
    return asset;
  },
};
