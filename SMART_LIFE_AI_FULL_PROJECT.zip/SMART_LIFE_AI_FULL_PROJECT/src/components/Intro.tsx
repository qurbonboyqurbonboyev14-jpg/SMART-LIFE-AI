import { Sparkles } from 'lucide-react';

export default function Intro() {
  return (
    <div className="intro-screen" aria-label="SMART LIFE AI intro">
      <div className="intro-bg" aria-hidden="true">
        <span className="intro-orb intro-orb-1" />
        <span className="intro-orb intro-orb-2" />
        <span className="intro-orb intro-orb-3" />
        <span className="intro-grid" />
        {Array.from({ length: 28 }).map((_, i) => (
          <span key={i} className="intro-particle" style={{ ['--i' as string]: i, left: `${(i * 37) % 100}%`, top: `${(i * 53) % 100}%` }} />
        ))}
      </div>
      <div className="intro-content">
        <div className="intro-logo-wrap">
          <div className="intro-logo-ring" />
          <div className="intro-logo-ring intro-logo-ring-2" />
          <div className="intro-logo logo-mark">
            <Sparkles size={42} strokeWidth={2.1} />
          </div>
        </div>
        <h1 className="intro-title font-display">
          SMART LIFE <span className="grad-text">AI</span>
        </h1>
        <p className="intro-tagline">YOUR LIFE. YOUR INTELLIGENCE.</p>
        <div className="intro-bar" aria-hidden="true"><span /></div>
      </div>
    </div>
  );
}
