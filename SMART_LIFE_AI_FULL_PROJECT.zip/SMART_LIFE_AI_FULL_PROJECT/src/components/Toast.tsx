import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { createPortal } from 'react-dom';
import { AlertTriangle, CheckCircle2, Info, PartyPopper, X } from 'lucide-react';
import { cn } from '../lib/cn';
import { useApp } from '../lib/store';

function playChime() {
  try {
    const AudioCtx = window.AudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.06, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.34);
    gain.connect(ctx.destination);
    [660, 880].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      osc.connect(gain);
      osc.start(ctx.currentTime + i * 0.09);
      osc.stop(ctx.currentTime + 0.34);
    });
    window.setTimeout(() => void ctx.close(), 500);
  } catch {
    /* audio is optional */
  }
}

type Tone = 'success' | 'info' | 'error' | 'celebrate';

interface ToastItem {
  id: number;
  title: string;
  description?: string;
  tone: Tone;
}

interface ToastContextValue {
  toast: (input: { title: string; description?: string; tone?: Tone }) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const toneStyles: Record<Tone, { icon: ReactNode; ring: string; glow: string }> = {
  success: {
    icon: <CheckCircle2 size={18} />,
    ring: 'text-emerald-400 bg-emerald-500/15',
    glow: 'shadow-[0_20px_60px_-20px_rgba(16,185,129,.45)]',
  },
  info: {
    icon: <Info size={18} />,
    ring: 'text-sky-400 bg-sky-500/15',
    glow: 'shadow-[0_20px_60px_-20px_rgba(14,165,233,.45)]',
  },
  error: {
    icon: <AlertTriangle size={18} />,
    ring: 'text-rose-400 bg-rose-500/15',
    glow: 'shadow-[0_20px_60px_-20px_rgba(244,63,94,.45)]',
  },
  celebrate: {
    icon: <PartyPopper size={18} />,
    ring: 'text-violet-300 bg-violet-500/15',
    glow: 'shadow-[0_20px_60px_-20px_rgba(139,92,246,.55)]',
  },
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const counter = useRef(0);
  const sound = useApp((s) => s.settings.sound);

  const remove = useCallback((id: number) => {
    setItems((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback(
    (input: { title: string; description?: string; tone?: Tone }) => {
      counter.current += 1;
      const id = counter.current;
      const item: ToastItem = {
        id,
        title: input.title,
        description: input.description,
        tone: input.tone ?? 'success',
      };
      setItems((prev) => [...prev.slice(-3), item]);
      window.setTimeout(() => remove(id), 4200);
      if (sound) playChime();
    },
    [remove, sound],
  );

  const value = useMemo(() => ({ toast }), [toast]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      {createPortal(
        <div
          className="pointer-events-none fixed inset-x-0 bottom-[86px] z-[120] flex flex-col items-center gap-2 px-4 sm:bottom-6 sm:right-6 sm:left-auto sm:items-end"
          aria-live="polite"
        >
          {items.map((item) => {
            const style = toneStyles[item.tone];
            return (
              <div
                key={item.id}
                className={cn(
                  'pointer-events-auto flex w-full max-w-[360px] items-start gap-3 rounded-2xl border border-line/10 bg-[var(--sidebar)] p-3.5 backdrop-blur-2xl animate-pop',
                  style.glow,
                )}
              >
                <span className={cn('mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl', style.ring)}>
                  {style.icon}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[13.5px] font-semibold leading-snug">{item.title}</p>
                  {item.description ? (
                    <p className="mt-0.5 text-xs leading-relaxed text-muted">{item.description}</p>
                  ) : null}
                </div>
                <button
                  type="button"
                  onClick={() => remove(item.id)}
                  aria-label="Close"
                  className="rounded-lg p-1 text-muted transition hover:bg-white/5 hover:text-ink"
                >
                  <X size={13} />
                </button>
              </div>
            );
          })}
        </div>,
        document.body,
      )}
    </ToastContext.Provider>
  );
}

export const useToast = () => {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx.toast;
};
