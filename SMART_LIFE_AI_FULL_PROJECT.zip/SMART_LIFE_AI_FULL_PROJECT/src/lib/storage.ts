/** Old device-only state from the pre-account version of the app. */
export const LEGACY_STATE_KEY = 'smartlife.v1';

/** Optional personal AI key — deliberately kept in this browser, never the database. */
export const aiKeyStorageKey = (userId: string) => `smartlife.aiKey.${userId}`;

export const AUTH_LANGUAGE_KEY = 'smartlife.authLanguage';
export const THEME_KEY = 'sl_theme';
export const LANG_KEY = 'sl_lang';

export function readAuthLanguage(): 'uz' | 'ru' | 'en' {
  try {
    const value = localStorage.getItem(AUTH_LANGUAGE_KEY);
    if (value === 'ru' || value === 'en') return value;
  } catch {
    // ignore storage restrictions
  }
  return 'uz';
}

export function writeAuthLanguage(language: 'uz' | 'ru' | 'en'): void {
  try {
    localStorage.setItem(AUTH_LANGUAGE_KEY, language);
  } catch {
    // ignore storage restrictions
  }
}

export function readAiKey(userId: string): string {
  try {
    return localStorage.getItem(aiKeyStorageKey(userId)) ?? '';
  } catch {
    return '';
  }
}

export function writeAiKey(userId: string, key: string): void {
  try {
    if (key) localStorage.setItem(aiKeyStorageKey(userId), key);
    else localStorage.removeItem(aiKeyStorageKey(userId));
  } catch {
    // ignore storage restrictions
  }
}
