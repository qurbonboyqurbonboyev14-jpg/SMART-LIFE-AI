import { create } from 'zustand';
import type {
  AppData,
  Category,
  ChatMessage,
  EventItem,
  Goal,
  Note,
  Priority,
  Settings,
  Task,
  User,
} from './types';
import { addDaysISO, todayISO } from './date';

const uid = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

const DEFAULT_SETTINGS: Settings = {
  theme: 'dark',
  language: 'uz',
  notifications: true,
  dailySummary: true,
  sound: false,
  reminderLead: 15,
  aiKey: '',
  aiBase: 'https://api.openai.com/v1',
  aiModel: 'gpt-4o-mini',
};

const DEFAULT_USER: User = {
  id: 'demo',
  userCode: 'SL-000000',
  name: 'Aziza Karimova',
  firstName: 'Aziza',
  lastName: 'Karimova',
  username: 'aziza',
  email: 'aziza.smartlife@gmail.com',
  bio: 'Talaba, mahsulot dizayneri va startap asoschisi. Har kuni bir qadam oldinga.',
  interests: 'Dizayn, AI, IELTS, startaplar, kitob o‘qish',
  goals: 'IELTS 8.0, startup MVP, yiliga 24 kitob',
  avatar: '🦋',
  joinedAt: '2025-09-01',
  authProvider: 'local',
};

const historyPool = [
  'Matematikadan amaliy topshiriq',
  'Kitob: "Atomic Habits" — 30 bet',
  'Ertalabki mashq va cho\'zilish',
  'Loyiha hisobotini yakunlash',
  'Ingliz tili lug\'at mashqi',
  'Dars jadvalini yangilash',
  'Taqdimot slaydlarini sayqallash',
  'Kod review sessiyasi',
  'Kunlik xulosa yozish',
  'Onlayn kurs — yangi dars',
  'Xonani tartibga keltirish',
  'Startup uchun mijoz intervyusi',
  'IELTS Listening mashqi',
  'Fizika masalalarini yechish',
  'Portfolio uchun keys tayyorlash',
  'Suv balansini kuzatish',
  'Instagram kontent rejasi',
  'Ispan tili — 15 daqiqa',
  'Jamoa stand-up uchrashuvi',
  'Ma\'lumotlar bazasi sxemasi',
  'Yangi retsept sinab ko\'rish',
  'Do\'stimga yordam berish',
  'Konferensiya tezisini ko\'rish',
  'Moliyaviy reja tahlili',
  'Meditatsiya — 10 daqiqa',
  'UI maketini tekshirish',
];

const historyCounts = [2, 3, 1, 4, 2, 3, 2, 4, 1, 3, 2, 4, 3];

const c = (category: Category, priority: Priority, day: number, title: string, completed = false): Task => ({
  id: uid(),
  title,
  description: '',
  category,
  priority,
  due: addDaysISO(todayISO(), day),
  completed,
  createdAt: `${addDaysISO(todayISO(), Math.min(day, 0) - 2)}T09:00:00`,
  completedAt: completed ? `${addDaysISO(todayISO(), day)}T` + (9 + (Math.abs(day) % 8)).toString().padStart(2, '0') + ':15:00' : null,
});

export function createEmptyWorkspace(profile?: User): AppData {
  return {
    user: profile ? { ...profile } : { ...DEFAULT_USER },
    tasks: [],
    events: [],
    goals: [],
    notes: [],
    messages: [],
    settings: { ...DEFAULT_SETTINGS },
  };
}

export function createSeed(profile?: User): AppData {
  const today = todayISO();

  const tasks: Task[] = [
    {
      ...c('study', 'high', 0, 'Fizika laboratoriya hisobotini yakunlash'),
      description: '3 va 4-mashqlar bo\'yicha xulosa yozish va grafiklarni joylash.',
    },
    { ...c('study', 'medium', 0, 'Ingliz tili — Speaking mashqi (30 daqiqa)'), completed: true, completedAt: `${today}T09:10:00` },
    {
      ...c('work', 'high', 0, 'Startup g\'oyasi bo\'yicha mijozlar bilan suhbat'),
      description: '3 nafar potensial foydalanuvchi bilan 20 daqiqalik suhbat.',
    },
    { ...c('personal', 'low', 0, 'Kunlik 10 000 qadam'), completed: true, completedAt: `${today}T07:40:00` },
    c('personal', 'low', 0, 'Kitob o\'qish — 20 bet'),
    c('study', 'high', 1, 'Matematik analiz seminariga tayyorgarlik'),
    c('work', 'medium', 1, 'Dizayn maketini yakunlash'),
    c('personal', 'medium', 1, 'Onamga qo\'ng\'iroq qilish'),
    c('study', 'high', 2, 'IELTS mock test — Reading'),
    c('work', 'medium', 2, 'Jamoa sprint review'),
    { ...c('personal', 'medium', -2, 'Kutubxona kitoblarini qaytarish'), priority: 'medium' },
    c('work', 'medium', 4, 'Portfolio saytini yangilash'),
    c('study', 'high', 6, 'Universitet konferensiyasiga tezis yuborish'),
    c('other', 'low', 8, 'Bank kartasini yangilash'),
  ];

  let titleIndex = 0;
  historyCounts.forEach((count, i) => {
    const day = -(i + 1);
    for (let j = 0; j < count; j++) {
      const title = historyPool[titleIndex % historyPool.length];
      titleIndex += 1;
      const category: Category = titleIndex % 5 === 0 ? 'work' : titleIndex % 3 === 0 ? 'personal' : titleIndex % 7 === 0 ? 'other' : 'study';
      const priority: Priority = titleIndex % 4 === 0 ? 'high' : titleIndex % 3 === 0 ? 'medium' : 'low';
      tasks.push({
        id: uid(),
        title,
        description: '',
        category,
        priority,
        due: addDaysISO(today, day),
        completed: true,
        createdAt: `${addDaysISO(today, day - 2)}T10:00:00`,
        completedAt: `${addDaysISO(today, day)}T${String(9 + j * 2).padStart(2, '0')}:${j % 2 === 0 ? '20' : '45'}:00`,
      });
    }
  });

  const events: EventItem[] = [
    { id: uid(), title: 'Ingliz tili darsi', date: today, start: '10:00', end: '11:30', category: 'study', reminder: 15, note: 'Speaking club — 4-mavzu' },
    { id: uid(), title: 'Loyiha uchrashuvi', date: today, start: '14:00', end: '15:00', category: 'work', reminder: 10, note: 'Haftalik natijalarni ko\'rib chiqish' },
    { id: uid(), title: 'Sport zal', date: today, start: '18:30', end: '19:30', category: 'personal', reminder: 30, note: 'Kuch mashqlari' },
    { id: uid(), title: 'Universitet ma\'ruzasi', date: addDaysISO(today, 1), start: '09:00', end: '10:30', category: 'study', reminder: 15, note: '' },
    { id: uid(), title: 'Startup mentorlik sessiyasi', date: addDaysISO(today, 1), start: '16:00', end: '17:00', category: 'work', reminder: 15, note: 'MVP bo\'yicha fikr-mulohaza' },
    { id: uid(), title: 'IELTS mock test', date: addDaysISO(today, 2), start: '09:00', end: '12:00', category: 'study', reminder: 60, note: '' },
    { id: uid(), title: 'Do\'stlar bilan kechki ovqat', date: addDaysISO(today, 3), start: '19:00', end: '21:00', category: 'personal', reminder: 30, note: '' },
    { id: uid(), title: 'Haftalik nazorat', date: addDaysISO(today, 5), start: '11:00', end: '12:00', category: 'work', reminder: 15, note: '' },
  ];

  const goals: Goal[] = [
    {
      id: uid(),
      title: 'IELTS 8.0 natijasiga erishish',
      description: 'Har kuni 45 daqiqa Speaking va haftada 2 marta mock test.',
      category: 'study',
      targetDate: addDaysISO(today, 92),
      progress: 65,
      completed: false,
      createdAt: addDaysISO(today, -60),
      completedAt: null,
    },
    {
      id: uid(),
      title: 'Yiliga 24 ta kitob o\'qish',
      description: 'Oyiga 2 kitob — ertalab 20 bet.',
      category: 'personal',
      targetDate: addDaysISO(today, 150),
      progress: 42,
      completed: false,
      createdAt: addDaysISO(today, -90),
      completedAt: null,
    },
    {
      id: uid(),
      title: 'Startup MVP ni ishga tushirish',
      description: '3 oy ichida 100 foydalanuvchi va birinchi daromad.',
      category: 'work',
      targetDate: addDaysISO(today, 64),
      progress: 28,
      completed: false,
      createdAt: addDaysISO(today, -35),
      completedAt: null,
    },
    {
      id: uid(),
      title: 'Sog\'lom turmush: haftada 4 mashq',
      description: 'Sport zal + yugurish, shakar iste\'molini kamaytirish.',
      category: 'personal',
      targetDate: addDaysISO(today, 30),
      progress: 75,
      completed: false,
      createdAt: addDaysISO(today, -25),
      completedAt: null,
    },
    {
      id: uid(),
      title: 'Portfolio saytini ishga tushirish',
      description: '3 ta keys va aloqa formasi bilan shaxsiy sayt.',
      category: 'work',
      targetDate: addDaysISO(today, -12),
      progress: 100,
      completed: true,
      createdAt: addDaysISO(today, -80),
      completedAt: addDaysISO(today, -12),
    },
  ];

  const notes: Note[] = [
    {
      id: uid(),
      title: 'Startup g\'oyalari',
      content:
        '1. Talabalar uchun aqlli rejalashtiruvchi — vazifa, kalendar va maqsadlarni birlashtiradi.\n2. Onlayn kurslar uchun mikro-o\'quv platformasi.\n3. Kichik biznes uchun avtomatik hisobotlar.\n\nKeyingi qadam: har bir g\'oya uchun 5 ta potensial foydalanuvchi bilan suhbat.',
      category: 'work',
      pinned: true,
      createdAt: addDaysISO(today, -9),
      updatedAt: addDaysISO(today, -2),
    },
    {
      id: uid(),
      title: 'IELTS Speaking savollari',
      content:
        'Part 2:\n• Describe a skill you would like to learn.\n• Describe a place that helps you relax.\n• Talk about a person who inspires you.\n\nFoydali iboralar: "What stands out to me is...", "I\'d say the main reason is..."',
      category: 'study',
      pinned: true,
      createdAt: addDaysISO(today, -20),
      updatedAt: addDaysISO(today, -4),
    },
    {
      id: uid(),
      title: '2026 yil uchun kitoblar ro\'yxati',
      content:
        '✓ Atomic Habits — James Clear\n✓ Deep Work — Cal Newport\n• The Alchemist — Paulo Coelho\n• Thinking, Fast and Slow — Daniel Kahneman\n• Sapiens — Yuval Noah Harari',
      category: 'personal',
      pinned: false,
      createdAt: addDaysISO(today, -45),
      updatedAt: addDaysISO(today, -7),
    },
    {
      id: uid(),
      title: 'Konferensiya tezisi uchun fikrlar',
      content:
        'Mavzu: "AI yordamida talabalar samaradorligini oshirish".\n\nAsosiy g\'oyalar:\n— Shaxsiylashtirilgan kunlik reja\n— Vaqt bloklari va fokus sessiyalari\n— Natijalarni vizual kuzatish\n\nStatistika uchun 30 nafar talaba bilan so\'rov o\'tkazish kerak.',
      category: 'study',
      pinned: false,
      createdAt: addDaysISO(today, -12),
      updatedAt: addDaysISO(today, -1),
    },
    {
      id: uid(),
      title: 'Haftalik xaridlar',
      content: 'Sut, tuxum, jo\'xori non, avokado, pomidor, yong\'oq, yashil choy, qog\'oz pechenye.',
      category: 'personal',
      pinned: false,
      createdAt: addDaysISO(today, -3),
      updatedAt: addDaysISO(today, -3),
    },
  ];

  return {
    user: profile ? { ...profile } : { ...DEFAULT_USER },
    tasks,
    events,
    goals,
    notes,
    messages: [],
    settings: { ...DEFAULT_SETTINGS },
  };
}

export type NewTask = Omit<Task, 'id' | 'createdAt' | 'completed' | 'completedAt'>;
export type NewEvent = Omit<EventItem, 'id'>;
export type NewGoal = Omit<Goal, 'id' | 'createdAt' | 'completed' | 'completedAt'>;
export type NewNote = Omit<Note, 'id' | 'createdAt' | 'updatedAt' | 'pinned'>;

interface Actions {
  addTask: (input: NewTask) => void;
  updateTask: (id: string, patch: Partial<NewTask>) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  addEvent: (input: NewEvent) => void;
  updateEvent: (id: string, patch: Partial<NewEvent>) => void;
  deleteEvent: (id: string) => void;
  toggleEvent: (id: string) => void;
  addGoal: (input: NewGoal) => void;
  updateGoal: (id: string, patch: Partial<NewGoal>) => void;
  setGoalProgress: (id: string, progress: number) => void;
  deleteGoal: (id: string) => void;
  addNote: (input: NewNote) => Note;
  updateNote: (id: string, patch: Partial<NewNote & { pinned: boolean }>) => void;
  deleteNote: (id: string) => void;
  toggleNotePin: (id: string) => void;
  addMessage: (message: Omit<ChatMessage, 'id' | 'createdAt'>) => void;
  clearMessages: () => void;
  updateSettings: (patch: Partial<Settings>) => void;
  updateUser: (patch: Partial<User>) => void;
  hydrate: (data: Partial<AppData> & { user: User }) => void;
  resetDemo: () => void;
  clearAllData: () => void;
  importData: (data: AppData) => void;
}

export type AppState = AppData & Actions;

export const useApp = create<AppState>()((set, get) => ({
  ...createSeed(),

      addTask: (input) =>
        set((s) => ({
          tasks: [
            {
              ...input,
              id: uid(),
              completed: false,
              completedAt: null,
              createdAt: new Date().toISOString(),
            },
            ...s.tasks,
          ],
        })),

      updateTask: (id, patch) =>
        set((s) => ({
          tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)),
        })),

      toggleTask: (id) =>
        set((s) => ({
          tasks: s.tasks.map((t) =>
            t.id === id
              ? {
                  ...t,
                  completed: !t.completed,
                  completedAt: !t.completed ? new Date().toISOString() : null,
                }
              : t,
          ),
        })),

      deleteTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),

      addEvent: (input) => set((s) => ({ events: [...s.events, { ...input, id: uid(), priority: (input as any).priority || 'medium', completed: Boolean((input as any).completed), completedAt: (input as any).completedAt ?? null }] })),

      updateEvent: (id, patch) =>
        set((s) => ({
          events: s.events.map((e) => (e.id === id ? { ...e, ...patch } : e)),
        })),

      deleteEvent: (id) => set((s) => ({ events: s.events.filter((e) => e.id !== id) })),

      toggleEvent: (id) =>
        set((s) => ({
          events: s.events.map((e) =>
            e.id === id ? { ...e, completed: !e.completed, completedAt: !e.completed ? new Date().toISOString() : null } : e,
          ),
        })),

      addGoal: (input) =>
        set((s) => ({
          goals: [
            {
              ...input,
              id: uid(),
              completed: false,
              completedAt: null,
              createdAt: new Date().toISOString(),
            },
            ...s.goals,
          ],
        })),

      updateGoal: (id, patch) =>
        set((s) => ({
          goals: s.goals.map((g) => (g.id === id ? { ...g, ...patch } : g)),
        })),

      setGoalProgress: (id, progress) =>
        set((s) => ({
          goals: s.goals.map((g) => {
            if (g.id !== id) return g;
            const next = Math.max(0, Math.min(100, Math.round(progress)));
            return {
              ...g,
              progress: next,
              completed: next >= 100,
              completedAt: next >= 100 ? g.completedAt ?? new Date().toISOString() : null,
            };
          }),
        })),

      deleteGoal: (id) => set((s) => ({ goals: s.goals.filter((g) => g.id !== id) })),

      addNote: (input) => {
        const note: Note = {
          ...input,
          id: uid(),
          pinned: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set((s) => ({ notes: [note, ...s.notes] }));
        return note;
      },

      updateNote: (id, patch) =>
        set((s) => ({
          notes: s.notes.map((n) =>
            n.id === id ? { ...n, ...patch, updatedAt: new Date().toISOString() } : n,
          ),
        })),

      deleteNote: (id) => set((s) => ({ notes: s.notes.filter((n) => n.id !== id) })),

      toggleNotePin: (id) =>
        set((s) => ({
          notes: s.notes.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)),
        })),

      addMessage: (message) =>
        set((s) => ({
          messages: [
            ...s.messages,
            { ...message, id: uid(), createdAt: new Date().toISOString() },
          ],
        })),

      clearMessages: () => set({ messages: [] }),

      hydrate: (data) =>
        set({
          user: data.user,
          tasks: Array.isArray(data.tasks) ? data.tasks : [],
          events: Array.isArray(data.events) ? data.events.map((e: any) => ({ ...e, priority: e?.priority || 'medium', completed: Boolean(e?.completed), completedAt: e?.completedAt ?? null })) : [],
          goals: Array.isArray(data.goals) ? data.goals : [],
          notes: Array.isArray(data.notes) ? data.notes : [],
          messages: Array.isArray(data.messages) ? data.messages : [],
          settings: { ...DEFAULT_SETTINGS, ...(data.settings ?? {}) },
        }),

      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),

      updateUser: (patch) => set((s) => ({ user: { ...s.user, ...patch } })),

      resetDemo: () => {
        const seeded = createSeed(get().user);
        set({ ...seeded, settings: get().settings });
      },

      clearAllData: () =>
        set({
          tasks: [],
          events: [],
          goals: [],
          notes: [],
          messages: [],
        }),

      importData: (data) =>
        set({
          user: get().user,
          tasks: Array.isArray(data.tasks) ? data.tasks : [],
          events: Array.isArray(data.events) ? data.events.map((e: any) => ({ ...e, priority: e?.priority || 'medium', completed: Boolean(e?.completed), completedAt: e?.completedAt ?? null })) : [],
          goals: Array.isArray(data.goals) ? data.goals : [],
          notes: Array.isArray(data.notes) ? data.notes : [],
          messages: Array.isArray(data.messages) ? data.messages : [],
          settings: { ...DEFAULT_SETTINGS, ...data.settings },
        }),
}));

export const hasAiConfigured = (settings: Settings) =>
  Boolean(settings.aiKey.trim() && settings.aiBase.trim());
