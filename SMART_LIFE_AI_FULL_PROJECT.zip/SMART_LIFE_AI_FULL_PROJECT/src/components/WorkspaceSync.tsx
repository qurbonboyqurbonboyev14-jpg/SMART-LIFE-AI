import { useEffect } from 'react';
import { api, toWorkspaceData } from '../lib/api';
import { useAuth } from '../lib/auth';
import { useApp } from '../lib/store';
import { writeAiKey } from '../lib/storage';

/**
 * Persists workspace changes to D1 with a short debounce. Profile data is
 * saved through the profile endpoint, and AI keys never leave the browser.
 */
export default function WorkspaceSync() {
  const status = useAuth((s) => s.status);
  const userId = useAuth((s) => s.user?.id);

  useEffect(() => {
    if (status !== 'authed' || !userId) return;

    let timer: number | undefined;
    let running = false;
    let pending = false;
    let disposed = false;
    let last = useApp.getState();

    const flush = async () => {
      if (running) {
        pending = true;
        return;
      }
      running = true;
      do {
        pending = false;
        const snapshot = toWorkspaceData(useApp.getState());
        try {
          await api.saveWorkspace(snapshot);
        } catch (error) {
          console.warn('Workspace sync failed', error);
        }
      } while (pending && !disposed);
      running = false;
    };

    const schedule = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(flush, 800);
    };

    const unsubscribe = useApp.subscribe((state) => {
      if (
        state.tasks === last.tasks &&
        state.events === last.events &&
        state.goals === last.goals &&
        state.notes === last.notes &&
        state.messages === last.messages &&
        state.settings === last.settings
      ) {
        return;
      }
      const aiKeyChanged = state.settings.aiKey !== last.settings.aiKey;
      last = state;
      if (aiKeyChanged) writeAiKey(userId, state.settings.aiKey);
      schedule();
    });

    const onVisibility = () => {
      if (document.visibilityState === 'hidden') {
        window.clearTimeout(timer);
        void flush();
      }
    };

    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', onVisibility);

    return () => {
      disposed = true;
      unsubscribe();
      window.clearTimeout(timer);
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', onVisibility);
    };
  }, [status, userId]);

  return null;
}
