export type Lang = 'uz' | 'ru' | 'en';
export type Theme = 'dark' | 'light';
export type Category = 'study' | 'work' | 'personal' | 'other';
export type Priority = 'low' | 'medium' | 'high';

export interface Appearance {
  profileFrame?: string;
  usernameEffect?: string;
  usernameColor?: string;
  borderColor?: string;
  glowEffect?: string;
  profileTheme?: string;
  // API aliases / persistence fields
  selectedFrameId?: string;
  selectedNicknameEffect?: string;
  selectedNicknameColor?: string;
  customizationUpdatedAt?: string | null;
  // VIP media customization
  coverUrl?: string;
  coverType?: 'image' | 'video' | '';
  coverPosX?: number;
  coverPosY?: number;
  coverScale?: number;
  bgUrl?: string;
  bgType?: 'image' | 'video' | '';
  bgPosX?: number;
  bgPosY?: number;
  bgScale?: number;
  bgBlur?: number;
  bgOverlay?: number;
}

export interface User extends Appearance {
  id: string;
  userCode?: string;
  name: string;
  firstName?: string;
  lastName?: string;
  username: string;
  email: string;
  bio: string;
  interests: string;
  goals: string;
  avatar: string;
  status?: string;
  authProvider?: string;
  isVip?: boolean;
  isOwner?: boolean;
  online?: boolean;
  lastSeenAt?: string | null;
  joinedAt: string;
}

export interface FriendProfile extends Appearance {
  id: string;
  userCode: string;
  name: string;
  username: string;
  avatar: string;
  bio?: string;
  interests?: string;
  isVip?: boolean;
  isOwner?: boolean;
  online?: boolean;
  lastSeenAt?: string | null;
  since?: string;
}

export interface FriendRequestItem extends Appearance {
  requestId: string;
  id: string;
  userCode: string;
  name: string;
  username: string;
  avatar: string;
  isVip?: boolean;
  isOwner?: boolean;
  online?: boolean;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  type: string;
  message: string;
  data?: Record<string, unknown>;
  read: boolean;
  createdAt: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  category: Category;
  priority: Priority;
  due: string; // yyyy-mm-dd
  completed: boolean;
  createdAt: string;
  completedAt: string | null;
}

export interface EventItem {
  id: string;
  title: string;
  date: string; // yyyy-mm-dd
  start: string; // HH:mm
  end: string; // HH:mm
  category: Category;
  priority?: Priority;
  reminder: number; // minutes before, 0 = off
  note: string;
  completed?: boolean;
  completedAt?: string | null;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  category: Category;
  targetDate: string;
  progress: number; // 0..100
  completed: boolean;
  createdAt: string;
  completedAt: string | null;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  category: Category;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  createdAt: string;
  simulated?: boolean;
}

export interface Settings {
  theme: Theme;
  language: Lang;
  notifications: boolean;
  dailySummary: boolean;
  sound: boolean;
  reminderLead: number;
  aiKey: string;
  aiBase: string;
  aiModel: string;
}

export interface AppData {
  user: User;
  tasks: Task[];
  events: EventItem[];
  goals: Goal[];
  notes: Note[];
  messages: ChatMessage[];
  settings: Settings;
}

export interface ChatConversation {
  conversationId: string;
  friend: FriendProfile;
  lastMessage: { text: string; at: string | null } | null;
  unread: number;
  typing: boolean;
  blockedByMe: boolean;
  blockedMe: boolean;
  updatedAt: string;
}

export interface DirectMessage {
  id: string;
  senderId: string;
  text: string;
  createdAt: string;
  deleted?: boolean;
  deletedForAll?: boolean;
}

export const CATEGORIES: Category[] = ['study', 'work', 'personal', 'other'];
export const PRIORITIES: Priority[] = ['low', 'medium', 'high'];
export const AVATARS = ['🦋', '🌙', '✨', '🚀', '🌿', '🎧', '🪐', '🔥', '🌸', '🦉', '💎', '🧠'];
