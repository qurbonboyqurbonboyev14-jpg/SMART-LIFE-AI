import { useCallback } from 'react';
import uz, { type TranslationKey } from './locales/uz';
import ru from './locales/ru';
import en from './locales/en';
import type { Lang } from './types';
import { useApp } from './store';

export type { TranslationKey };

export const dictionaries: Record<Lang, typeof uz> = { uz, ru, en };

export function translate(lang: Lang, key: TranslationKey, vars?: Record<string, string | number>) {
  const dict = dictionaries[lang] ?? uz;
  let value: string = dict[key] ?? uz[key] ?? key;
  if (vars) {
    for (const [k, v] of Object.entries(vars)) {
      value = value.split(`{${k}}`).join(String(v));
    }
  }
  return value;
}

export const useT = () => {
  const lang = useApp((s) => s.settings.language);
  const t = useCallback(
    (key: TranslationKey, vars?: Record<string, string | number>) => translate(lang, key, vars),
    [lang],
  );
  return { t, lang };
};

export const localeTag: Record<Lang, string> = { uz: 'uz-UZ', ru: 'ru-RU', en: 'en-GB' };
