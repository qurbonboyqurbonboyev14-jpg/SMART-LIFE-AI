import { useEffect, useRef, useState } from 'react';
import {
  HashRouter,
  Link,
  Navigate,
  Route,
  Routes,
  useLocation,
} from 'react-router-dom';
import { Loader2, Sparkles } from 'lucide-react';
import Layout from './components/Layout';
import Intro from './components/Intro';
import WorkspaceSync from './components/WorkspaceSync';
import { ToastProvider, useToast } from './components/Toast';
import { useApp } from './lib/store';
import { useAuth } from './lib/auth';
import { useT } from './lib/i18n';
import { formatClock, todayISO } from './lib/date';
import { dailyProgress } from './lib/analytics';
import AuthPage from './pages/Auth';
import Dashboard from './pages/Dashboard';
import Assistant from './pages/Assistant';
import Tasks from './pages/Tasks';
import Calendar from './pages/Calendar';
import Goals from './pages/Goals';
import Notes from './pages/Notes';
import Stats from './pages/Stats';
import Friends from './pages/Friends';
import Messages from './pages/Messages';
import Profile from './pages/Profile';
import AdminPage from './pages/Admin';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'auto' }); }, [pathname]);
  return null;
}

function ThemeLanguage() {
  const theme = useApp((s) => s.settings.theme);
  const language = useApp((s) => s.settings.language);
  const status = useAuth((s) => s.status);

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', theme);
    root.style.colorScheme = theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#07070d' : '#f3f3fa');
    try { localStorage.setItem('sl_theme', theme); } catch { /* ignore */ }
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
    try { localStorage.setItem('sl_lang', language); } catch { /* ignore */ }
  }, [language, status]);

  return null;
}

function ReminderWatcher() {
  const { t } = useT();
  const toast = useToast();
  const events = useApp((s) => s.events);
  const tasks = useApp((s) => s.tasks);
  const notifications = useApp((s) => s.settings.notifications);
  const dailySummary = useApp((s) => s.settings.dailySummary);
  const fired = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!dailySummary) return;
    const key = `smartlife.summary.${todayISO()}`;
    try { if (localStorage.getItem(key)) return; localStorage.setItem(key, '1'); } catch { return; }
    const progress = dailyProgress(tasks);
    toast({ title: t('dailyProgress'), description: t('todaySummary', { done: progress.done, total: progress.total }), tone: 'info' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!notifications) return;
    const tick = () => {
      const now = new Date();
      const minutes = now.getHours() * 60 + now.getMinutes();
      const today = todayISO();
      for (const event of events) {
        if (event.date !== today || !event.reminder) continue;
        const [h, m] = event.start.split(':').map(Number);
        const start = (h || 0) * 60 + (m || 0);
        if (start - event.reminder <= minutes && minutes < start) {
          const key = `${event.id}-${today}`;
          if (fired.current.has(key)) continue;
          fired.current.add(key);
          toast({
            title: t('reminderToastTitle'),
            description: t('reminderToastBody', { title: event.title, time: formatClock(new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m)) }),
            tone: 'info',
          });
        }
      }
    };
    tick();
    const id = window.setInterval(tick, 30000);
    return () => window.clearInterval(id);
  }, [events, notifications, t, toast]);

  return null;
}

function NotFound() {
  const { t } = useT();
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
      <span className="logo-mark mb-5 h-14 w-14"><Sparkles size={24} /></span>
      <p className="font-display text-5xl font-extrabold grad-text">404</p>
      <h1 className="mt-3 font-display text-xl font-bold">{t('noResultsTitle')}</h1>
      <p className="mt-1 max-w-sm text-sm text-muted">{t('noResultsText')}</p>
      <Link to="/" className="btn btn-primary mt-6">{t('navDashboard')}</Link>
    </div>
  );
}

function BootLoader({ label }: { label: string }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-bg text-ink">
      <div className="flex flex-col items-center gap-3">
        <span className="logo-mark h-14 w-14"><Sparkles size={24} /></span>
        <p className="flex items-center gap-2 text-sm text-muted"><Loader2 size={15} className="animate-spin" /> {label}</p>
      </div>
    </div>
  );
}

function AppShell() {
  return (
    <ToastProvider>
      <WorkspaceSync />
      <ScrollToTop />
      <ReminderWatcher />
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="/assistant" element={<Assistant />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path="/goals" element={<Goals />} />
          <Route path="/notes" element={<Notes />} />
          <Route path="/friends" element={<Friends />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </ToastProvider>
  );
}

export default function App() {
  const status = useAuth((s) => s.status);
  const boot = useAuth((s) => s.boot);
  const [introDone, setIntroDone] = useState(() => new URLSearchParams(window.location.search).get('nointro') === '1');

  useEffect(() => { void boot(); }, [boot]);
  useEffect(() => {
    if (introDone) return;
    const id = window.setTimeout(() => setIntroDone(true), 3000);
    return () => window.clearTimeout(id);
  }, [introDone]);

  return (
    <HashRouter>
      <ThemeLanguage />
      {!introDone ? <Intro /> : null}
      {introDone && status === 'booting' ? <BootLoader label="Loading your secure workspace..." /> : null}
      {introDone && status === 'guest' ? (
        <ToastProvider>
          <Routes>
            <Route path="/admin" element={<AdminPage />} />
            <Route path="*" element={<AuthPage />} />
          </Routes>
        </ToastProvider>
      ) : null}
      {introDone && status === 'authed' ? (
        <Routes>
          <Route path="/admin" element={<Navigate to="/" replace />} />
          <Route path="/*" element={<AppShell />} />
        </Routes>
      ) : null}
    </HashRouter>
  );
}
