import { useId, useMemo, useState } from 'react';
import { cn } from '../lib/cn';

export interface Datum {
  label: string;
  value: number;
  iso?: string;
}

/* ------------------------------------------------------------------ */
/*  Bar chart                                                          */
/* ------------------------------------------------------------------ */
export function BarChart({
  data,
  height = 170,
  className,
  suffix,
}: {
  data: Datum[];
  height?: number;
  className?: string;
  suffix?: string;
}) {
  const [active, setActive] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.value));
  const todayIso = new Date().toISOString().slice(0, 10);

  return (
    <div className={cn('w-full', className)}>
      <div className="flex items-end gap-1.5 sm:gap-2.5" style={{ height }}>
        {data.map((d, i) => {
          const pct = (d.value / max) * 100;
          const isToday = d.iso === todayIso;
          const isActive = active === i;
          return (
            <div
              key={`${d.label}-${i}`}
              className="group relative flex h-full flex-1 flex-col items-center justify-end gap-2"
              onMouseEnter={() => setActive(i)}
              onMouseLeave={() => setActive(null)}
              onFocus={() => setActive(i)}
              onBlur={() => setActive(null)}
              tabIndex={0}
              role="img"
              aria-label={`${d.label}: ${d.value}`}
            >
              <div
                className={cn(
                  'pointer-events-none absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-xl border border-line/10 px-2 py-1 text-[10.5px] font-semibold text-ink transition-all duration-200 tooltip-bubble',
                  isActive ? 'opacity-100' : 'opacity-0 translate-y-1',
                )}
                style={{ bottom: `calc(${Math.max(pct, 4)}% + 26px)` }}
              >
                {d.value}
                {suffix ? ` ${suffix}` : ''}
              </div>
              <div className="relative flex w-full items-end justify-center" style={{ height: height - 22 }}>
                <div
                  className={cn(
                    'w-full max-w-[32px] rounded-t-[9px] transition-all duration-500',
                    isActive ? 'brightness-125' : '',
                  )}
                  style={{
                    height: `${Math.max(pct, d.value > 0 ? 6 : 2)}%`,
                    backgroundImage:
                      d.value > 0
                        ? isToday || isActive
                          ? 'linear-gradient(180deg, #c4b5fd 0%, #8b5cf6 42%, rgba(79,124,255,.35) 100%)'
                          : 'linear-gradient(180deg, rgba(167,139,250,.85) 0%, #7c5cff 50%, rgba(79,124,255,.18) 100%)'
                        : 'linear-gradient(180deg, rgba(255,255,255,.07), rgba(255,255,255,.02))',
                    boxShadow:
                      d.value > 0 && (isToday || isActive)
                        ? '0 0 24px -2px rgba(139,92,246,.65)'
                        : undefined,
                  }}
                />
              </div>
              <span
                className={cn(
                  'max-w-full truncate text-[9.5px] font-medium uppercase tracking-wide transition-colors sm:text-[10px]',
                  isActive || isToday ? 'text-ink' : 'text-muted',
                )}
              >
                {d.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Area chart                                                         */
/* ------------------------------------------------------------------ */
const smoothPath = (points: [number, number][]) => {
  if (points.length === 0) return '';
  if (points.length < 3) return points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0]},${p[1]}`).join(' ');
  let d = `M${points[0][0]},${points[0][1]}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const cp1x = p1[0] + (p2[0] - p0[0]) / 6;
    const cp1y = p1[1] + (p2[1] - p0[1]) / 6;
    const cp2x = p2[0] - (p3[0] - p1[0]) / 6;
    const cp2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${cp1x},${cp1y} ${cp2x},${cp2y} ${p2[0]},${p2[1]}`;
  }
  return d;
};

export function AreaChart({ data, height = 190 }: { data: Datum[]; height?: number }) {
  const id = useId().replace(/:/g, '');
  const [active, setActive] = useState<number | null>(null);
  const width = 620;
  const padX = 10;
  const padTop = 16;
  const padBottom = 26;
  const max = Math.max(1, ...data.map((d) => d.value));
  const innerW = width - padX * 2;
  const innerH = height - padTop - padBottom;

  const points = useMemo<[number, number][]>(
    () =>
      data.map((d, i) => [
        padX + (data.length === 1 ? innerW / 2 : (i / (data.length - 1)) * innerW),
        padTop + innerH - (d.value / max) * innerH,
      ]),
    [data, innerW, innerH, max],
  );

  const line = smoothPath(points);
  const area = `${line} L${points[points.length - 1]?.[0] ?? 0},${padTop + innerH} L${points[0]?.[0] ?? 0},${padTop + innerH} Z`;
  const step = Math.ceil(data.length / 7);

  return (
    <div className="relative w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full"
        style={{ height }}
        preserveAspectRatio="none"
        onMouseLeave={() => setActive(null)}
      >
        <defs>
          <linearGradient id={`area-${id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.42" />
            <stop offset="55%" stopColor="#6366f1" stopOpacity="0.14" />
            <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
          </linearGradient>
          <linearGradient id={`line-${id}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#c4b5fd" />
            <stop offset="50%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#38bdf8" />
          </linearGradient>
        </defs>

        {[0, 0.25, 0.5, 0.75, 1].map((f) => (
          <line
            key={f}
            x1={padX}
            x2={width - padX}
            y1={padTop + innerH * f}
            y2={padTop + innerH * f}
            strokeWidth="1"
            style={{ stroke: 'rgb(var(--line) / 0.07)' }}
            strokeDasharray="4 6"
          />
        ))}

        <path d={area} fill={`url(#area-${id})`} />
        <path
          d={line}
          fill="none"
          stroke={`url(#line-${id})`}
          strokeWidth="2.5"
          strokeLinecap="round"
          style={{ filter: 'drop-shadow(0 4px 12px rgba(124,92,255,.45))' }}
        />

        {active !== null && points[active] ? (
          <>
            <line
              x1={points[active][0]}
              x2={points[active][0]}
              y1={padTop}
              y2={padTop + innerH}
              strokeWidth="1"
              style={{ stroke: 'rgb(var(--brand) / .4)' }}
              strokeDasharray="3 4"
            />
            <circle cx={points[active][0]} cy={points[active][1]} r="5.5" fill="#a78bfa" />
            <circle cx={points[active][0]} cy={points[active][1]} r="10" fill="#a78bfa" opacity="0.18" />
          </>
        ) : null}

        {data.map((d, i) => {
          const x = points[i][0];
          const segWidth = innerW / Math.max(1, data.length - 1);
          return (
            <g key={i}>
              <rect
                x={x - segWidth / 2}
                y={0}
                width={segWidth}
                height={height}
                fill="transparent"
                onMouseEnter={() => setActive(i)}
              />
              {i % step === 0 || i === data.length - 1 ? (
                <text
                  x={x}
                  y={height - 6}
                  textAnchor={i === 0 ? 'start' : i === data.length - 1 ? 'end' : 'middle'}
                  style={{ fill: 'rgb(var(--muted))', fontSize: 10, fontWeight: 500 }}
                >
                  {d.label}
                </text>
              ) : null}
            </g>
          );
        })}
      </svg>

      {active !== null && data[active] ? (
        <div
          className="pointer-events-none absolute top-1 z-10 -translate-x-1/2 rounded-xl border border-line/10 px-2.5 py-1.5 text-center tooltip-bubble"
          style={{ left: `${(active / Math.max(1, data.length - 1)) * 100}%` }}
        >
          <p className="text-[11px] font-bold leading-none">{data[active].value}</p>
          <p className="mt-1 text-[9px] leading-none text-muted">{data[active].label}</p>
        </div>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Donut                                                              */
/* ------------------------------------------------------------------ */
export function Donut({
  segments,
  centerLabel,
  centerValue,
  size = 168,
  thickness = 18,
}: {
  segments: { key: string; label: string; value: number; color: string }[];
  centerLabel: string;
  centerValue: string;
  size?: number;
  thickness?: number;
}) {
  const [active, setActive] = useState<number | null>(null);
  const total = segments.reduce((s, x) => s + x.value, 0);
  const radius = (size - thickness) / 2;
  const circumference = 2 * Math.PI * radius;
  let cumulative = 0;

  const shown = active !== null ? segments[active] : null;

  return (
    <div className="flex flex-col items-center gap-5 sm:flex-row sm:items-center sm:gap-7">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            strokeWidth={thickness}
            style={{ stroke: 'rgb(var(--line) / 0.06)' }}
          />
          {total > 0 &&
            segments.map((seg, i) => {
              if (seg.value <= 0) return null;
              const fraction = seg.value / total;
              const len = Math.max(0, fraction * circumference - 3);
              const offset = cumulative * circumference;
              cumulative += fraction;
              const isActive = active === i;
              return (
                <circle
                  key={seg.key}
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  fill="none"
                  stroke={seg.color}
                  strokeWidth={isActive ? thickness + 5 : thickness}
                  strokeLinecap="round"
                  strokeDasharray={`${len} ${circumference - len}`}
                  strokeDashoffset={-offset}
                  onMouseEnter={() => setActive(i)}
                  onMouseLeave={() => setActive(null)}
                  style={{
                    transition: 'stroke-width .2s ease, opacity .2s ease',
                    opacity: active === null || isActive ? 1 : 0.45,
                    cursor: 'pointer',
                    filter: isActive ? `drop-shadow(0 0 10px ${seg.color})` : undefined,
                  }}
                />
              );
            })}
        </svg>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="font-display text-2xl font-extrabold leading-none tracking-tight">
            {shown ? shown.value : centerValue}
          </span>
          <span className="mt-1 max-w-[90px] truncate text-[10px] font-medium uppercase tracking-wider text-muted">
            {shown ? shown.label : centerLabel}
          </span>
        </div>
      </div>
      <div className="w-full space-y-2">
        {segments.map((seg, i) => (
          <button
            key={seg.key}
            type="button"
            onMouseEnter={() => setActive(i)}
            onMouseLeave={() => setActive(null)}
            onFocus={() => setActive(i)}
            onBlur={() => setActive(null)}
            className={cn(
              'flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-left transition-colors',
              active === i ? 'bg-line/[0.05]' : '',
            )}
          >
            <span className="h-2 w-2 rounded-full" style={{ background: seg.color, boxShadow: `0 0 8px ${seg.color}66` }} />
            <span className="flex-1 truncate text-[12px] text-muted">{seg.label}</span>
            <span className="text-[12px] font-semibold">{seg.value}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Heatmap                                                            */
/* ------------------------------------------------------------------ */
export function Heatmap({
  data,
  labels,
}: {
  data: { iso: string; value: number; future?: boolean }[];
  labels: { less: string; more: string };
}) {
  const columns = useMemo(() => {
    const cols: { iso: string; value: number; future?: boolean }[][] = [];
    for (let i = 0; i < data.length; i += 7) cols.push(data.slice(i, i + 7));
    return cols;
  }, [data]);

  const max = Math.max(1, ...data.map((d) => d.value));

  const shade = (value: number, future?: boolean) => {
    if (future) return 'rgb(var(--line) / 0.025)';
    if (value <= 0) return 'rgb(var(--line) / 0.07)';
    const ratio = value / max;
    if (ratio <= 0.25) return 'rgb(var(--brand) / 0.28)';
    if (ratio <= 0.5) return 'rgb(var(--brand) / 0.48)';
    if (ratio <= 0.75) return 'rgb(var(--brand) / 0.7)';
    return 'rgb(var(--brand) / 0.95)';
  };

  return (
    <div>
      <div className="flex gap-[5px] overflow-x-auto pb-1">
        {columns.map((col, ci) => (
          <div key={ci} className="flex flex-col gap-[5px]">
            {col.map((cell) => (
              <div
                key={cell.iso}
                title={`${cell.iso} · ${cell.value}`}
                className="h-[15px] w-[15px] rounded-[4px] transition-transform hover:scale-125 sm:h-[17px] sm:w-[17px]"
                style={{
                  background: shade(cell.value, cell.future),
                  boxShadow: cell.value >= max * 0.75 ? '0 0 10px rgba(139,92,246,.35)' : undefined,
                }}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center justify-end gap-1.5 text-[10px] text-muted">
        <span>{labels.less}</span>
        {[0, 0.28, 0.48, 0.7, 0.95].map((v, i) => (
          <span
            key={i}
            className="h-[11px] w-[11px] rounded-[3px]"
            style={{ background: v === 0 ? 'rgb(var(--line) / 0.07)' : `rgb(var(--brand) / ${v})` }}
          />
        ))}
        <span>{labels.more}</span>
      </div>
    </div>
  );
}
