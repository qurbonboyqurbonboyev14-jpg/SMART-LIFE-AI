import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  ArrowUpRight,
  BarChart3,
  Bell,
  CalendarDays,
  CheckSquare2,
  ChevronDown,
  ChevronRight,
  Clock3,
  Copy,
  Globe2,
  Home,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageCircle,
  Moon,
  NotebookPen,
  Settings2,
  Shield,
  Sparkles,
  Sun,
  Target,
  Users,
  X,
  type LucideIcon,
} from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { useApp } from '../lib/store';
import { useT, type TranslationKey } from '../lib/i18n';
import { cn } from '../lib/cn';
import { formatClock, formatDate, formatLongDate, todayISO } from '../lib/date';
import { isOverdue, upcomingEvents } from '../lib/analytics';
import type { AppNotification, Lang } from '../lib/types';
import { Avatar, DisplayName } from './ui';
import { useToast } from './Toast';

export const NAV: { to: string; key: TranslationKey; icon: LucideIcon }[] = [
  { to: '/', key: 'navDashboard', icon: LayoutDashboard },
  { to: '/assistant', key: 'navAssistant', icon: Sparkles },
  { to: '/tasks', key: 'navTasks', icon: CheckSquare2 },
  { to: '/calendar', key: 'navCalendar', icon: CalendarDays },
  { to: '/goals', key: 'navGoals', icon: Target },
  { to: '/notes', key: 'navNotes', icon: NotebookPen },
  { to: '/friends', key: 'navFriends', icon: Users },
  { to: '/messages', key: 'messages', icon: MessageCircle },
  { to: '/stats', key: 'navStats', icon: BarChart3 },
  { to: '/profile', key: 'navProfile', icon: Settings2 },
];

function useNow(interval = 15000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), interval);
    return () => window.clearInterval(id);
  }, [interval]);
  return now;
}

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { t } = useT();
  const toast = useToast();
  const user = useApp((s) => s.user);
  const logout = useAuth((s) => s.logout);

  const copyId = async () => {
    if (!user.userCode) return;
    try { await navigator.clipboard.writeText(user.userCode); toast({ title: t('idCopied'), tone: 'success' }); } catch { toast({ title: user.userCode, tone: 'info' }); }
  };

  return (
    <div className="flex h-full flex-col">
      <Link to="/" onClick={onNavigate} className="flex items-center gap-3 px-5 pb-6 pt-5">
        <span className="logo-mark h-10 w-10"><Sparkles size={20} strokeWidth={2.2} /></span>
        <span className="leading-tight">
          <span className="block font-display text-[15px] font-extrabold tracking-[0.02em]">SMART LIFE <span className="grad-text">AI</span></span>
          <span className="mt-0.5 block text-[9.5px] font-medium uppercase tracking-[0.22em] text-muted">{t('workspace')}</span>
        </span>
      </Link>

      <div className="px-3">
        <div className="mb-3 rounded-2xl border border-line/[0.07] bg-line/[0.025] px-3 py-2.5">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="truncate text-[11.5px] font-semibold leading-tight">{user.userCode || t('workspace')}</p>
              <p className="truncate text-[10px] text-muted">{t('cloudSynced')}</p>
            </div>
            {user.userCode ? (
              <button type="button" onClick={copyId} className="icon-btn h-7 w-7 shrink-0" title={t('copyId')} aria-label={t('copyId')}><Copy size={12} /></button>
            ) : null}
          </div>
        </div>

        <p className="eyebrow px-2 pb-2 pt-1">{t('navigation')}</p>
        <nav className="space-y-1">
          {NAV.map((item) => {
            const Icon = item.icon;
            const unread = item.to === '/messages' ? ((window as any).__slUnreadMsgs || 0) : 0;
            return (
              <NavLink key={item.to} to={item.to} end={item.to === '/'} onClick={onNavigate}
                className={({ isActive }) => cn('nav-item', isActive && 'nav-item-active')}>
                <Icon size={17} strokeWidth={1.9} />
                <span className="truncate">{t(item.key)}</span>
                {unread > 0 ? <span className="ml-auto grid h-5 min-w-5 place-items-center rounded-full bg-brand px-1.5 text-[10px] font-bold text-white">{unread > 99 ? '99+' : unread}</span> : null}
              </NavLink>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto space-y-3 p-3">
        <div className="relative overflow-hidden rounded-[22px] border border-brand/25 bg-gradient-to-br from-brand/[0.22] via-brand2/[0.1] to-transparent p-4">
          <div className="absolute -right-8 -top-10 h-24 w-24 rounded-full bg-brand/30 blur-2xl" />
          <div className="relative">
            <span className="mb-2 inline-grid h-8 w-8 place-items-center rounded-xl bg-white/10 text-violet-200"><Sparkles size={16} /></span>
            <p className="font-display text-[13px] font-bold leading-snug">{t('aiCardTitle')}</p>
            <p className="mt-1 text-[11px] leading-relaxed text-muted">{t('aiCardText')}</p>
            <Link to="/assistant" onClick={onNavigate} className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-1.5 text-[11px] font-semibold text-ink transition hover:bg-white/15">
              {t('aiCardCta')} <ArrowUpRight size={12} />
            </Link>
          </div>
        </div>

        <div className="rounded-2xl border border-transparent px-2 py-2">
          <Link to="/profile" onClick={onNavigate} className="flex items-center gap-3 transition hover:opacity-90">
            <Avatar emoji={user.avatar} size={38} frame={user.profileFrame} glowEffect={user.glowEffect} online={user.online} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12.5px] font-semibold leading-tight"><DisplayName name={user.name} isVip={user.isVip} isOwner={(user as any).isOwner} effect={(user as any).selectedNicknameEffect || user.usernameEffect} color={(user as any).selectedNicknameColor || user.usernameColor} /></p>
              <p className="mt-0.5 truncate text-[10.5px] text-muted">@{user.username} · {user.userCode || ''}</p>
            </div>
            <ChevronRight size={15} className="shrink-0 text-muted" />
          </Link>
          <button type="button" onClick={() => void logout()} className="mt-2 flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-[11px] font-medium text-muted transition hover:bg-line/[0.05] hover:text-rose-300">
            <LogOut size={13} /> {t('logout')}
          </button>
        </div>
      </div>
    </div>
  );
}

const LANGS: { value: Lang; code: string }[] = [
  { value: 'uz', code: 'UZ' }, { value: 'ru', code: 'RU' }, { value: 'en', code: 'EN' },
];

function LanguageSwitcher() {
  const lang = useApp((s) => s.settings.language);
  const updateSettings = useApp((s) => s.updateSettings);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [open]);
  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => setOpen((v) => !v)} className="flex h-9 items-center gap-1.5 rounded-xl border border-line/[0.08] bg-line/[0.03] px-2.5 text-[11.5px] font-semibold text-muted transition hover:border-brand/30 hover:text-ink" aria-label="Language">
        <Globe2 size={14} /> {LANGS.find((l) => l.value === lang)?.code} <ChevronDown size={12} className={cn('transition', open && 'rotate-180')} />
      </button>
      {open ? (
        <div className="absolute right-0 top-full z-50 mt-2 w-36 overflow-hidden rounded-2xl border border-line/10 bg-[var(--sidebar)] p-1.5 shadow-2xl backdrop-blur-2xl animate-pop">
          {LANGS.map((l) => (
            <button key={l.value} type="button" onClick={() => { updateSettings({ language: l.value }); setOpen(false); }}
              className={cn('flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-left text-[12.5px] transition', lang === l.value ? 'bg-brand/15 text-ink' : 'text-muted hover:bg-line/[0.05] hover:text-ink')}>
              <span>{l.value === 'uz' ? "O'zbekcha" : l.value === 'ru' ? 'Русский' : 'English'}</span>
              <span className="text-[10px] font-bold tracking-wider text-muted">{l.code}</span>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function NotificationsButton() {
  const { t, lang } = useT();
  const navigate = useNavigate();
  const events = useApp((s) => s.events);
  const tasks = useApp((s) => s.tasks);
  const [open, setOpen] = useState(false);
  const [server, setServer] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  const next = useMemo(() => upcomingEvents(events, 3), [events]);
  const overdue = useMemo(() => tasks.filter(isOverdue).length, [tasks]);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try { const r = await api.notifications(); if (mounted) { setServer(r.notifications.slice(0, 8)); setUnread(r.unread); } } catch { /* ignore */ }
    };
    void load();
    const id = window.setInterval(load, 30000);
    return () => { mounted = false; window.clearInterval(id); };
  }, []);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [open]);

  useEffect(() => {
    if (open && unread > 0) {
      api.readNotifications().then(() => setUnread(0)).catch(() => undefined);
      setServer((s) => s.map((n) => ({ ...n, read: true })));
    }
  }, [open, unread]);

  const count = unread + next.length + (overdue > 0 ? 1 : 0);

  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => setOpen((v) => !v)} className="icon-btn relative" aria-label={t('notifications')}>
        <Bell size={16} />
        {count > 0 ? <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-gradient-to-br from-violet-400 to-sky-400 px-1 text-[9px] font-bold text-white shadow-[0_0_10px_rgba(139,92,246,.8)]">{count > 9 ? '9+' : count}</span> : null}
      </button>
      {open ? (
        <div className="absolute right-0 top-full z-50 mt-2 w-[320px] overflow-hidden rounded-3xl border border-line/10 bg-[var(--sidebar)] shadow-2xl backdrop-blur-2xl animate-pop sm:w-[360px]">
          <div className="flex items-center justify-between border-b border-line/[0.07] px-4 py-3">
            <div><p className="text-[13px] font-bold">{t('notifications')}</p><p className="text-[10.5px] text-muted">{t('notificationsHint')}</p></div>
            <span className="chip chip-brand">{count}</span>
          </div>
          <div className="scroll-thin max-h-[330px] overflow-y-auto p-2">
            {server.map((n) => (
              <button key={n.id} type="button" onClick={() => { setOpen(false); if (n.type.startsWith('friend')) navigate('/friends'); }} className="flex w-full items-start gap-2.5 rounded-2xl px-2.5 py-2.5 text-left transition hover:bg-line/[0.05]">
                <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl border border-brand/20 bg-brand/10 text-violet-300"><Users size={14} /></span>
                <span className="min-w-0 flex-1"><span className="block text-[12px] font-medium leading-snug">{n.message}</span><span className="mt-0.5 block text-[10px] text-muted">{new Date(n.createdAt).toLocaleString()}</span></span>
              </button>
            ))}
            {next.map((event) => (
              <button key={event.id} type="button" onClick={() => { setOpen(false); navigate('/calendar'); }} className="flex w-full items-center gap-3 rounded-2xl px-2.5 py-2.5 text-left transition hover:bg-line/[0.05]">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-brand/20 bg-brand/10 text-[10px] font-bold leading-none text-violet-200">
                  <span className="block text-[13px]">{event.date.slice(8, 10)}</span>
                  <span className="mt-0.5 block text-[8px] uppercase text-muted">{formatDate(event.date, lang, { month: 'short' })}</span>
                </span>
                <span className="min-w-0 flex-1"><span className="block truncate text-[12.5px] font-semibold">{event.title}</span><span className="mt-0.5 flex items-center gap-1 text-[10.5px] text-muted"><Clock3 size={10} /> {event.start} – {event.end}</span></span>
              </button>
            ))}
            {overdue > 0 ? (
              <button type="button" onClick={() => { setOpen(false); navigate('/tasks'); }} className="flex w-full items-center gap-3 rounded-2xl px-2.5 py-2.5 text-left transition hover:bg-line/[0.05]">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-rose-400/25 bg-rose-500/10 text-rose-300"><Clock3 size={16} /></span>
                <span className="min-w-0 flex-1"><span className="block text-[12.5px] font-semibold">{t('tasksOverdue')} · {overdue}</span><span className="mt-0.5 block text-[10.5px] text-muted">{t('todo')}</span></span>
              </button>
            ) : null}
            {server.length === 0 && next.length === 0 && overdue === 0 ? <div className="px-4 py-8 text-center"><Bell size={22} className="mx-auto mb-2 text-muted" /><p className="text-xs text-muted">{t('noNotifications')}</p></div> : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Topbar({ onOpenMenu }: { onOpenMenu: () => void }) {
  const { t, lang } = useT();
  const location = useLocation();
  const theme = useApp((s) => s.settings.theme);
  const updateSettings = useApp((s) => s.updateSettings);
  const user = useApp((s) => s.user);
  const now = useNow();
  const active = NAV.find((n) => (n.to === '/' ? location.pathname === '/' : location.pathname.startsWith(n.to)));
  return (
    <header className="sticky top-0 z-30 border-b border-line/[0.06] bg-[var(--sidebar)] backdrop-blur-2xl">
      <div className="flex h-[64px] items-center gap-3 px-4 sm:px-6 lg:px-8">
        <button type="button" onClick={onOpenMenu} className="icon-btn lg:hidden" aria-label={t('menu')}><Menu size={18} /></button>
        <div className="hidden min-w-0 items-center gap-2 text-[12px] sm:flex">
          <span className="hidden items-center gap-1.5 text-muted md:flex"><span className="h-1.5 w-1.5 rounded-full bg-brand/70" /> {t('workspace')}</span>
          <span className="hidden text-muted/40 md:inline">/</span>
          <span className="truncate font-semibold">{active ? t(active.key) : t('navDashboard')}</span>
        </div>
        <div className="flex-1" />
        <div className="hidden items-center gap-2 rounded-xl border border-line/[0.07] bg-line/[0.025] px-3 py-1.5 xl:flex">
          <Clock3 size={13} className="text-brand" />
          <span className="text-[11.5px] font-medium text-muted">{formatLongDate(now, lang)}</span>
          <span className="text-[11.5px] font-bold tabular-nums">{formatClock(now)}</span>
        </div>
        <div className="hidden h-6 w-px bg-line/10 sm:block" />
        <LanguageSwitcher />
        <button type="button" onClick={() => updateSettings({ theme: theme === 'dark' ? 'light' : 'dark' })} className="icon-btn" aria-label={theme === 'dark' ? t('light') : t('dark')} title={theme === 'dark' ? t('light') : t('dark')}>
          {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
        </button>
        <NotificationsButton />
        <Link to="/profile" className="ml-0.5 flex items-center gap-2 rounded-2xl border border-transparent p-0.5 pr-1 transition hover:border-line/[0.08] hover:bg-line/[0.03]" aria-label={t('navProfile')}>
          <Avatar emoji={user.avatar} size={34} frame={user.profileFrame} glowEffect={user.glowEffect} online={user.online} />
          <ChevronDown size={12} className="hidden text-muted sm:block" />
        </Link>
      </div>
    </header>
  );
}

function BottomNav({ onOpenMenu }: { onOpenMenu: () => void }) {
  const { t } = useT();
  const location = useLocation();
  const items = [
    { to: '/', labelKey: 'navDashboard' as TranslationKey, icon: Home },
    { to: '/tasks', labelKey: 'navTasks' as TranslationKey, icon: CheckSquare2 },
    { to: '/assistant', labelKey: 'navAssistant' as TranslationKey, icon: Sparkles, center: true },
    { to: '/calendar', labelKey: 'navCalendar' as TranslationKey, icon: CalendarDays },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line/[0.08] bg-[var(--sidebar)] pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl lg:hidden">
      <div className="grid grid-cols-5 items-end px-1.5 pb-1.5 pt-2">
        {items.map((item) => {
          const Icon = item.icon;
          const active = item.to === '/' ? location.pathname === '/' : location.pathname.startsWith(item.to);
          if (item.center) {
            return (
              <Link key={item.to} to={item.to} className="flex -mt-6 flex-col items-center gap-1" aria-label={t(item.labelKey)}>
                <span className={cn('grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-violet-400 via-violet-500 to-sky-400 text-white shadow-[0_12px_30px_-8px_rgba(124,92,255,.9)] transition', active && 'scale-105 ring-4 ring-brand/20')}><Icon size={20} strokeWidth={2.1} /></span>
                <span className={cn('text-[9px] font-semibold', active ? 'text-ink' : 'text-muted')}>{t(item.labelKey)}</span>
              </Link>
            );
          }
          return (
            <Link key={item.to} to={item.to} className={cn('flex flex-col items-center gap-1 rounded-xl py-1 transition', active ? 'text-ink' : 'text-muted')}>
              <span className="relative"><Icon size={19} strokeWidth={active ? 2.2 : 1.8} />{active ? <span className="absolute -bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-brand shadow-[0_0_8px_2px_rgba(139,92,246,.7)]" /> : null}</span>
              <span className="max-w-[70px] truncate text-[9px] font-medium">{t(item.labelKey)}</span>
            </Link>
          );
        })}
        <button type="button" onClick={onOpenMenu} className="flex flex-col items-center gap-1 rounded-xl py-1 text-muted">
          <Menu size={19} strokeWidth={1.8} /><span className="text-[9px] font-medium">{t('menu')}</span>
        </button>
      </div>
    </nav>
  );
}

function MediaBackground({ user }: { user: any }) {
  const url = user?.bgUrl || '';
  const type = user?.bgType || '';
  if (!url) return null;
  const posX = Number.isFinite(user?.bgPosX) ? user.bgPosX : 50;
  const posY = Number.isFinite(user?.bgPosY) ? user.bgPosY : 50;
  const scale = Number.isFinite(user?.bgScale) ? user.bgScale : 100;
  const blur = Number.isFinite(user?.bgBlur) ? user.bgBlur : 0;
  const overlay = Number.isFinite(user?.bgOverlay) ? user.bgOverlay : 45;
  const objPos = posX + '% ' + posY + '%';
  const dark = document.documentElement.getAttribute('data-theme') !== 'light';
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      {type === 'video' ? (
        <video src={url} autoPlay loop muted playsInline preload="metadata" className="h-full w-full object-cover" style={{ objectPosition: objPos, transform: 'scale(' + (scale/100) + ')', filter: blur ? 'blur(' + blur + 'px)' : undefined }} />
      ) : (
        <img src={url} alt="" loading="lazy" className="h-full w-full object-cover" style={{ objectPosition: objPos, transform: 'scale(' + (scale/100) + ')', filter: blur ? 'blur(' + blur + 'px)' : undefined }} />
      )}
      <div className="absolute inset-0" style={{ background: dark ? 'rgba(6,6,12,' + (overlay/100) + ')' : 'rgba(243,243,250,' + (Math.max(overlay,35)/100) + ')' }} />
    </div>
  );
}

export default function Layout() {
  const { t } = useT();
  const location = useLocation();
  const bgUser = useApp((s) => s.user);
  const [drawer, setDrawer] = useState(false);
  const [unreadMsgs, setUnreadMsgs] = useState(0);
  useEffect(() => {
    let mounted = true;
    const tick = async () => {
      try {
        await api.presencePing();
        const r = await api.chatConversations();
        if (mounted) setUnreadMsgs((r.conversations || []).reduce((sum, c) => sum + (c.unread || 0), 0));
      } catch { /* ignore */ }
    };
    void tick();
    const id = window.setInterval(tick, 12000);
    return () => { mounted = false; window.clearInterval(id); };
  }, []);
  useEffect(() => { setDrawer(false); }, [location.pathname]);
  useEffect(() => { document.body.style.overflow = drawer ? 'hidden' : ''; return () => { document.body.style.overflow = ''; }; }, [drawer]);
  return (
    <div className="relative min-h-screen">
      <MediaBackground user={bgUser} />
      <div className="app-bg" aria-hidden><span className="orb orb-1" /><span className="orb orb-2" /><span className="orb orb-3" /></div>
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[264px] border-r border-line/[0.07] bg-[var(--sidebar)] backdrop-blur-2xl lg:block"><SidebarContent /></aside>
      <div className={cn('fixed inset-0 z-[70] lg:hidden', !drawer && 'pointer-events-none')}>
        <div onClick={() => setDrawer(false)} className={cn('absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300', drawer ? 'opacity-100' : 'opacity-0')} />
        <aside className={cn('absolute inset-y-0 left-0 w-[288px] border-r border-line/10 bg-[var(--sidebar)] backdrop-blur-2xl transition-transform duration-300 ease-out', drawer ? 'translate-x-0' : '-translate-x-full')}>
          <button type="button" onClick={() => setDrawer(false)} className="icon-btn absolute right-3 top-4 z-10 h-8 w-8" aria-label={t('close')}><X size={15} /></button>
          <SidebarContent onNavigate={() => setDrawer(false)} />
        </aside>
      </div>
      <div className="relative z-10 lg:pl-[264px]">
        <Topbar onOpenMenu={() => setDrawer(true)} />
        <main className="mx-auto w-full max-w-[1440px] px-4 pb-28 pt-5 sm:px-6 sm:pt-7 lg:px-8 lg:pb-12">
          <div key={location.pathname} className="page-enter"><Outlet /></div>
        </main>
        <footer className="hidden items-center justify-between px-8 pb-6 text-[10.5px] text-muted/70 lg:flex">
          <span>© {new Date().getFullYear()} SMART LIFE AI</span>
          <span className="flex items-center gap-1.5"><span className="h-1 w-1 rounded-full bg-emerald-400" /> {t('cloudSynced')}</span>
        </footer>
      </div>
      <BottomNav onOpenMenu={() => setDrawer(true)} />
    </div>
  );
}
