import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Ban, Flag, MessageCircle, Search, Send, ShieldAlert, Trash2 } from 'lucide-react';
import { api } from '../lib/api';
import type { ChatConversation, DirectMessage, FriendProfile } from '../lib/types';
import { useAuth } from '../lib/auth';
import { useT } from '../lib/i18n';
import { useToast } from '../components/Toast';
import { Avatar, DisplayName, EmptyState, PageHeader } from '../components/ui';

function fmtTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function Messages() {
  const { t } = useT();
  const toast = useToast();
  const me = useAuth((s) => s.user);
  const [params, setParams] = useSearchParams();
  const activeId = params.get('with') || '';
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [peer, setPeer] = useState<FriendProfile | null>(null);
  const [typing, setTyping] = useState(false);
  const [blockedByMe, setBlockedByMe] = useState(false);
  const [blockedMe, setBlockedMe] = useState(false);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [searchQ, setSearchQ] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const typingTimer = useRef<number | null>(null);
  const lastTypingSent = useRef(0);

  const loadConversations = async (silent = false) => {
    try {
      const r = await api.chatConversations();
      setConversations(r.conversations || []);
      if (!silent) setLoading(false);
    } catch { if (!silent) setLoading(false); }
  };

  const loadMessages = async (withId: string) => {
    if (!withId) { setMessages([]); setPeer(null); return; }
    try {
      const r = await api.chatMessages(withId);
      setMessages(r.messages || []);
      setPeer(r.peer || null);
      setTyping(Boolean(r.typing));
      setBlockedByMe(Boolean(r.blockedByMe));
      setBlockedMe(Boolean(r.blockedMe));
    } catch { /* ignore */ }
  };

  useEffect(() => { void loadConversations(); }, []);
  useEffect(() => { void loadMessages(activeId); }, [activeId]);

  useEffect(() => {
    const id = window.setInterval(() => {
      void api.presencePing().catch(() => undefined);
      void loadConversations(true);
      if (activeId) void loadMessages(activeId);
    }, 4000);
    return () => window.clearInterval(id);
  }, [activeId]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [messages.length, typing]);

  const activeConv = conversations.find((c) => c.friend.id === activeId);

  const openChat = (id: string) => setParams({ with: id });

  const send = async () => {
    const value = text.trim();
    if (!value || !activeId || sending) return;
    setSending(true);
    try {
      const r = await api.chatSend(activeId, value);
      setMessages((m) => [...m, r.message]);
      setText('');
      await api.chatTyping(activeId, false).catch(() => undefined);
      void loadConversations(true);
    } catch (e: any) { toast({ title: e?.message || 'Failed to send', tone: 'error' }); }
    finally { setSending(false); }
  };

  const onType = (v: string) => {
    setText(v);
    if (!activeId) return;
    const now = Date.now();
    if (now - lastTypingSent.current > 2000) {
      lastTypingSent.current = now;
      void api.chatTyping(activeId, true).catch(() => undefined);
    }
    if (typingTimer.current) window.clearTimeout(typingTimer.current);
    typingTimer.current = window.setTimeout(() => { void api.chatTyping(activeId, false).catch(() => undefined); }, 2500);
  };

  const delMsg = async (id: string, mode: 'me' | 'all') => {
    try { await api.chatDelete(id, mode); setMessages((m) => m.map((x) => x.id === id ? { ...x, text: mode === 'all' ? 'Message deleted' : x.text, deleted: mode === 'me', deletedForAll: mode === 'all' } : x).filter((x) => !(mode === 'me' && x.deleted))); }
    catch (e: any) { toast({ title: e?.message || 'Delete failed', tone: 'error' }); }
  };

  const toggleBlock = async () => {
    if (!activeId) return;
    try { const r = await api.chatBlock(activeId, !blockedByMe); setBlockedByMe(r.blocked); toast({ title: r.blocked ? 'User blocked' : 'User unblocked', tone: 'info' }); void loadConversations(true); }
    catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); }
  };

  const report = async () => {
    if (!activeId) return;
    const reason = window.prompt('Reason for report (spam, abuse, harassment, etc.)', 'abuse');
    if (!reason) return;
    try { await api.chatReport(activeId, reason, '', activeConv?.conversationId || ''); toast({ title: 'Report submitted', tone: 'success' }); }
    catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); }
  };

  const doSearch = async () => {
    const q = searchQ.trim();
    if (q.length < 2) { setSearchResults([]); return; }
    setSearching(true);
    try { const r = await api.chatSearch(q); setSearchResults(r.results || []); }
    catch { setSearchResults([]); }
    finally { setSearching(false); }
  };

  return (
    <div>
      <PageHeader eyebrow={t('messages')} title={t('messages')} subtitle="Private, secure chat with your accepted friends. Messages sync across your devices." />
      <div className="grid gap-4 lg:grid-cols-[340px_minmax(0,1fr)]">
        <section className="card card-pad flex max-h-[72vh] flex-col">
          <div className="mb-3 flex gap-2">
            <div className="relative flex-1"><Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="field pl-9" value={searchQ} onChange={(e) => setSearchQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') void doSearch(); }} placeholder="Search conversations" /></div>
            <button type="button" className="btn btn-soft" onClick={() => void doSearch()} disabled={searching}>Search</button>
          </div>
          {searchQ.trim().length >= 2 && searchResults.length > 0 ? (
            <div className="mb-3 space-y-1 max-h-40 overflow-y-auto scroll-thin">
              {searchResults.map((r: any) => (
                <button key={r.messageId} type="button" onClick={() => { openChat(r.friendId); setSearchQ(''); setSearchResults([]); }} className="w-full rounded-xl border border-line/[0.07] px-3 py-2 text-left hover:bg-line/[0.04]">
                  <p className="text-[11px] font-semibold">{r.name} <span className="text-muted">@{r.username}</span></p>
                  <p className="truncate text-[11px] text-muted">{r.text}</p>
                </button>
              ))}
            </div>
          ) : null}
          <div className="scroll-thin flex-1 space-y-1 overflow-y-auto">
            {loading ? <p className="py-6 text-center text-[12px] text-muted">{t('loading')}</p> : conversations.length === 0 ? <p className="py-8 text-center text-[12px] text-muted">No accepted friends yet. Add friends to start chatting.</p> : conversations.map((c) => (
              <button key={c.conversationId} type="button" onClick={() => openChat(c.friend.id)} className={`flex w-full items-center gap-3 rounded-2xl border px-3 py-2.5 text-left transition ${activeId === c.friend.id ? 'border-brand/30 bg-brand/10' : 'border-transparent hover:bg-line/[0.04]'}`}>
                <Avatar emoji={c.friend.avatar} size={42} frame={(c.friend as any).selectedFrameId || c.friend.profileFrame} glowEffect={c.friend.glowEffect} borderColor={(c.friend as any).borderColor} online={c.friend.online} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-[13px] font-semibold"><DisplayName name={c.friend.name} isVip={c.friend.isVip} isOwner={(c.friend as any).isOwner} effect={(c.friend as any).selectedNicknameEffect || c.friend.usernameEffect} color={(c.friend as any).selectedNicknameColor || c.friend.usernameColor} /></p>
                    {c.lastMessage?.at ? <span className="shrink-0 text-[9.5px] text-muted">{fmtTime(c.lastMessage.at)}</span> : null}
                  </div>
                  <p className="truncate text-[11px] text-muted">{c.typing ? <span className="text-violet-300">Typing…</span> : (c.lastMessage?.text || 'No messages yet')}</p>
                </div>
                {c.unread > 0 ? <span className="grid h-5 min-w-5 place-items-center rounded-full bg-brand px-1.5 text-[10px] font-bold text-white">{c.unread > 99 ? '99+' : c.unread}</span> : null}
              </button>
            ))}
          </div>
        </section>

        <section className="card flex min-h-[72vh] flex-col overflow-hidden">
          {!activeId || !peer ? (
            <EmptyState icon={MessageCircle} title="Select a conversation" text="Choose a friend to start a private conversation. Your messages are stored securely and sync across devices." />
          ) : (
            <>
              <div className="flex items-center justify-between gap-3 border-b border-line/[0.07] px-4 py-3">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar emoji={peer.avatar} size={40} frame={(peer as any).selectedFrameId || peer.profileFrame} glowEffect={peer.glowEffect} borderColor={(peer as any).borderColor} online={peer.online} />
                  <div className="min-w-0">
                    <p className="truncate text-[13.5px] font-bold"><DisplayName name={peer.name} isVip={peer.isVip} isOwner={(peer as any).isOwner} effect={(peer as any).selectedNicknameEffect || peer.usernameEffect} color={(peer as any).selectedNicknameColor || peer.usernameColor} /></p>
                    <p className="text-[10.5px] text-muted">@{peer.username} · {peer.userCode} · {peer.online ? <span className="text-emerald-400">Online</span> : 'Offline'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button type="button" className="icon-btn h-8 w-8" title={blockedByMe ? 'Unblock' : 'Block'} onClick={() => void toggleBlock()}><Ban size={14} className={blockedByMe ? 'text-rose-400' : ''} /></button>
                  <button type="button" className="icon-btn h-8 w-8" title="Report" onClick={() => void report()}><Flag size={14} /></button>
                </div>
              </div>
              <div className="scroll-thin flex-1 space-y-2 overflow-y-auto p-4">
                {messages.length === 0 ? <p className="py-10 text-center text-[12px] text-muted">No messages yet. Say hello!</p> : messages.map((m) => {
                  const mine = m.senderId === me?.id;
                  const deleted = m.deleted || m.deletedForAll;
                  return (
                    <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                      <div className={`chat-bubble ${mine ? 'chat-bubble-me' : 'chat-bubble-them'} ${deleted ? 'opacity-60' : ''}`}>
                        <p className="whitespace-pre-wrap break-words text-[13px] leading-relaxed">{m.text}</p>
                        <div className={`mt-1 flex items-center gap-2 text-[9.5px] ${mine ? 'text-white/70 justify-end' : 'text-muted'}`}>
                          <span>{fmtTime(m.createdAt)}</span>
                          {!deleted ? (
                            <>
                              <button type="button" className="hover:underline" onClick={() => void delMsg(m.id, 'me')}>Delete for me</button>
                              {mine ? <button type="button" className="hover:underline" onClick={() => void delMsg(m.id, 'all')}>Delete for everyone</button> : null}
                            </>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  );
                })}
                {typing ? <div className="flex justify-start"><div className="chat-bubble chat-bubble-them flex items-center gap-1 py-3"><span className="typing-dot" /><span className="typing-dot [animation-delay:.15s]" /><span className="typing-dot [animation-delay:.3s]" /></div></div> : null}
                <div ref={endRef} />
              </div>
              <div className="border-t border-line/[0.07] p-3">
                {blockedByMe || blockedMe ? (
                  <div className="flex items-center gap-2 rounded-xl border border-rose-400/20 bg-rose-500/10 px-3 py-2 text-[12px] text-rose-300"><ShieldAlert size={14} /> {blockedByMe ? 'You blocked this user. Unblock to chat.' : 'You cannot message this user right now.'}</div>
                ) : (
                  <div className="flex items-end gap-2">
                    <textarea className="field min-h-[44px] max-h-32 flex-1 resize-y" rows={1} value={text} onChange={(e) => onType(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); } }} placeholder="Write a message… (Enter to send, Shift+Enter for new line)" />
                    <button type="button" className="btn btn-primary h-[44px] px-4" disabled={!text.trim() || sending} onClick={() => void send()}><Send size={15} /></button>
                  </div>
                )}
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
