import { create } from 'zustand';
import { api, toWorkspaceData, type RegisterInput } from './api';
import { createEmptyWorkspace, createSeed, useApp } from './store';
import { readAiKey, LEGACY_STATE_KEY } from './storage';
import type { AppData, Lang, User } from './types';

type AuthStatus = 'booting' | 'guest' | 'authed';

interface AuthState {
  status: AuthStatus;
  user: User | null;
  bootError: string;
  busy: boolean;
  boot: () => Promise<void>;
  login: (identifier: string, password: string) => Promise<void>;
  loginGoogle: (credential: string) => Promise<void>;
  register: (input: RegisterInput, language: Lang) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  setUser: (user: User) => void;
}

let bootPromise: Promise<void> | null = null;

async function applyWorkspace(user: User): Promise<void> {
  const response = await api.getWorkspace();
  let data: AppData;
  if (!response.workspace) {
    // New users must start with an empty task list (no demo/fake data)
    data = createEmptyWorkspace(user);
    try { await api.saveWorkspace(toWorkspaceData(data)); } catch { await api.saveWorkspace(toWorkspaceData(data)).catch(() => undefined); }
  } else {
    data = { ...response.workspace, user } as AppData;
  }
  data.settings = { ...data.settings, aiKey: readAiKey(user.id) };
  useApp.getState().hydrate(data);
}

export const useAuth = create<AuthState>()((set, get) => ({
  status: 'booting',
  user: null,
  bootError: '',
  busy: false,

  boot: async () => {
    if (bootPromise) return bootPromise;
    bootPromise = (async () => {
      try { localStorage.removeItem(LEGACY_STATE_KEY); } catch { /* ignore */ }
      try {
        const { user } = await api.me();
        await applyWorkspace(user);
        set({ status: 'authed', user, bootError: '' });
      } catch (error: any) {
        if (error?.status === 401) {
          set({ status: 'guest', user: null, bootError: '' });
        } else {
          set({ status: 'guest', user: null, bootError: error?.status === 0 ? 'The server is unreachable. Please refresh when your connection is back.' : 'Your session could not be restored. Please sign in again.' });
        }
      }
    })();
    return bootPromise;
  },

  login: async (identifier, password) => {
    if (get().busy) return;
    set({ busy: true, bootError: '' });
    try {
      const { user } = await api.login(identifier, password);
      await applyWorkspace(user);
      set({ status: 'authed', user, busy: false, bootError: '' });
    } catch (error) { set({ busy: false }); throw error; }
  },

  loginGoogle: async (credential) => {
    if (get().busy) return;
    set({ busy: true, bootError: '' });
    try {
      const { user } = await api.loginGoogle(credential);
      await applyWorkspace(user);
      set({ status: 'authed', user, busy: false, bootError: '' });
    } catch (error) { set({ busy: false }); throw error; }
  },

  register: async (input, language) => {
    if (get().busy) return;
    set({ busy: true, bootError: '' });
    try {
      const { user } = await api.register(input);
      // New users must start with an empty task list (no demo/fake data)
      const ws = createEmptyWorkspace(user);
      ws.settings = { ...ws.settings, language };
      useApp.getState().hydrate(ws);
      try { await api.saveWorkspace(toWorkspaceData(ws)); } catch { await api.saveWorkspace(toWorkspaceData(ws)).catch(() => undefined); }
      set({ status: 'authed', user, busy: false, bootError: '' });
    } catch (error) { set({ busy: false }); throw error; }
  },

  logout: async () => {
    await api.logout().catch(() => undefined);
    useApp.setState(createSeed());
    bootPromise = null;
    set({ status: 'guest', user: null, bootError: '' });
  },

  refresh: async () => {
    try {
      const { user } = await api.me();
      set({ user });
      useApp.getState().updateUser(user as any);
    } catch { /* ignore */ }
  },

  setUser: (user) => set({ user }),
}));
