# SMART LIFE AI — To‘liq loyiha (Full Project)

Bu arxiv **SMART LIFE AI** loyihasining mavjud (amaldagi) manba kodlarining to‘liq eksportidir: frontend, backend (API/worker), ma’lumotlar bazasi sxemasi/migratsiyalar, konfiguratsiya va o‘rnatish/joylash bo‘yicha qo‘llanma. Bu demo/mockup emas — loyiha kodlari va funksiyalari saqlangan. Maxfiy kalitlar, parollar va shaxsiy foydalanuvchi ma’lumotlari kiritilmagan.

## 1) Texnologiyalar va arxitektura
- **Frontend:** React 18 + TypeScript + Vite, Tailwind CSS, Zustand, React Router (`src/`, `index.html`, `public/`).
- **Backend/API:** Cloudflare Worker (ESM, `fetch` handler) — `worker/index.ts` (auth, profil/avatar/media, VIP, do‘stlar/chat, workspace/rejalar, admin/owner).
- **Ma’lumotlar bazasi:** Cloudflare D1 (SQLite) binding `DB` — sxema/migratsiya `migrations/0001_init.sql` va worker ichidagi `ensureSchema` mantiqi.
- **Fayl saqlash (avatar/cover/background):** Cloudflare R2 binding `MEDIA_BUCKET` (yuklangan media `/api/media/...` orqali saqlanadi va xizmat qilinadi).
- **Autentifikatsiya:** email/parol (PBKDF2-SHA256) + ixtiyoriy Google Sign-In, HttpOnly cookie sessiyalar, server-tomon tekshiruvlar (VIP/owner/admin).

> Izoh (DB): bu loyihada hozir **Firebase/Firestore ishlatilmaydi**; haqiqiy ma’lumotlar bazasi **D1 (SQLite)**. Agar Firebase kerak bo‘lsa, `worker/index.ts` dagi ma’lumotlar qatlami/almashtirishlar va qoidalar alohida moslashtiriladi (quyida ko‘rsatilgan).

## 2) Loyiha tuzilmasi (asosiy)
- `src/` — frontend: sahifalar (`src/pages/*` — Dashboard, Tasks/Calendar, Notes, Goals, Friends, Messages/Chat, Assistant, Profile, Admin, Auth va h.k.), komponentlar (`src/components/*`), kutubxonalar/state (`src/lib/*`), lokalizatsiya, stillar.
- `public/` — statik assets (favicon va b.).
- `worker/index.ts` — backend API, auth, Google token tekshiruvi, profil/avatar/media yuklash va saqlash, VIP/owner/admin, do‘stlar/chat/notifications, workspace (tasks/events/goals/notes) saqlash.
- `migrations/0001_init.sql` — D1 sxemasi/migratsiya.
- `deploy.manifest.json` — deploy manifest (entrypoint/modules/assets/spa).
- `wrangler.toml` — Worker/D1/assets bindinglar (namuna).
- `package.json`, `package-lock.json` — dependency va skriptlar.
- `vite.config.ts`, `tsconfig*.json`, `tailwind.config.ts`, `postcss.config.js` — build/konfiguratsiya.
- `.env.example` — muhit o‘zgaruvchilari namunasi (**maxfiy qiymatlarsiz**).
- `.gitignore` — gitdan chiqariladigan fayllar.

*(Build natijalari `dist/`, `worker-dist/` va `node_modules/` eksportga kiritilmagan — ularni o‘zingiz qurishingiz/`npm install` qilishingiz kerak.)*

## 3) Lokal kompyuterda ishga tushirish
**Talablar:** Node.js (LTS tavsiya etiladi) va npm.

1. Arxivni chiqarib oling va papkaga kiring:
   - `SMART_LIFE_AI_FULL_PROJECT/`
2. Dependency o‘rnating: `npm install`
3. `.env.example` ni `.env` ga nusxalang va kerakli qiymatlarni kiriting (quyidagi “Muhit o‘zgaruvchilari” bo‘limi). Hech qachon real sirlarni repoga qo‘ymang.
4. **D1 ma’lumotlar bazasi (lokal/dev):** Wrangler orqali `DB` binding sozlang (`wrangler.toml` dagi `[[d1_databases]]`), kerak bo‘lsa `npx wrangler d1 create <name>` va migratsiyani qo‘llang (masalan `npx wrangler d1 migrations apply <name> --local` / loyiha sozlamasiga mos).
5. **Frontend:** `npm run dev` (Vite).
6. **API/Worker (lokal):** `npm run dev:api` yoki `npx wrangler dev` (loyiha skriptiga qarang). `/api/*` so‘rovlari workerga yetib borishi va cookie/same-origin ishlashi uchun dev proxy/origin sozlamasini tekshiring.
7. **Tekshiruv/build:**
   - Frontend typecheck+build: `npm run build`
   - Worker bundle: `npm run build:worker` → `worker-dist/index.js`
   - To‘liq prod build: `npm run build:prod`

> Eslatma: loyihada `package.json` ichidagi mavjud skriptlar ustuvor — yuqoridagi buyruqlar umumiy ko‘rinish; aniq nomlarni `npm run` orqali ko‘ring.

## 4) Muhit o‘zgaruvchilari va konfiguratsiya (.env / secrets)
`.env.example` ga qarang (faqat placeholder). Asosiylari:
- **VITE_GOOGLE_CLIENT_ID** (frontend, build-time, public): Google OAuth Web client ID.
- **GOOGLE_CLIENT_ID** (server/worker): server-tomon ID token tekshiruvi uchun (odatda yuqoridagi bilan bir xil).
- **ADMIN_KEY** / **ADMIN_PASSWORD_HASH** (server secret, **frontendga qo‘ymang**): admin panelga kirish; hosting secret manager orqali sozlang. `qurbonboyqurbonboyev14@gmail.com` egasi (owner) server-tomon taniladi (Google auth to‘g‘ri sozlangan va shu akkaunt bilan kirilganda).
- **DB** (D1 binding): foydalanuvchilar, sessiyalar, workspace (rejalar/tasks/events/goals/notes), do‘stlar/chat va sozlamalar.
- **MEDIA_BUCKET** (R2 binding): avatar va (VIP) cover/background media yuklash/saqlash.

Hech qachon real parol, private API key, admin secret yoki service-account credentiallarni frontendga yoki repoga kiritmang.

## 5) Ma’lumotlar bazasi (D1) ulash va sxema
- Sxema: `migrations/0001_init.sql` va `worker/index.ts` dagi `ensureSchema`/migratsiya mantiqi.
- **Lokal:** Wrangler D1 (`wrangler.toml` `[[d1_databases]]`, binding `DB`) + migratsiyalarni qo‘llash.
- **Prod/Cloudflare:** D1 bazasini yarating, bindingni ulang, migratsiyalarni bajaring, mavjud foydalanuvchi/ma’lumotlarni o‘chirmang.
- **Boshqa hostga ko‘chirish:** D1 ma’lumotlarini eksport/import qiling va ma’lumotlar qatlamini moslashtiring (pastga qarang). Firebase/Firestore ishlatilsa, u alohida integratsiya bo‘lib, bu eksportda Firestore rules/fayllar mavjud emas (loyiha D1 asosida).

## 6) Google OAuth (Sign-In) sozlash
1. Google Cloud Console → Credentials → OAuth 2.0 **Web client** yarating.
2. **Authorized JavaScript origins** ga lokal (masalan `http://localhost:5173` va worker dev origin) hamda production domen(lar)ni qo‘shing.
3. `VITE_GOOGLE_CLIENT_ID` (build-time) va `GOOGLE_CLIENT_ID` (server) ni sozlang.
4. Frontendni qayta build/deploy qiling (client ID buildga kiradi).

## 7) Backendni ishga tushirish va joylash (deploy)
### Hozirgi maqsadli muhit: Cloudflare Workers + Static Assets
1. `npm run build:prod` (`dist/` va `worker-dist/index.js` hosil bo‘ladi).
2. `wrangler.toml` / `deploy.manifest.json` da `DB`, `ASSETS`, (kerak bo‘lsa) `MEDIA_BUCKET` bindinglarni tekshiring.
3. D1 va R2 ni provisioning qiling, sirlarni sozlang (`GOOGLE_CLIENT_ID`, `ADMIN_KEY`, `ADMIN_PASSWORD_HASH` va b.).
4. `wrangler deploy` yoki loyihangiz deploy jarayoni orqali HTTPS ostida joylang.

### Vercel yoki boshqa hostingga moslashtirish
- **Frontend (SPA):** `npm run build` natijasi `dist/` — Vercel/Netlify kabi static hostga joylash mumkin (client-side route’lar uchun SPA fallback/rewrites `index.html` ga yo‘naltirilsin).
- **Backend/API:** `worker/index.ts` **Cloudflare Workers runtime** ga mo‘ljallangan (D1 `DB`, R2 `MEDIA_BUCKET`, Web Crypto/fetch). Vercel serverless/Node muhitida ishlatish uchun ma’lumotlar qatlami va bindinglar (D1→Postgres/SQLite va object storage→S3/R2 muqobili), cookie/origin va upload endpointlar moslashtirilishi kerak — yoki API ni Cloudflare Workers’da qoldirib, frontendni alohida hostda domen orqali ulang (CORS/same-origin/cookie sozlamalariga e’tibor bering).
- Yangi hostda env/secrets, DB, storage, Google OAuth originlari va HTTPS/cookie domenlarini qayta sozlang.

## 8) Xavfsizlik eslatmalari
- Sessiyalar HttpOnly cookie, VIP/owner/admin huquqlari **server-tomon** tekshiriladi.
- Admin sirlarini frontendga chiqarmang; `.secrets/` va real credentiallarni commit/eksport qilmang.
- Foydalanuvchi workspace/rejalari autentifikatsiyalangan foydalanuvchiga xos va saqlanadi (mavjud ma’lumotlar o‘chirilmasin).

## 9) Ma’lum cheklovlar
- Google login va owner/admin to‘liq tekshiruvi real Google OAuth sozlamalari va akkaunt bilan amalga oshiriladi.
- Avatar/media yuklash va ko‘rsatish uchun `MEDIA_BUCKET` va `/api/media/*` ishlashi talab etiladi.
