import { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  CalendarDays,
  CalendarPlus,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Pencil,
  Plus,
  Trash2,
} from 'lucide-react';
import { useApp, type NewEvent } from '../lib/store';
import { useT, type TranslationKey } from '../lib/i18n';
import { cn } from '../lib/cn';
import {
  addDaysISO,
  formatDate,
  formatLongDate,
  formatMonthYear,
  minutesToTime,
  monthMatrix,
  startOfWeek,
  timeToMinutes,
  toISO,
  todayISO,
  weekdayLabels,
} from '../lib/date';
import type { Category, EventItem } from '../lib/types';
import { CATEGORIES } from '../lib/types';
import { CATEGORY_COLORS, eventsForDay, upcomingEvents } from '../lib/analytics';
import {
  CategoryTag,
  ConfirmDialog,
  EmptyState,
  Modal,
  PageHeader,
  Segmented,
} from '../components/ui';
import { useToast } from '../components/Toast';

type View = 'day' | 'week' | 'month';

const REMINDERS = [0, 5, 15, 30, 60];

export default function Calendar() {
  const { t, lang } = useT();
  const toast = useToast();

  const events = useApp((s) => s.events);
  const addEvent = useApp((s) => s.addEvent);
  const updateEvent = useApp((s) => s.updateEvent);
  const deleteEvent = useApp((s) => s.deleteEvent);

  const [view, setView] = useState<View>('month');
  const [cursor, setCursor] = useState(() => new Date());
  const [selected, setSelected] = useState(todayISO());
  const [editor, setEditor] = useState<{ mode: 'new' | 'edit'; event?: EventItem; date?: string } | null>(null);
  const [deleting, setDeleting] = useState<EventItem | null>(null);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 60000);
    return () => window.clearInterval(id);
  }, []);

  const today = todayISO();
  const selectedEvents = useMemo(() => eventsForDay(events, selected), [events, selected]);
  const nextEvents = useMemo(() => upcomingEvents(events, 5), [events]);

  const shift = (dir: -1 | 1) => {
    if (view === 'month') {
      setCursor((c) => new Date(c.getFullYear(), c.getMonth() + dir, 1));
    } else if (view === 'week') {
      setCursor((c) => {
        const d = new Date(c);
        d.setDate(d.getDate() + dir * 7);
        return d;
      });
    } else {
      setCursor((c) => {
        const d = new Date(c);
        d.setDate(d.getDate() + dir);
        return d;
      });
      setSelected((s) => addDaysISO(s, dir));
    }
  };

  const goToday = () => {
    const d = new Date();
    setCursor(d);
    setSelected(toISO(d));
  };

  const openNew = (date?: string) => setEditor({ mode: 'new', date: date ?? selected });

  const jumpTo = (event: EventItem) => {
    const d = new Date(event.date + 'T00:00:00');
    setCursor(d);
    setSelected(event.date);
    setView('day');
  };

  const weekStart = startOfWeek(cursor);
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    return d;
  });
  const monthDays = monthMatrix(cursor.getFullYear(), cursor.getMonth());
  const weekdayShort = weekdayLabels(lang);

  const label =
    view === 'month'
      ? formatMonthYear(cursor, lang)
      : view === 'week'
        ? `${formatDate(toISO(weekStart), lang, { day: 'numeric', month: 'short' })} – ${formatDate(
            addDaysISO(toISO(weekStart), 6),
            lang,
            { day: 'numeric', month: 'short', year: 'numeric' },
          )}`
        : formatLongDate(cursor, lang);

  const handleSave = (values: NewEvent) => {
    if (editor?.mode === 'edit' && editor.event) {
      updateEvent(editor.event.id, values);
      toast({ title: t('eventUpdatedToast'), description: values.title });
    } else {
      addEvent(values);
      toast({ title: t('eventAddedToast'), description: values.title });
    }
    setSelected(values.date);
    setCursor(new Date(values.date + 'T00:00:00'));
    setEditor(null);
  };

  return (
    <div>
      <PageHeader
        eyebrow={t('workspace')}
        title={t('calendarTitle')}
        subtitle={t('calendarSubtitle')}
        actions={
          <button type="button" className="btn btn-primary" onClick={() => openNew()}>
            <Plus size={15} />
            {t('addEvent')}
          </button>
        }
      />

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_330px] xl:gap-5">
        <section className="card overflow-hidden">
          <div className="flex flex-col gap-3 border-b border-line/[0.07] px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-5">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand/12 text-violet-300">
                <CalendarDays size={17} />
              </span>
              <div>
                <h2 className="font-display text-[15px] font-bold capitalize leading-tight">{label}</h2>
                <p className="text-[10.5px] text-muted">{t('eventsThisDay')} · {eventsForDay(events, selected).length}</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <Segmented
                size="sm"
                value={view}
                onChange={setView}
                options={[
                  { value: 'day', label: t('viewDay') },
                  { value: 'week', label: t('viewWeek') },
                  { value: 'month', label: t('viewMonth') },
                ]}
              />
              <div className="ml-1 flex items-center gap-1">
                <button type="button" onClick={() => shift(-1)} className="icon-btn h-8 w-8" aria-label={t('prevPeriod')}>
                  <ChevronLeft size={15} />
                </button>
                <button type="button" onClick={goToday} className="rounded-xl border border-line/[0.08] px-2.5 py-1.5 text-[11px] font-semibold text-muted transition hover:text-ink">
                  {t('todayBtn')}
                </button>
                <button type="button" onClick={() => shift(1)} className="icon-btn h-8 w-8" aria-label={t('nextPeriod')}>
                  <ChevronRight size={15} />
                </button>
              </div>
            </div>
          </div>

          {/* MONTH */}
          {view === 'month' ? (
            <div className="p-2 sm:p-3">
              <div className="grid grid-cols-7">
                {weekdayShort.map((d) => (
                  <div key={d} className="pb-2 text-center text-[9.5px] font-semibold uppercase tracking-wider text-muted">
                    {d}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 overflow-hidden rounded-xl border border-line/[0.06]">
                {monthDays.flat().map((date, i) => {
                  const iso = toISO(date);
                  const inMonth = date.getMonth() === cursor.getMonth();
                  const isToday = iso === today;
                  const isSelected = iso === selected;
                  const dayEvents = eventsForDay(events, iso);
                  return (
                    <button
                      key={iso}
                      type="button"
                      onClick={() => {
                        setSelected(iso);
                        if (!inMonth) setCursor(new Date(date.getFullYear(), date.getMonth(), 1));
                      }}
                      onDoubleClick={() => openNew(iso)}
                      className={cn(
                        'relative flex min-h-[72px] flex-col items-stretch gap-1 border-b border-r border-line/[0.055] p-1.5 text-left transition-colors last:border-r-0 sm:min-h-[104px] sm:p-2',
                        !inMonth && 'opacity-40',
                        isSelected ? 'bg-brand/[0.09]' : 'hover:bg-line/[0.03]',
                      )}
                    >
                      <span
                        className={cn(
                          'grid h-6 w-6 place-items-center rounded-full text-[11px] font-semibold',
                          isToday
                            ? 'bg-gradient-to-br from-violet-400 to-indigo-500 text-white shadow-[0_0_14px_rgba(139,92,246,.6)]'
                            : isSelected
                              ? 'bg-brand/20 text-ink'
                              : 'text-muted',
                        )}
                      >
                        {date.getDate()}
                      </span>
                      <div className="hidden flex-1 flex-col gap-1 sm:flex">
                        {dayEvents.slice(0, 2).map((ev) => {
                          const color = CATEGORY_COLORS[ev.category];
                          return (
                            <span
                              key={ev.id}
                              className="flex items-center gap-1 truncate rounded-md px-1.5 py-0.5 text-[9.5px] font-medium"
                              style={{ background: `${color}1c`, color }}
                            >
                              <span className="h-1 w-1 shrink-0 rounded-full" style={{ background: color }} />
                              <span className="truncate">{ev.title}</span>
                            </span>
                          );
                        })}
                        {dayEvents.length > 2 ? (
                          <span className="px-1 text-[9px] text-muted">{t('moreEvents', { n: dayEvents.length - 2 })}</span>
                        ) : null}
                      </div>
                      {dayEvents.length > 0 ? (
                        <div className="flex gap-0.5 sm:hidden">
                          {dayEvents.slice(0, 3).map((ev) => (
                            <span
                              key={ev.id}
                              className="h-1 w-1 rounded-full"
                              style={{ background: CATEGORY_COLORS[ev.category] }}
                            />
                          ))}
                        </div>
                      ) : null}
                    </button>
                  );
                })}
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-3 px-1 text-[9.5px] text-muted">
                {CATEGORIES.map((cat) => (
                  <span key={cat} className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: CATEGORY_COLORS[cat] }} />
                    {t(cat)}
                  </span>
                ))}
              </div>
            </div>
          ) : null}

          {/* WEEK */}
          {view === 'week' ? (
            <div className="grid grid-cols-7 gap-[1px] overflow-x-auto bg-line/[0.05]">
              {weekDays.map((date) => {
                const iso = toISO(date);
                const isToday = iso === today;
                const isSelected = iso === selected;
                const dayEvents = eventsForDay(events, iso);
                return (
                  <div key={iso} className={cn('min-w-[92px] bg-surface/30 p-2 sm:min-w-0 sm:p-2.5', isSelected && 'bg-brand/[0.07]')}>
                    <button type="button" onClick={() => setSelected(iso)} className="mb-2 w-full text-center">
                      <p className="text-[9px] font-semibold uppercase tracking-wider text-muted">
                        {formatDate(iso, lang, { weekday: 'short' })}
                      </p>
                      <span
                        className={cn(
                          'mx-auto mt-1 grid h-7 w-7 place-items-center rounded-full text-[12px] font-bold',
                          isToday ? 'bg-gradient-to-br from-violet-400 to-indigo-500 text-white' : 'text-ink',
                        )}
                      >
                        {date.getDate()}
                      </span>
                    </button>
                    <div className="space-y-1.5">
                      {dayEvents.map((ev) => {
                        const color = CATEGORY_COLORS[ev.category];
                        return (
                          <button
                            key={ev.id}
                            type="button"
                            onClick={() => setEditor({ mode: 'edit', event: ev })}
                            className="w-full rounded-lg border-l-2 px-1.5 py-1.5 text-left transition hover:brightness-125"
                            style={{ background: `${color}14`, borderColor: color }}
                          >
                            <p className="text-[8.5px] font-semibold" style={{ color }}>{ev.start}</p>
                            <p className="mt-0.5 line-clamp-2 text-[10px] font-medium leading-tight">{ev.title}</p>
                          </button>
                        );
                      })}
                      {dayEvents.length === 0 ? (
                        <button
                          type="button"
                          onClick={() => openNew(iso)}
                          className="flex w-full items-center justify-center rounded-lg border border-dashed border-line/[0.12] py-3 text-[9px] text-muted/60 transition hover:border-brand/30 hover:text-muted"
                        >
                          <Plus size={11} />
                        </button>
                      ) : null}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}

          {/* DAY */}
          {view === 'day' ? (
            <DayTimeline
              date={cursor}
              events={eventsForDay(events, toISO(cursor))}
              now={now}
              onEdit={(ev) => setEditor({ mode: 'edit', event: ev })}
              onAdd={() => openNew(toISO(cursor))}
            />
          ) : null}
        </section>

        {/* Aside */}
        <aside className="space-y-4">
          <div className="card card-pad">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="eyebrow">{t('selectDay')}</p>
                <h3 className="mt-1 font-display text-[15px] font-bold capitalize">
                  {formatDate(selected, lang, { weekday: 'long', day: 'numeric', month: 'long' })}
                </h3>
              </div>
              <button type="button" onClick={() => openNew()} className="icon-btn h-8 w-8 shrink-0" aria-label={t('addEvent')}>
                <CalendarPlus size={15} />
              </button>
            </div>

            <div className="mt-3 space-y-2">
              {selectedEvents.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-line/[0.12] px-4 py-7 text-center">
                  <CalendarDays size={20} className="mx-auto mb-2 text-muted/60" />
                  <p className="text-[11.5px] text-muted">{t('noEventsForDay')}</p>
                  <button type="button" onClick={() => openNew()} className="mt-2 text-[11px] font-semibold text-brand">
                    + {t('addEvent')}
                  </button>
                </div>
              ) : (
                selectedEvents.map((ev) => {
                  const color = CATEGORY_COLORS[ev.category];
                  return (
                    <div
                      key={ev.id}
                      className="group relative rounded-2xl border border-line/[0.06] bg-line/[0.02] p-3 pl-3.5 transition hover:border-line/[0.12]"
                    >
                      <span className="absolute left-0 top-3 h-6 w-[3px] rounded-r-full" style={{ background: color }} />
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-[12.5px] font-semibold">{ev.title}</p>
                          <p className="mt-0.5 flex items-center gap-1.5 text-[10.5px] text-muted">
                            <Clock3 size={10} /> {ev.start} – {ev.end}
                            {ev.reminder ? (
                              <span className="flex items-center gap-0.5">
                                <Bell size={9} /> {ev.reminder}
                                {t('minShort')}
                              </span>
                            ) : null}
                          </p>
                          {ev.note ? <p className="mt-1 line-clamp-2 text-[10px] text-muted/80">{ev.note}</p> : null}
                          <div className="mt-1.5">
                            <CategoryTag category={ev.category} />
                          </div>
                        </div>
                        <div className="flex shrink-0 gap-0.5">
                          <button
                            type="button"
                            onClick={() => setEditor({ mode: 'edit', event: ev })}
                            className="rounded-lg p-1 text-muted transition hover:bg-line/[0.07] hover:text-ink"
                            aria-label={t('edit')}
                          >
                            <Pencil size={12} />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleting(ev)}
                            className="rounded-lg p-1 text-muted transition hover:bg-rose-500/10 hover:text-rose-400"
                            aria-label={t('delete')}
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="card card-pad">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-[12.5px] font-bold">{t('upcomingTitle')}</h3>
              <span className="chip chip-muted">{nextEvents.length}</span>
            </div>
            <div className="mt-2.5 space-y-1">
              {nextEvents.length === 0 ? (
                <p className="py-5 text-center text-[11px] text-muted">{t('noUpcoming')}</p>
              ) : (
                nextEvents.map((ev) => (
                  <button
                    key={ev.id}
                    type="button"
                    onClick={() => jumpTo(ev)}
                    className="flex w-full items-center gap-2.5 rounded-xl px-1.5 py-2 text-left transition hover:bg-line/[0.04]"
                  >
                    <span
                      className="h-8 w-8 shrink-0 rounded-lg border text-center text-[10px] font-bold leading-8"
                      style={{
                        background: `${CATEGORY_COLORS[ev.category]}14`,
                        borderColor: `${CATEGORY_COLORS[ev.category]}30`,
                        color: CATEGORY_COLORS[ev.category],
                      }}
                    >
                      {ev.date.slice(8, 10)}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[11.5px] font-medium">{ev.title}</span>
                      <span className="block text-[9.5px] text-muted">
                        {formatDate(ev.date, lang, { day: 'numeric', month: 'short' })} · {ev.start}
                      </span>
                    </span>
                    <ChevronRight size={12} className="text-muted/50" />
                  </button>
                ))
              )}
            </div>
          </div>
        </aside>
      </div>

      <EventEditor
        open={Boolean(editor)}
        mode={editor?.mode ?? 'new'}
        event={editor?.event}
        defaultDate={editor?.date ?? selected}
        onClose={() => setEditor(null)}
        onSave={handleSave}
      />

      <ConfirmDialog
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={() => {
          if (deleting) {
            deleteEvent(deleting.id);
            toast({ title: t('eventDeletedToast'), tone: 'info' });
          }
        }}
        title={t('deleteEventTitle')}
        text={t('deleteEventText', { title: deleting?.title ?? '' })}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Day timeline                                                       */
/* ------------------------------------------------------------------ */
function DayTimeline({
  date,
  events,
  now,
  onEdit,
  onAdd,
}: {
  date: Date;
  events: EventItem[];
  now: Date;
  onEdit: (event: EventItem) => void;
  onAdd: () => void;
}) {
  const { t } = useT();
  const startHour = 7;
  const endHour = 22;
  const hourHeight = 55;
  const height = (endHour - startHour) * hourHeight;
  const isToday = toISO(date) === todayISO();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const nowTop = ((nowMinutes - startHour * 60) / 60) * hourHeight;

  return (
    <div className="relative px-3 py-3 sm:px-5">
      <div className="relative" style={{ height }}>
        {Array.from({ length: endHour - startHour + 1 }, (_, i) => {
          const hour = startHour + i;
          return (
            <div
              key={hour}
              className="absolute left-0 right-0 border-t border-line/[0.06]"
              style={{ top: i * hourHeight }}
            >
              <span className="absolute -top-2 left-0 w-10 text-[9.5px] tabular-nums text-muted">
                {String(hour).padStart(2, '0')}:00
              </span>
            </div>
          );
        })}

        {isToday && nowTop >= 0 && nowTop <= height ? (
          <div className="absolute left-12 right-0 z-20 flex items-center" style={{ top: nowTop }}>
            <span className="-ml-1 h-2 w-2 rounded-full bg-rose-400 shadow-[0_0_8px_2px_rgba(251,113,133,.6)]" />
            <span className="h-px flex-1 bg-rose-400/50" />
            <span className="ml-1.5 rounded bg-rose-500/15 px-1 text-[8.5px] font-semibold text-rose-300">
              {t('now')}
            </span>
          </div>
        ) : null}

        <div className="absolute bottom-0 left-12 right-0 top-0">
          {events.length === 0 ? (
            <div className="flex h-full items-center justify-center">
              <div className="text-center">
                <CalendarDays size={24} className="mx-auto mb-2 text-muted/40" />
                <p className="text-[11.5px] text-muted">{t('noEventsForDay')}</p>
                <button type="button" onClick={onAdd} className="btn btn-soft btn-sm mt-3">
                  <Plus size={12} />
                  {t('addEvent')}
                </button>
              </div>
            </div>
          ) : (
            events.map((ev) => {
              const top = Math.max(0, ((timeToMinutes(ev.start) - startHour * 60) / 60) * hourHeight);
              const rawHeight = ((timeToMinutes(ev.end) - timeToMinutes(ev.start)) / 60) * hourHeight;
              const color = CATEGORY_COLORS[ev.category];
              return (
                <button
                  key={ev.id}
                  type="button"
                  onClick={() => onEdit(ev)}
                  className="absolute left-1 right-2 overflow-hidden rounded-xl border p-2.5 text-left transition hover:brightness-125 sm:left-3"
                  style={{
                    top,
                    height: Math.max(38, rawHeight - 4),
                    background: `linear-gradient(120deg, ${color}24, ${color}0d)`,
                    borderColor: `${color}45`,
                    boxShadow: `inset 3px 0 0 ${color}`,
                  }}
                >
                  <p className="text-[10px] font-bold" style={{ color }}>
                    {ev.start} – {ev.end}
                  </p>
                  <p className="mt-0.5 truncate text-[12px] font-semibold">{ev.title}</p>
                  {ev.note ? <p className="mt-0.5 line-clamp-1 text-[10px] text-muted">{ev.note}</p> : null}
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Event editor                                                       */
/* ------------------------------------------------------------------ */
function EventEditor({
  open,
  mode,
  event,
  defaultDate,
  onClose,
  onSave,
}: {
  open: boolean;
  mode: 'new' | 'edit';
  event?: EventItem;
  defaultDate: string;
  onClose: () => void;
  onSave: (values: NewEvent) => void;
}) {
  const { t, lang } = useT();
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(defaultDate);
  const [start, setStart] = useState('09:00');
  const [end, setEnd] = useState('10:00');
  const [category, setCategory] = useState<Category>('study');
  const [reminder, setReminder] = useState(15);
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setTitle(event?.title ?? '');
    setDate(event?.date ?? defaultDate);
    setStart(event?.start ?? '09:00');
    setEnd(event?.end ?? '10:00');
    setCategory(event?.category ?? 'study');
    setReminder(event?.reminder ?? 15);
    setNote(event?.note ?? '');
    setError(null);
  }, [open, event, defaultDate]);

  const submit = () => {
    if (!title.trim()) {
      setError(t('eventName'));
      return;
    }
    if (timeToMinutes(end) <= timeToMinutes(start)) {
      setError(t('invalidTime'));
      return;
    }
    onSave({ title: title.trim(), date, start, end, category, reminder, note: note.trim() });
  };

  const quickTimes = [
    { start: '09:00', end: '10:00' },
    { start: '12:00', end: '13:00' },
    { start: '15:00', end: '16:00' },
    { start: '18:00', end: '19:00' },
  ];

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={mode === 'edit' ? t('editEvent') : t('addEvent')}
      subtitle={t('addEventHint')}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            {t('cancel')}
          </button>
          <button type="button" className="btn btn-primary" onClick={submit}>
            <CalendarPlus size={14} />
            {t('addEventBtn')}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="field-label" htmlFor="event-title">
            {t('eventName')} *
          </label>
          <input
            id="event-title"
            autoFocus
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              setError(null);
            }}
            placeholder={t('eventNamePlaceholder')}
            className="field"
          />
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <label className="field-label" htmlFor="event-date">{t('eventDate')}</label>
            <input
              id="event-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value || defaultDate)}
              className="field"
            />
          </div>
          <div>
            <label className="field-label" htmlFor="event-start">{t('startTime')}</label>
            <input id="event-start" type="time" value={start} onChange={(e) => setStart(e.target.value)} className="field" />
          </div>
          <div>
            <label className="field-label" htmlFor="event-end">{t('endTime')}</label>
            <input id="event-end" type="time" value={end} onChange={(e) => setEnd(e.target.value)} className="field" />
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {quickTimes.map((q) => (
            <button
              key={q.start}
              type="button"
              onClick={() => {
                setStart(q.start);
                setEnd(q.end);
                setError(null);
              }}
              className={cn(
                'rounded-full border px-2.5 py-1 text-[10.5px] font-medium transition',
                start === q.start
                  ? 'border-brand/40 bg-brand/15 text-violet-200'
                  : 'border-line/[0.08] text-muted hover:text-ink',
              )}
            >
              {q.start} – {q.end}
            </button>
          ))}
        </div>

        <div>
          <span className="field-label">{t('taskCategory')}</span>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {CATEGORIES.map((c) => {
              const color = CATEGORY_COLORS[c];
              const active = category === c;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCategory(c)}
                  className="flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2 text-[11.5px] font-medium transition"
                  style={{
                    borderColor: active ? `${color}88` : 'var(--glass-border)',
                    background: active ? `${color}1f` : 'var(--input-bg)',
                    color: active ? color : 'rgb(var(--muted))',
                  }}
                >
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
                  {t(c)}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="field-label" htmlFor="event-reminder">{t('reminderLabel')}</label>
            <select
              id="event-reminder"
              value={reminder}
              onChange={(e) => setReminder(Number(e.target.value))}
              className="field"
            >
              <option value={0}>{t('reminderOff')}</option>
              <option value={5}>{t('reminder5')}</option>
              <option value={15}>{t('reminder15')}</option>
              <option value={30}>{t('reminder30')}</option>
              <option value={60}>{t('reminder60')}</option>
            </select>
          </div>
          <div>
            <label className="field-label" htmlFor="event-note">
              {t('eventNote')} <span className="normal-case tracking-normal opacity-60">({t('optional')})</span>
            </label>
            <input
              id="event-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={t('eventNotePlaceholder')}
              className="field"
            />
          </div>
        </div>

        <div className="rounded-xl border border-line/[0.06] bg-line/[0.02] px-3 py-2.5">
          <div className="flex flex-wrap items-center gap-2 text-[10.5px] text-muted">
            <Clock3 size={12} />
            {formatDate(date, lang, { day: 'numeric', month: 'short' })}
            <span className="text-muted/40">·</span>
            {start} – {end}
            <span className="text-muted/40">·</span>
            <Bell size={11} />
            {reminder ? `${reminder} ${t('minShort')}` : t('reminderOff')}
          </div>
        </div>

        {error ? <p className="text-[11.5px] text-rose-400">{error}</p> : null}
      </div>
    </Modal>
  );
}
