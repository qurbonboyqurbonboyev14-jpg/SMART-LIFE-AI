import type {
  AppData,
  AppNotification,
  ChatConversation,
  ChatMessage,
  DirectMessage,
  EventItem,
  FriendProfile,
  FriendRequestItem,
  Goal,
  Note,
  Settings,
  Task,
  User,
} from './types';

export type { ChatConversation, DirectMessage, FriendProfile };

export class ApiError extends Error {
  status: number;
  code?: string;
  constructor(message: string, status = 0, code?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, {
      credentials: 'include',
      ...init,
      headers: {
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
        ...(init.headers ?? {}),
      },
    });
  } catch {
    throw new ApiError('Cannot reach the server. Check your connection.', 0, 'network_error');
  }

  let payload: any = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok) {
    throw new ApiError(
      typeof payload?.error === 'string' ? payload.error : 'Request failed',
      response.status,
      typeof payload?.code === 'string' ? payload.code : undefined,
    );
  }
  return payload as T;
}

export interface RegisterInput {
  name: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  password: string;
  bio: string;
  interests: string;
  goals: string;
  avatar: string;
}

export interface ProfileInput {
  name?: string;
  firstName?: string;
  lastName?: string;
  username?: string;
  email?: string;
  bio?: string;
  interests?: string;
  goals?: string;
  avatar?: string;
  profileFrame?: string;
  usernameEffect?: string;
  usernameColor?: string;
  borderColor?: string;
  glowEffect?: string;
  profileTheme?: string;
  selectedFrameId?: string;
  selectedNicknameEffect?: string;
  selectedNicknameColor?: string;
  coverUrl?: string;
  coverType?: 'image' | 'video' | '';
  coverPosX?: number;
  coverPosY?: number;
  coverScale?: number;
  bgUrl?: string;
  bgType?: 'image' | 'video' | '';
  bgPosX?: number;
  bgPosY?: number;
  bgScale?: number;
  bgBlur?: number;
  bgOverlay?: number;
  currentPassword?: string;
  newPassword?: string;
}

export interface WorkspaceData {
  tasks: Task[];
  events: EventItem[];
  goals: Goal[];
  notes: Note[];
  messages: ChatMessage[];
  settings: Settings;
}

export interface ServerUser extends User {}

export interface FriendsResponse {
  friends: FriendProfile[];
  incoming: FriendRequestItem[];
  outgoing: FriendRequestItem[];
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  suspendedUsers: number;
  newUsers7d: number;
  activeSessions: number;
  logins24h: number;
  totalFriendships: number;
  totals: { tasks: number; events: number; goals: number; notes: number; messages: number };
  registrations: { day: string; count: number }[];
  generatedAt: string;
}

export interface AdminUser {
  id: string;
  userCode: string;
  name: string;
  username: string;
  email: string;
  bio: string;
  interests: string;
  goals: string;
  status: 'active' | 'suspended' | string;
  authProvider?: string;
  isVip?: boolean;
  vipPermanent?: boolean;
  isOwner?: boolean;
  profileFrame?: string;
  usernameEffect?: string;
  usernameColor?: string;
  selectedFrameId?: string;
  selectedNicknameEffect?: string;
  selectedNicknameColor?: string;
  joinedAt: string;
  lastLoginAt: string | null;
  counts: { tasks: number; goals: number; notes: number };
}

export interface AdminUsersResponse {
  users: AdminUser[];
  page: number;
  pageSize: number;
  total: number;
  pages: number;
}

export interface AdminActivity {
  id: number;
  action: string;
  detail: string;
  createdAt: string;
  name: string | null;
  username: string | null;
  userCode: string | null;
}

export function toWorkspaceData(data: AppData): WorkspaceData {
  return {
    tasks: data.tasks,
    events: data.events,
    goals: data.goals,
    notes: data.notes,
    messages: data.messages,
    settings: { ...data.settings, aiKey: '' },
  };
}

export const api = {
  register: (input: RegisterInput) =>
    request<{ user: ServerUser }>('/api/auth/register', { method: 'POST', body: JSON.stringify(input) }),
  login: (identifier: string, password: string) =>
    request<{ user: ServerUser }>('/api/auth/login', { method: 'POST', body: JSON.stringify({ identifier, password }) }),
  loginGoogle: (credential: string) =>
    request<{ user: ServerUser }>('/api/auth/google', { method: 'POST', body: JSON.stringify({ credential }) }),
  logout: () => request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  me: () => request<{ user: ServerUser }>('/api/auth/me'),

  updateProfile: (input: ProfileInput) =>
    request<{ user: ServerUser }>('/api/profile', { method: 'PATCH', body: JSON.stringify(input) }),
  deleteAccount: (input: { password?: string; confirm: string }) =>
    request<{ ok: boolean }>('/api/account', { method: 'DELETE', body: JSON.stringify(input) }),

  getWorkspace: () => request<{ workspace: WorkspaceData | null; updatedAt: string | null }>('/api/workspace'),
  saveWorkspace: (workspace: WorkspaceData) =>
    request<{ ok: boolean; updatedAt: string }>('/api/workspace', { method: 'PUT', body: JSON.stringify({ workspace }) }),

  friends: () => request<FriendsResponse>('/api/friends'),
  searchFriend: (code: string) => request<{ user: FriendProfile | null; relation?: string }>(`/api/friends/search?code=${encodeURIComponent(code)}`),
  sendFriendRequest: (code: string) => request<{ ok: boolean; status: string }>('/api/friends/request', { method: 'POST', body: JSON.stringify({ code }) }),
  respondFriendRequest: (requestId: string, action: 'accept' | 'reject') =>
    request<{ ok: boolean }>('/api/friends/respond', { method: 'POST', body: JSON.stringify({ requestId, action }) }),
  removeFriend: (friendId: string) => request<{ ok: boolean }>('/api/friends/remove', { method: 'POST', body: JSON.stringify({ friendId }) }),

  notifications: () => request<{ notifications: AppNotification[]; unread: number }>('/api/notifications'),
  readNotifications: () => request<{ ok: boolean }>('/api/notifications/read', { method: 'POST' }),

  uploadMedia: async (file: File) => {
    const form = new FormData();
    form.append('file', file);
    let response: Response;
    try { response = await fetch('/api/media/upload', { method: 'POST', body: form, credentials: 'include' }); }
    catch { throw new ApiError('Cannot reach the server. Check your connection.', 0, 'network_error'); }
    let payload: any = null; try { payload = await response.json(); } catch { payload = null; }
    if (!response.ok) throw new ApiError(typeof payload?.error === 'string' ? payload.error : 'Upload failed', response.status, typeof payload?.code === 'string' ? payload.code : undefined);
    return payload as { ok: boolean; url: string; type: 'image' | 'video'; contentType: string; size: number };
  },

  adminLogin: (adminKey: string, password: string) =>
    request<{ ok: boolean; expiresAt: string }>('/api/admin/login', { method: 'POST', body: JSON.stringify({ adminKey, password }) }),
  adminLogout: () => request<{ ok: boolean }>('/api/admin/logout', { method: 'POST' }),
  adminMe: () => request<{ admin: boolean }>('/api/admin/me'),
  adminStats: () => request<AdminStats>('/api/admin/stats'),
  adminUsers: (query: string, status: string, page: number) => {
    const params = new URLSearchParams({ query, status, page: String(page) });
    return request<AdminUsersResponse>(`/api/admin/users?${params.toString()}`);
  },
  adminActivity: () => request<{ activity: AdminActivity[] }>('/api/admin/activity?limit=70'),
  adminUpdateUser: (id: string, status: 'active' | 'suspended') =>
    request<{ ok: boolean; status: string }>(`/api/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  adminVips: () => request<{ vips: any[] }>('/api/admin/vips'),
  adminSetVip: (input: { userId?: string; email?: string; code?: string; isVip?: boolean; profileFrame?: string; usernameEffect?: string }) =>
    request<{ ok: boolean; isVip: boolean; vipPermanent: boolean }>('/api/admin/vip', { method: 'POST', body: JSON.stringify(input) }),

  presencePing: () => request<{ ok: boolean }>('/api/presence/ping', { method: 'POST' }),
  chatConversations: () => request<{ conversations: ChatConversation[] }>('/api/chat/conversations'),
  chatMessages: (withId: string, limit = 80, before?: number) => {
    const p = new URLSearchParams({ with: withId, limit: String(limit) });
    if (before) p.set('before', String(before));
    return request<{ conversationId: string; messages: DirectMessage[]; peer: FriendProfile | null; typing: boolean; blockedByMe: boolean; blockedMe: boolean }>(`/api/chat/messages?${p.toString()}`);
  },
  chatSend: (to: string, text: string) => request<{ ok: boolean; message: DirectMessage }>('/api/chat/messages', { method: 'POST', body: JSON.stringify({ to, text }) }),
  chatDelete: (messageId: string, mode: 'me' | 'all') => request<{ ok: boolean }>('/api/chat/messages/delete', { method: 'POST', body: JSON.stringify({ messageId, mode }) }),
  chatTyping: (to: string, typing: boolean) => request<{ ok: boolean }>('/api/chat/typing', { method: 'POST', body: JSON.stringify({ to, typing }) }),
  chatSearch: (q: string) => request<{ results: any[] }>(`/api/chat/search?q=${encodeURIComponent(q)}`),
  chatBlock: (userId: string, block: boolean) => request<{ ok: boolean; blocked: boolean }>('/api/chat/block', { method: 'POST', body: JSON.stringify({ userId, block }) }),
  chatReport: (userId: string, reason: string, detail = '', conversationId = '') => request<{ ok: boolean }>('/api/chat/report', { method: 'POST', body: JSON.stringify({ userId, reason, detail, conversationId }) }),
};
