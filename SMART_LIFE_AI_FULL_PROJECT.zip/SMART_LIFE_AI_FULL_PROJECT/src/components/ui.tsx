import { useEffect, useId, type CSSProperties, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Check, X, AlertTriangle, Crown, Shield, type LucideIcon } from 'lucide-react';
import { cn } from '../lib/cn';
import type { Category, Priority } from '../lib/types';
import { CATEGORY_COLORS, PRIORITY_COLORS } from '../lib/analytics';
import { useT } from '../lib/i18n';

export function Modal({ open, onClose, title, subtitle, children, footer, maxWidth = 'max-w-lg' }: { open: boolean; onClose: () => void; title: ReactNode; subtitle?: ReactNode; children: ReactNode; footer?: ReactNode; maxWidth?: string }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow; document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev; };
  }, [open, onClose]);
  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-[100] flex items-end justify-center sm:items-center sm:p-6">
      <button type="button" aria-label="Close" onClick={onClose} className="absolute inset-0 cursor-default bg-black/65 backdrop-blur-md animate-fade-in" />
      <div role="dialog" aria-modal="true" className={cn('relative flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-[28px] border border-line/10 bg-[var(--sidebar)] shadow-[0_40px_120px_-30px_rgba(0,0,0,.9)] backdrop-blur-2xl animate-pop sm:rounded-[26px]', maxWidth)} style={{ background: 'var(--sidebar)' }}>
        <div className="glow-border pointer-events-none absolute inset-0 rounded-[inherit] opacity-60" />
        <div className="flex items-start justify-between gap-4 border-b border-line/[0.07] px-5 py-4 sm:px-6">
          <div className="min-w-0"><h2 className="font-display text-lg font-bold leading-tight sm:text-xl">{title}</h2>{subtitle ? <p className="mt-1 text-xs leading-relaxed text-muted">{subtitle}</p> : null}</div>
          <button type="button" onClick={onClose} className="icon-btn h-9 w-9 shrink-0" aria-label="Close"><X size={16} /></button>
        </div>
        <div className="scroll-thin flex-1 overflow-y-auto px-5 py-5 sm:px-6">{children}</div>
        {footer ? <div className="flex items-center justify-end gap-2 border-t border-line/[0.07] px-5 py-4 sm:px-6">{footer}</div> : null}
      </div>
    </div>, document.body);
}

export function ConfirmDialog({ open, onClose, onConfirm, title, text, confirmLabel, tone = 'danger' }: { open: boolean; onClose: () => void; onConfirm: () => void; title: string; text: string; confirmLabel?: string; tone?: 'danger' | 'primary' }) {
  const { t } = useT();
  return (
    <Modal open={open} onClose={onClose} title={title} maxWidth="max-w-md" footer={<><button type="button" className="btn btn-ghost" onClick={onClose}>{t('cancel')}</button><button type="button" className={cn('btn', tone === 'danger' ? 'btn-danger' : 'btn-primary')} onClick={() => { onConfirm(); onClose(); }}>{confirmLabel ?? t('delete')}</button></>}>
      <div className="flex gap-4"><span className={cn('grid h-11 w-11 shrink-0 place-items-center rounded-2xl', tone === 'danger' ? 'bg-rose-500/12 text-rose-400' : 'bg-brand/15 text-brand')}><AlertTriangle size={20} /></span><p className="pt-1 text-sm leading-relaxed text-muted">{text}</p></div>
    </Modal>
  );
}

export function ProgressBar({ value, className, height = 8, showGlow = true }: { value: number; className?: string; height?: number; showGlow?: boolean }) {
  const safe = Math.max(0, Math.min(100, value));
  return (
    <div className={cn('relative w-full overflow-hidden rounded-full bg-line/[0.08]', className)} style={{ height }} role="progressbar" aria-valuenow={Math.round(safe)} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full transition-[width] duration-700 ease-out" style={{ width: `${safe}%`, backgroundImage: 'linear-gradient(90deg, #8b5cf6, #6366f1 55%, #38bdf8)', boxShadow: showGlow ? '0 0 16px rgba(124,92,255,.55)' : undefined }} />
    </div>
  );
}

export function ProgressRing({ value, size = 150, stroke = 12, children }: { value: number; size?: number; stroke?: number; children?: ReactNode }) {
  const id = useId().replace(/:/g, '');
  const radius = (size - stroke) / 2; const circumference = 2 * Math.PI * radius;
  const safe = Math.max(0, Math.min(100, value)); const offset = circumference - (safe / 100) * circumference;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90"><defs><linearGradient id={`ring-${id}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#c4b5fd" /><stop offset="45%" stopColor="#8b5cf6" /><stop offset="100%" stopColor="#38bdf8" /></linearGradient></defs>
        <circle cx={size/2} cy={size/2} r={radius} fill="none" strokeWidth={stroke} style={{ stroke: 'rgb(var(--line) / 0.08)' }} />
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={`url(#ring-${id})`} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={offset} style={{ transition: 'stroke-dashoffset 1.1s cubic-bezier(.22,1,.36,1)', filter: 'drop-shadow(0 0 8px rgba(124,92,255,.55))' }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

export function CategoryTag({ category, className }: { category: Category; className?: string }) {
  const { t } = useT(); const color = CATEGORY_COLORS[category];
  return <span className={cn('chip', className)} style={{ background: `${color}1f`, color, borderColor: `${color}33` }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />{t(category)}</span>;
}
export function PriorityTag({ priority, className }: { priority: Priority; className?: string }) {
  const { t } = useT(); const color = PRIORITY_COLORS[priority];
  return <span className={cn('chip', className)} style={{ background: `${color}18`, color, borderColor: `${color}2e` }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />{t(priority)}</span>;
}

export function Segmented<T extends string>({ options, value, onChange, className, size = 'md' }: { options: { value: T; label: string; icon?: LucideIcon }[]; value: T; onChange: (value: T) => void; className?: string; size?: 'sm' | 'md' }) {
  return (
    <div className={cn('inline-flex items-center gap-0.5 rounded-2xl border border-line/[0.07] bg-line/[0.035] p-1', className)}>
      {options.map((opt) => { const Icon = opt.icon; const active = opt.value === value;
        return <button key={opt.value} type="button" onClick={() => onChange(opt.value)} className={cn('inline-flex items-center gap-1.5 whitespace-nowrap rounded-xl font-semibold transition-all duration-200', size === 'sm' ? 'px-2.5 py-1.5 text-[11.5px]' : 'px-3 py-1.5 text-xs', active ? 'bg-white/[0.09] text-ink shadow-[inset_0_1px_0_rgba(255,255,255,.1)]' : 'text-muted hover:text-ink')}>{Icon ? <Icon size={13} /> : null}{opt.label}</button>; })}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, text, action, className }: { icon: LucideIcon; title: string; text: string; action?: ReactNode; className?: string }) {
  return (
    <div className={cn('flex flex-col items-center justify-center px-6 py-14 text-center', className)}>
      <div className="relative mb-4 grid h-16 w-16 place-items-center rounded-3xl border border-brand/20 bg-brand/10 text-brand"><div className="absolute inset-0 rounded-3xl bg-brand/20 blur-xl" /><Icon size={26} className="relative" /></div>
      <h3 className="font-display text-base font-semibold">{title}</h3><p className="mt-1.5 max-w-sm text-[13px] leading-relaxed text-muted">{text}</p>
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  );
}

export function PageHeader({ eyebrow, title, subtitle, actions }: { eyebrow?: string; title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>{eyebrow ? <div className="eyebrow mb-2"><span className="h-1.5 w-1.5 rounded-full bg-brand shadow-[0_0_8px_2px_rgba(139,92,246,.5)]" />{eyebrow}</div> : null}
        <h1 className="font-display text-[26px] font-extrabold leading-tight tracking-tight sm:text-[32px]">{title}</h1>
        {subtitle ? <p className="mt-1.5 max-w-2xl text-[13.5px] leading-relaxed text-muted">{subtitle}</p> : null}</div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}
export function SectionHeading({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return <div className="mb-4 flex items-start justify-between gap-3"><div><h2 className="font-display text-[15px] font-bold tracking-tight sm:text-base">{title}</h2>{hint ? <p className="mt-0.5 text-[11.5px] text-muted">{hint}</p> : null}</div>{action}</div>;
}
export function CheckMark({ className, style }: { className?: string; style?: CSSProperties }) { return <span className={cn('grid place-items-center', className)} style={style}><Check size={12} strokeWidth={3.5} /></span>; }

export const FRAME_STYLES = ['none','neon-purple','electric-blue','golden-vip','rainbow-glow','cyber-frame','diamond-frame','premium-black'] as const;
export const USERNAME_EFFECTS = ['none','rainbow','purple-neon','blue-electric','golden-vip','red-glow','green-glow','static'] as const;
export const VIP_ONLY_FRAMES = new Set(['golden-vip','rainbow-glow','diamond-frame','premium-black']);
export const VIP_ONLY_EFFECTS = new Set(['rainbow','golden-vip']);

export function VipBadge({ small }: { small?: boolean }) { return <span className={cn('vip-badge inline-flex items-center gap-1 rounded-full font-extrabold tracking-wide', small ? 'px-1.5 py-0.5 text-[8px]' : 'px-2 py-0.5 text-[9.5px]')} title="VIP"><Crown size={small ? 9 : 11} /> VIP</span>; }

export function OwnerBadge({ small }: { small?: boolean }) { return <span className={cn('owner-badge inline-flex items-center gap-1 rounded-full font-extrabold tracking-wide', small ? 'px-1.5 py-0.5 text-[8px]' : 'px-2 py-0.5 text-[9.5px]')} title="Owner"><Shield size={small ? 9 : 11} /> OWNER</span>; }

export function DisplayName({ name, isVip, isOwner, effect, color, className }: { name: string; isVip?: boolean; isOwner?: boolean; effect?: string; color?: string; className?: string }) {
  const eff = effect || 'none';
  const cls = cn('name-fx', eff !== 'none' && `name-fx-${eff}`);
  const style: CSSProperties = (eff === 'static' && color) ? { color, textShadow: color ? `0 0 10px ${color}55` : undefined } : {};
  return <span className={cn('inline-flex items-center gap-1.5 min-w-0 flex-wrap', className)}><span className={cls} style={style}>{name}</span>{isOwner ? <OwnerBadge small /> : null}{isVip ? <VipBadge small /> : null}</span>;
}

export function Avatar({ emoji, size = 40, className, ring = true, frame, glowEffect, online, borderColor }: { emoji: string; size?: number; className?: string; ring?: boolean; frame?: string; glowEffect?: string; online?: boolean; borderColor?: string }) {
  const src = typeof emoji === 'string' ? emoji.trim() : '';
  const isImage = !!src && (
    src.startsWith('data:image') ||
    /^https?:\/\//i.test(src) ||
    /^blob:/i.test(src) ||
    src.startsWith('/api/media/') ||
    /^\/[^\s]+\.(?:png|jpe?g|webp|gif|avif)(?:[?#].*)?$/i.test(src)
  );
  const f = frame && frame !== 'none' ? frame : '';
  const g = glowEffect && glowEffect !== 'none' ? glowEffect : '';
  return (
    <span className={cn('avatar-wrap relative inline-grid shrink-0 place-items-center', f && `frame-${f}`, g && `glow-${g}`)} style={{ width: size, height: size }}>
      <span className={cn('relative grid h-full w-full place-items-center overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-violet-500/25 via-indigo-500/15 to-sky-400/20', ring && !f && 'ring-2 ring-brand/20 ring-offset-2 ring-offset-transparent', className)} style={{ fontSize: size * 0.46, borderColor: borderColor || undefined }}>
        {isImage ? <img src={src} alt="" className="h-full w-full object-cover" loading="lazy" decoding="async" onError={(e) => { const el = e.currentTarget; el.style.display = 'none'; const fb = el.nextElementSibling as HTMLElement | null; if (fb) fb.style.display = 'grid'; }} /> : null}
        <span aria-hidden className={cn('h-full w-full place-items-center', isImage ? 'hidden' : 'grid')}>🦋</span>
      </span>
      {typeof online === 'boolean' ? <span className={cn('absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[rgb(var(--bg))]', online ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,.8)]' : 'bg-zinc-500')} /> : null}
    </span>
  );
}
