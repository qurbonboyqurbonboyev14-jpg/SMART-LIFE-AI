import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Flame,
  Plus,
  Sparkles,
  Target,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { useT, type TranslationKey } from '../lib/i18n';
import { cn } from '../lib/cn';
import {
  activeCategoryCounts,
  calculateStreak,
  categoryCounts,
  dailyProgress,
  eventsForDay,
  lastWeekCompleted,
  productivityScore,
  tasksForDay,
  upcomingEvents,
  weekCompleted,
  weekSeries,
} from '../lib/analytics';
import {
  diffDays,
  formatClock,
  formatDate,
  greetingKey,
  relativeDay,
  todayISO,
} from '../lib/date';
import type { Task } from '../lib/types';
import { BarChart, Donut } from '../components/charts';
import { CategoryTag, EmptyState, ProgressBar, ProgressRing, SectionHeading } from '../components/ui';
import { TaskItem } from '../components/TaskItem';
import { useToast } from '../components/Toast';
import { CATEGORY_COLORS } from '../lib/analytics';

function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 20000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

function StatCard({
  icon: Icon,
  label,
  value,
  unit,
  hint,
  tone,
  progress,
  delay,
}: {
  icon: typeof Flame;
  label: string;
  value: string | number;
  unit?: string;
  hint: React.ReactNode;
  tone: 'violet' | 'blue' | 'teal' | 'amber';
  progress?: number;
  delay?: string;
}) {
  const tones = {
    violet: 'from-violet-500/25 to-violet-500/5 text-violet-300 border-violet-400/20',
    blue: 'from-sky-500/25 to-sky-500/5 text-sky-300 border-sky-400/20',
    teal: 'from-emerald-500/25 to-emerald-500/5 text-emerald-300 border-emerald-400/20',
    amber: 'from-amber-500/25 to-amber-500/5 text-amber-300 border-amber-400/20',
  };
  return (
    <div className={cn('card card-hover card-pad animate-fade-up', delay)}>
      <div className="flex items-center justify-between">
        <span className={cn('grid h-9 w-9 place-items-center rounded-xl border bg-gradient-to-br', tones[tone])}>
          <Icon size={17} />
        </span>
        <span className="text-[10px] font-medium uppercase tracking-widest text-muted/70">{label}</span>
      </div>
      <div className="mt-4 flex items-end gap-1.5">
        <span className="stat-value">{value}</span>
        {unit ? <span className="pb-0.5 text-[11px] font-medium text-muted">{unit}</span> : null}
      </div>
      <div className="mt-2">{progress !== undefined ? <ProgressBar value={progress} height={5} /> : null}</div>
      <p className="mt-2 text-[11px] leading-relaxed text-muted">{hint}</p>
    </div>
  );
}

export default function Dashboard() {
  const { t, lang } = useT();
  const navigate = useNavigate();
  const toast = useToast();
  const now = useClock();

  const user = useApp((s) => s.user);
  const tasks = useApp((s) => s.tasks);
  const events = useApp((s) => s.events);
  const goals = useApp((s) => s.goals);
  const toggleTask = useApp((s) => s.toggleTask);

  const today = todayISO();
  const progress = dailyProgress(tasks);
  const streak = calculateStreak(tasks);
  const weekly = weekCompleted(tasks);
  const previousWeek = lastWeekCompleted(tasks);
  const score = productivityScore(tasks, goals);
  const activeGoals = goals.filter((g) => !g.completed);
  const avgGoal = activeGoals.length
    ? Math.round(activeGoals.reduce((s, g) => s + g.progress, 0) / activeGoals.length)
    : 0;

  const todays = useMemo(
    () =>
      tasksForDay(tasks, today).sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        const p = { high: 0, medium: 1, low: 2 };
        return p[a.priority] - p[b.priority];
      }),
    [tasks, today],
  );

  const todayEvents = useMemo(() => eventsForDay(events, today), [events, today]);
  const nextEvents = useMemo(() => upcomingEvents(events, 4), [events]);
  const series = useMemo(() => weekSeries(tasks, lang), [tasks, lang]);
  const categories = useMemo(() => activeCategoryCounts(tasks), [tasks]);
  const allCategories = useMemo(() => categoryCounts(tasks), [tasks]);
  const completionDelta = previousWeek ? Math.round(((weekly - previousWeek) / previousWeek) * 100) : 0;

  const handleToggle = (task: Task) => {
    toggleTask(task.id);
    toast({
      title: task.completed ? t('taskReopenedToast') : t('taskDoneToast'),
      description: task.title,
      tone: task.completed ? 'info' : 'success',
    });
  };

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Hero + ring */}
      <div className="grid gap-4 lg:grid-cols-12 lg:gap-5">
        <section className="card relative overflow-hidden p-5 sm:p-7 lg:col-span-8">
          <div className="pointer-events-none absolute -right-24 -top-32 h-72 w-72 rounded-full bg-brand/25 blur-[80px]" />
          <div className="pointer-events-none absolute -bottom-40 left-1/3 h-64 w-64 rounded-full bg-brand2/20 blur-[90px]" />
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.05]"
            style={{
              backgroundImage:
                'radial-gradient(circle at 1px 1px, rgba(255,255,255,.8) 1px, transparent 0)',
              backgroundSize: '22px 22px',
              maskImage: 'linear-gradient(120deg, #000, transparent 65%)',
              WebkitMaskImage: 'linear-gradient(120deg, #000, transparent 65%)',
            }}
          />
          <div className="relative">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip chip-brand">
                <Sparkles size={11} />
                AI WORKSPACE
              </span>
              <span className="chip chip-muted">
                <Clock3 size={11} />
                {formatClock(now)}
              </span>
              <span className="hidden items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2.5 py-1 text-[10.5px] font-medium text-emerald-300 sm:inline-flex">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                {t('cloudSynced')}
              </span>
            </div>

            <h1 className="mt-5 font-display text-[27px] font-extrabold leading-[1.12] tracking-tight sm:text-[36px]">
              {t('dashGreeting', {
                greet: t(greetingKey(now.getHours()) as TranslationKey),
                name: user.name.split(' ')[0] || user.name,
              })}
            </h1>
            <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-muted sm:text-sm">
              {t('dashSubtitle', {
                date: formatDate(today, lang, { weekday: 'long', day: 'numeric', month: 'long' }),
              })}
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => navigate('/assistant?prompt=day')}
                className="btn btn-primary"
              >
                <Sparkles size={15} />
                {t('planDay')}
                <ArrowUpRight size={14} />
              </button>
              <button
                type="button"
                onClick={() => navigate('/tasks?new=1')}
                className="btn btn-soft"
              >
                <Plus size={15} />
                {t('newTask')}
              </button>
            </div>

            <div className="mt-6 flex items-start gap-3 rounded-2xl border border-line/[0.07] bg-line/[0.03] p-3.5 sm:mt-7">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-500/25 to-sky-400/15 text-violet-200">
                <Sparkles size={16} />
              </span>
              <div className="min-w-0">
                <p className="text-[11.5px] font-semibold text-violet-200/90">{t('dashInsightTitle')}</p>
                <p className="mt-0.5 text-[12px] leading-relaxed text-muted">{t('dashInsightText')}</p>
              </div>
              <Link
                to="/assistant?prompt=day"
                className="ml-auto hidden shrink-0 items-center gap-1 whitespace-nowrap pt-1 text-[11px] font-semibold text-ink/90 transition hover:text-brand sm:flex"
              >
                {t('dashInsightCta')}
                <ArrowRight size={12} />
              </Link>
            </div>
          </div>
        </section>

        <section className="card card-pad relative overflow-hidden lg:col-span-4">
          <div className="pointer-events-none absolute -right-16 -top-20 h-48 w-48 rounded-full bg-brand/20 blur-3xl" />
          <div className="relative flex items-center justify-between">
            <div>
              <p className="font-display text-[13px] font-bold">{t('dailyProgress')}</p>
              <p className="mt-0.5 text-[10.5px] text-muted">{t('dailyProgressHint')}</p>
            </div>
            <span className="chip chip-brand">{today.slice(8, 10)}.{today.slice(5, 7)}</span>
          </div>

          <div className="mt-5 flex justify-center">
            <ProgressRing value={progress.percent} size={158} stroke={12}>
              <div className="text-center">
                <div className="font-display text-[34px] font-extrabold leading-none tracking-tight">
                  {progress.percent}
                  <span className="ml-0.5 text-base font-bold text-muted">%</span>
                </div>
                <p className="mt-1 text-[10px] font-medium uppercase tracking-wider text-muted">
                  {t('todaySummary', { done: progress.done, total: progress.total })}
                </p>
              </div>
            </ProgressRing>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-2">
            <div className="rounded-xl border border-line/[0.07] bg-line/[0.025] px-3 py-2">
              <p className="text-[9.5px] uppercase tracking-wider text-muted">{t('remainingCount', { n: progress.total - progress.done })}</p>
              <p className="mt-1 text-[12px] font-semibold">
                {progress.done === progress.total && progress.total > 0 ? t('allDone') : t('tasksToday')}
              </p>
            </div>
            <div className="rounded-xl border border-line/[0.07] bg-line/[0.025] px-3 py-2">
              <p className="text-[9.5px] uppercase tracking-wider text-muted">{t('streak')}</p>
              <p className="mt-1 flex items-center gap-1 text-[12px] font-semibold">
                <Flame size={12} className="text-amber-400" />
                {streak} {t('streakUnit')}
              </p>
            </div>
          </div>
          <Link
            to="/stats"
            className="mt-3 flex items-center justify-center gap-1 text-[11px] font-semibold text-muted transition hover:text-ink"
          >
            {t('navStats')}
            <ArrowRight size={12} />
          </Link>
        </section>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <div className="animate-fade-up delay-1">
          <StatCard
            icon={CheckCircle2}
            label={t('weeklyDone')}
            value={weekly}
            unit={t('tasks')}
            tone="violet"
            hint={
              <span className="flex items-center gap-1">
                {completionDelta >= 0 ? (
                  <TrendingUp size={11} className="text-emerald-400" />
                ) : (
                  <TrendingDown size={11} className="text-rose-400" />
                )}
                <span className={completionDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {completionDelta > 0 ? '+' : ''}
                  {completionDelta}%
                </span>{' '}
                {t('versusLastWeek')}
              </span>
            }
          />
        </div>
        <div className="animate-fade-up delay-2">
          <StatCard
            icon={Flame}
            label={t('streak')}
            value={streak}
            unit={t('streakUnit')}
            tone="amber"
            hint={t('productivityHint')}
          />
        </div>
        <div className="animate-fade-up delay-3">
          <StatCard
            icon={Target}
            label={t('activeGoals')}
            value={activeGoals.length}
            unit={t('goals').toLowerCase()}
            tone="teal"
            hint={`${t('avgProgressLabel')}: ${avgGoal}%`}
          />
        </div>
        <div className="animate-fade-up delay-4">
          <StatCard
            icon={Sparkles}
            label={t('productivityScore')}
            value={score}
            unit="/ 100"
            tone="blue"
            progress={score}
            hint={t('productivityHint')}
          />
        </div>
      </div>

      {/* Tasks + events */}
      <div className="grid gap-4 lg:grid-cols-12 lg:gap-5">
        <section className="card card-pad lg:col-span-7">
          <SectionHeading
            title={t('tasksToday')}
            hint={t('todaySummary', { done: progress.done, total: progress.total })}
            action={
              <Link
                to="/tasks"
                className="inline-flex items-center gap-1 rounded-xl px-2 py-1 text-[11.5px] font-semibold text-muted transition hover:bg-line/[0.05] hover:text-ink"
              >
                {t('viewAllTasks')}
                <ArrowRight size={12} />
              </Link>
            }
          />

          {todays.length === 0 ? (
            <EmptyState
              icon={CalendarDays}
              title={t('noTasksToday')}
              text={t('noTasksHint')}
              action={
                <Link to="/tasks?new=1" className="btn btn-primary btn-sm">
                  <Plus size={13} />
                  {t('newTask')}
                </Link>
              }
            />
          ) : (
            <div className="divide-y divide-line/[0.05]">
              {todays.slice(0, 5).map((task) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  dense
                  onToggle={() => handleToggle(task)}
                  onEdit={() => navigate('/tasks?edit=' + task.id)}
                />
              ))}
            </div>
          )}

          {todays.length > 5 ? (
            <Link
              to="/tasks"
              className="mt-2 flex items-center justify-center gap-1 rounded-xl border border-line/[0.07] bg-line/[0.025] py-2 text-[11px] font-medium text-muted transition hover:text-ink"
            >
              {t('moreItems', { n: todays.length - 5 })}
              <ArrowRight size={11} />
            </Link>
          ) : null}
        </section>

        <section className="card card-pad lg:col-span-5">
          <SectionHeading
            title={t('upcomingEvents')}
            hint={todayEvents.length ? `${todayEvents.length} · ${t('today')}` : t('noEventsToday')}
            action={
              <Link
                to="/calendar"
                className="grid h-7 w-7 place-items-center rounded-lg border border-line/[0.08] text-muted transition hover:border-brand/30 hover:text-ink"
                aria-label={t('openCalendar')}
              >
                <ArrowUpRight size={13} />
              </Link>
            }
          />

          {nextEvents.length === 0 ? (
            <EmptyState icon={CalendarDays} title={t('noUpcoming')} text={t('noUpcomingHint')} className="py-10" />
          ) : (
            <div className="space-y-2">
              {nextEvents.map((event) => {
                const color = CATEGORY_COLORS[event.category];
                const isToday = event.date === today;
                return (
                  <Link
                    key={event.id}
                    to="/calendar"
                    className="group flex items-center gap-3 rounded-2xl border border-line/[0.06] bg-line/[0.02] p-2.5 transition hover:border-brand/25 hover:bg-line/[0.04]"
                  >
                    <span
                      className="relative flex h-11 w-11 shrink-0 flex-col items-center justify-center rounded-xl border text-center"
                      style={{ background: `${color}14`, borderColor: `${color}30` }}
                    >
                      <span className="text-[14px] font-bold leading-none" style={{ color }}>
                        {event.date.slice(8, 10)}
                      </span>
                      <span className="mt-0.5 text-[8px] font-semibold uppercase tracking-wider text-muted">
                        {formatDate(event.date, lang, { month: 'short' })}
                      </span>
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12.5px] font-semibold">{event.title}</p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-[10.5px] text-muted">
                        <Clock3 size={10} />
                        {event.start} – {event.end}
                        <span className="text-muted/40">·</span>
                        {isToday
                          ? t('today')
                          : relativeDay(event.date, lang, {
                              today: t('today'),
                              tomorrow: t('tomorrow'),
                              yesterday: t('yesterday'),
                            })}
                      </p>
                    </div>
                    <ArrowUpRight
                      size={14}
                      className="shrink-0 text-muted/40 transition group-hover:text-ink"
                    />
                  </Link>
                );
              })}
            </div>
          )}
        </section>
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-12 lg:gap-5">
        <section className="card card-pad lg:col-span-7">
          <SectionHeading
            title={t('weeklyActivity')}
            hint={t('weeklyActivityHint')}
            action={
              <span className="chip chip-muted">
                {weekly} {t('tasks').toLowerCase()}
              </span>
            }
          />
          <BarChart data={series} height={178} />
          <div className="mt-4 flex items-center justify-between border-t border-line/[0.06] pt-3">
            <p className="text-[11px] text-muted">{t('focusAreasHint')}</p>
            <Link
              to="/stats"
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-muted transition hover:text-ink"
            >
              {t('navStats')}
              <ArrowRight size={11} />
            </Link>
          </div>
        </section>

        <section className="card card-pad lg:col-span-5">
          <SectionHeading title={t('focusAreas')} hint={t('focusAreasHint')} />
          <Donut
            segments={categories.map((c) => ({ ...c, label: t(c.key as TranslationKey) }))}
            centerLabel={t('tasks').toLowerCase()}
            centerValue={String(allCategories.reduce((s, c) => s + c.value, 0))}
            size={150}
          />
        </section>
      </div>

      {/* Goals preview */}
      <section className="card card-pad">
        <SectionHeading
          title={t('goalProgress')}
          hint={`${activeGoals.length} · ${t('activeGoals')}`}
          action={
            <Link
              to="/goals"
              className="inline-flex items-center gap-1 rounded-xl px-2 py-1 text-[11.5px] font-semibold text-muted transition hover:bg-line/[0.05] hover:text-ink"
            >
              {t('viewAll')}
              <ArrowRight size={12} />
            </Link>
          }
        />
        {activeGoals.length === 0 ? (
          <EmptyState icon={Target} title={t('noGoalsTitle')} text={t('noGoalsText')} className="py-8" />
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {activeGoals.slice(0, 3).map((goal) => {
              const days = diffDays(goal.targetDate, today);
              return (
                <Link
                  key={goal.id}
                  to="/goals"
                  className="group rounded-2xl border border-line/[0.07] bg-line/[0.022] p-3.5 transition hover:border-brand/25 hover:bg-line/[0.04]"
                >
                  <div className="flex items-start justify-between gap-2">
                    <CategoryTag category={goal.category} />
                    <span className="text-[10.5px] font-semibold text-muted">
                      {days >= 0 ? t('daysLeft', { n: days }) : t('deadlinePassed')}
                    </span>
                  </div>
                  <p className="mt-2 line-clamp-1 text-[12.5px] font-semibold">{goal.title}</p>
                  <div className="mt-2.5 flex items-center gap-2.5">
                    <ProgressBar value={goal.progress} height={5} />
                    <span className="w-8 shrink-0 text-right text-[11px] font-bold">{goal.progress}%</span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
