import { useMemo, useState } from 'react';
import {
  Award,
  CalendarRange,
  CheckCircle2,
  Flame,
  Percent,
  Sparkles,
  Target,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { useT, type TranslationKey } from '../lib/i18n';
import { cn } from '../lib/cn';
import {
  averageGoalProgress,
  bestProductiveDay,
  calculateStreak,
  CATEGORY_COLORS,
  completionRate,
  heatmapSeries,
  lastWeekCompleted,
  monthSeries,
  weekCompleted,
  weekSeries,
  yearSeries,
} from '../lib/analytics';
import { addDaysISO, diffDays, formatDate, todayISO } from '../lib/date';
import { CATEGORIES } from '../lib/types';
import type { Period } from './stats-types';
import { AreaChart, Donut, Heatmap } from '../components/charts';
import { PageHeader, ProgressBar, Segmented } from '../components/ui';

export default function Stats() {
  const { t, lang } = useT();
  const tasks = useApp((s) => s.tasks);
  const goals = useApp((s) => s.goals);

  const [period, setPeriod] = useState<Period>('week');
  const today = todayISO();

  const from =
    period === 'week'
      ? addDaysISO(today, -6)
      : period === 'month'
        ? addDaysISO(today, -29)
        : `${new Date().getFullYear()}-01-01`;

  const series =
    period === 'week'
      ? weekSeries(tasks, lang, 7)
      : period === 'month'
        ? monthSeries(tasks, lang, 30)
        : yearSeries(tasks, lang);

  const periodCompleted = useMemo(
    () =>
      tasks.filter(
        (task) =>
          task.completed &&
          task.completedAt &&
          task.completedAt.slice(0, 10) >= from &&
          task.completedAt.slice(0, 10) <= today,
      ),
    [tasks, from, today],
  );

  const totalCompleted = periodCompleted.length;
  const rate = completionRate(tasks, from, today);
  const avgGoal = averageGoalProgress(goals);
  const streak = calculateStreak(tasks);
  const weekly = weekCompleted(tasks);
  const prevWeek = lastWeekCompleted(tasks);
  const weeklyDelta = prevWeek ? Math.round(((weekly - prevWeek) / prevWeek) * 100) : 0;

  const categories = CATEGORIES.map((cat) => ({
    key: cat,
    label: t(cat as TranslationKey),
    value: periodCompleted.filter((task) => task.category === cat).length,
    color: CATEGORY_COLORS[cat],
  }));

  const goalOrder = [...goals].sort((a, b) => Number(a.completed) - Number(b.completed) || b.progress - a.progress);
  const bestDay = bestProductiveDay(tasks, lang, series);
  const heatmap = heatmapSeries(tasks, 70);

  const insight =
    rate >= 70 ? t('statInsightHigh', { rate }) : rate >= 40 ? t('statInsightMid', { rate }) : t('statInsightLow', { rate });

  const rangeLabel =
    period === 'week'
      ? `${formatDate(from, lang, { day: 'numeric', month: 'short' })} – ${formatDate(today, lang, { day: 'numeric', month: 'short' })}`
      : period === 'month'
        ? `${formatDate(from, lang, { day: 'numeric', month: 'short' })} – ${formatDate(today, lang, { day: 'numeric', month: 'short' })}`
        : `${formatDate(from, lang, { month: 'long' })} – ${formatDate(today, lang, { month: 'long' })}`;

  return (
    <div>
      <PageHeader
        eyebrow={t('workspace')}
        title={t('statsTitle')}
        subtitle={t('statsSubtitle')}
        actions={
          <Segmented
            value={period}
            onChange={setPeriod}
            options={[
              { value: 'week', label: t('periodWeek') },
              { value: 'month', label: t('periodMonth') },
              { value: 'year', label: t('periodYear') },
            ]}
          />
        }
      />

      <div className="card relative mb-4 overflow-hidden p-4 sm:p-5">
        <div className="pointer-events-none absolute -right-20 -top-24 h-56 w-56 rounded-full bg-brand/25 blur-[70px]" />
        <div className="relative flex items-start gap-3.5">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/30 to-sky-400/15 text-violet-200">
            <Sparkles size={18} />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-[11.5px] font-bold uppercase tracking-widest text-violet-200/90">
                {t('statInsightTitle')}
              </p>
              <span className="chip chip-muted">
                <CalendarRange size={10} />
                {rangeLabel}
              </span>
            </div>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">{insight}</p>
          </div>
        </div>
      </div>

      <div className="mb-4 grid grid-cols-2 gap-2.5 sm:gap-3.5 xl:grid-cols-4">
        <KpiCard
          icon={CheckCircle2}
          label={t('completedTotal')}
          value={String(totalCompleted)}
          hint={`${t('periodWeek')}: ${weekly} · ${t('vsPrev')}`}
          tone="violet"
        />
        <KpiCard
          icon={Percent}
          label={t('completionRate')}
          value={`${rate}%`}
          hint={t('activityHint')}
          tone="blue"
          progress={rate}
        />
        <KpiCard
          icon={Target}
          label={t('avgGoal')}
          value={`${avgGoal}%`}
          hint={`${goals.filter((g) => !g.completed).length} ${t('activeGoals').toLowerCase()}`}
          tone="teal"
          progress={avgGoal}
        />
        <KpiCard
          icon={Flame}
          label={t('currentStreak')}
          value={`${streak}`}
          hint={
            weeklyDelta >= 0
              ? `+${weeklyDelta}% ${t('versusLastWeek')}`
              : `${weeklyDelta}% ${t('versusLastWeek')}`
          }
          tone="amber"
          delta={weeklyDelta}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-12 xl:gap-5">
        <section className="card card-pad xl:col-span-8">
          <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
            <div>
              <h2 className="font-display text-[15px] font-bold">{t('activityTitle')}</h2>
              <p className="mt-0.5 text-[11px] text-muted">
                {period === 'week' ? t('weeklyActivityHint') : period === 'month' ? t('monthChartHint') : t('yearChartHint')}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="chip chip-brand">
                <TrendingUp size={10} />
                {totalCompleted}
              </span>
            </div>
          </div>

          {totalCompleted === 0 ? (
            <div className="flex h-[210px] items-center justify-center text-[12px] text-muted">{t('noChartData')}</div>
          ) : (
            <AreaChart data={series} height={205} />
          )}

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-line/[0.06] pt-3">
            <div className="flex items-center gap-2 text-[11px] text-muted">
              <Award size={13} className="text-amber-300" />
              {t('bestDay')}:{' '}
              <span className="font-semibold text-ink">
                {bestDay ? t('bestDayValue', { day: bestDay.label, n: bestDay.value }) : t('none')}
              </span>
            </div>
            <span className="text-[10px] text-muted/70">{rangeLabel}</span>
          </div>
        </section>

        <section className="card card-pad xl:col-span-4">
          <h2 className="font-display text-[15px] font-bold">{t('byCategoryTitle')}</h2>
          <p className="mt-0.5 text-[11px] text-muted">{t('byCategoryHint')}</p>
          <div className="mt-5">
            {totalCompleted === 0 ? (
              <p className="py-12 text-center text-[12px] text-muted">{t('noCategoryData')}</p>
            ) : (
              <Donut
                segments={categories}
                centerLabel={t('complete')}
                centerValue={String(totalCompleted)}
                size={152}
              />
            )}
          </div>
          <div className="mt-5 border-t border-line/[0.06] pt-3">
            <div className="flex items-center justify-between text-[10.5px] text-muted">
              <span>{t('completionRate')}</span>
              <span className="font-semibold text-ink">{rate}%</span>
            </div>
            <div className="mt-1.5">
              <ProgressBar value={rate} height={5} />
            </div>
          </div>
        </section>

        <section className="card card-pad xl:col-span-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-[15px] font-bold">{t('goalOverviewTitle')}</h2>
              <p className="mt-0.5 text-[11px] text-muted">{t('goalOverviewHint')}</p>
            </div>
            <span className="chip chip-muted">{goals.length}</span>
          </div>

          <div className="mt-4 space-y-3">
            {goalOrder.length === 0 ? (
              <p className="py-10 text-center text-[12px] text-muted">{t('noGoalsTitle')}</p>
            ) : (
              goalOrder.slice(0, 6).map((goal) => {
                const days = diffDays(goal.targetDate, today);
                return (
                  <div key={goal.id}>
                    <div className="flex items-center justify-between gap-2">
                      <p className="min-w-0 flex-1 truncate text-[11.5px] font-medium">{goal.title}</p>
                      <span className="shrink-0 text-[10.5px] font-bold">{goal.progress}%</span>
                    </div>
                    <div className="mt-1">
                      <ProgressBar
                        value={goal.progress}
                        height={5}
                        showGlow={!goal.completed}
                      />
                    </div>
                    <div className="mt-1 flex items-center justify-between text-[9px] text-muted">
                      <span>{t(goal.category as TranslationKey)}</span>
                      <span className={cn(days < 0 && !goal.completed && 'text-rose-400')}>
                        {goal.completed
                          ? t('goalCompletedBadge')
                          : days >= 0
                            ? t('daysLeft', { n: days })
                            : t('deadlinePassed')}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        <section className="card card-pad xl:col-span-7">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-[15px] font-bold">{t('heatmapTitle')}</h2>
              <p className="mt-0.5 text-[11px] text-muted">{t('heatmapHint')}</p>
            </div>
            <span className="chip chip-success">
              <Flame size={10} />
              {streak} {t('streakUnit')}
            </span>
          </div>
          <div className="mt-5">
            <Heatmap data={heatmap} labels={{ less: t('legendLess'), more: t('legendMore') }} />
          </div>
          <div className="mt-4 flex items-center justify-between border-t border-line/[0.06] pt-3 text-[10.5px] text-muted">
            <span>{t('heatmapHint')}</span>
            <span className="flex items-center gap-1">
              {weeklyDelta >= 0 ? (
                <TrendingUp size={11} className="text-emerald-400" />
              ) : (
                <TrendingDown size={11} className="text-rose-400" />
              )}
              {weeklyDelta >= 0 ? '+' : ''}
              {weeklyDelta}% {t('versusLastWeek')}
            </span>
          </div>
        </section>
      </div>
    </div>
  );
}

function KpiCard({
  icon: Icon,
  label,
  value,
  hint,
  tone,
  progress,
  delta,
}: {
  icon: typeof Flame;
  label: string;
  value: string;
  hint: string;
  tone: 'violet' | 'blue' | 'teal' | 'amber';
  progress?: number;
  delta?: number;
}) {
  const tones = {
    violet: 'from-violet-500/25 to-violet-500/5 text-violet-300',
    blue: 'from-sky-500/25 to-sky-500/5 text-sky-300',
    teal: 'from-emerald-500/25 to-emerald-500/5 text-emerald-300',
    amber: 'from-amber-500/25 to-amber-500/5 text-amber-300',
  };
  return (
    <div className="card card-pad">
      <div className="flex items-center justify-between">
        <span className={cn('grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br', tones[tone])}>
          <Icon size={15} />
        </span>
        {delta !== undefined ? (
          <span className={cn('chip', delta >= 0 ? 'chip-success' : 'chip-danger')}>
            {delta >= 0 ? '+' : ''}
            {delta}%
          </span>
        ) : null}
      </div>
      <p className="mt-3 text-[9.5px] uppercase tracking-wider text-muted">{label}</p>
      <p className="mt-1 font-display text-[26px] font-extrabold leading-none tracking-tight">{value}</p>
      {progress !== undefined ? (
        <div className="mt-2">
          <ProgressBar value={progress} height={4} />
        </div>
      ) : null}
      <p className="mt-2 line-clamp-1 text-[10px] text-muted">{hint}</p>
    </div>
  );
}
