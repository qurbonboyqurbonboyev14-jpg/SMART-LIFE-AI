import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  ArrowUpRight,
  BarChart3,
  CalendarRange,
  CheckCircle2,
  Flame,
  ListChecks,
  Send,
  Settings2,
  ShieldCheck,
  Sparkles,
  Sun,
  Target,
  Timer,
  Trash2,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { useApp, hasAiConfigured } from '../lib/store';
import { useT, type TranslationKey } from '../lib/i18n';
import { cn } from '../lib/cn';
import { requestAssistant } from '../lib/ai';
import {
  averageGoalProgress,
  calculateStreak,
  dailyProgress,
  eventsForDay,
} from '../lib/analytics';
import { formatClock, formatDate, todayISO } from '../lib/date';
import { Avatar, PageHeader, ProgressBar } from '../components/ui';
import { useToast } from '../components/Toast';

/* ------------------------------------------------------------------ */
/*  Lightweight markdown renderer                                      */
/* ------------------------------------------------------------------ */
function inline(text: string): ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
      return (
        <strong key={i} className="font-semibold text-ink">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      return (
        <code
          key={i}
          className="rounded-md border border-brand/20 bg-brand/10 px-1 py-0.5 font-mono text-[11px] tracking-wider text-violet-200"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    return <span key={i}>{part}</span>;
  });
}

function MarkdownLite({ text }: { text: string }) {
  const lines = text.split('\n');
  const blocks: ReactNode[] = [];
  let list: string[] = [];

  const flush = () => {
    if (!list.length) return;
    blocks.push(
      <ul key={`ul-${blocks.length}`} className="my-1.5 space-y-1.5">
        {list.map((item, i) => (
          <li key={i} className="flex gap-2">
            <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-brand" />
            <span className="min-w-0">{inline(item)}</span>
          </li>
        ))}
      </ul>,
    );
    list = [];
  };

  lines.forEach((raw, i) => {
    const line = raw.trimEnd();
    const trimmed = line.trim();
    if (trimmed.startsWith('- ')) {
      list.push(trimmed.slice(2));
      return;
    }
    flush();
    if (!trimmed) return;
    if (trimmed.startsWith('#### ')) {
      blocks.push(
        <h4 key={i} className="mt-3 font-display text-[12px] font-bold uppercase tracking-wider text-muted">
          {trimmed.slice(5)}
        </h4>,
      );
    } else if (trimmed.startsWith('### ')) {
      blocks.push(
        <h3 key={i} className="mb-1.5 mt-1 font-display text-[15px] font-bold tracking-tight">
          {inline(trimmed.slice(4))}
        </h3>,
      );
    } else if (trimmed.startsWith('> ')) {
      blocks.push(
        <blockquote
          key={i}
          className="my-2 rounded-r-xl border-l-2 border-brand/60 bg-brand/[0.07] px-3 py-2 text-[12.5px] italic text-muted"
        >
          {inline(trimmed.slice(2))}
        </blockquote>,
      );
    } else {
      blocks.push(
        <p key={i} className="leading-relaxed">
          {inline(trimmed)}
        </p>,
      );
    }
  });
  flush();

  return <div className="space-y-1.5 text-[13px]">{blocks}</div>;
}

/* ------------------------------------------------------------------ */
/*  Assistant                                                          */
/* ------------------------------------------------------------------ */
export default function Assistant() {
  const { t, lang } = useT();
  const toast = useToast();
  const [searchParams, setSearchParams] = useSearchParams();

  const user = useApp((s) => s.user);
  const tasks = useApp((s) => s.tasks);
  const events = useApp((s) => s.events);
  const goals = useApp((s) => s.goals);
  const messages = useApp((s) => s.messages);
  const settings = useApp((s) => s.settings);
  const addMessage = useApp((s) => s.addMessage);
  const clearMessages = useApp((s) => s.clearMessages);
  const theme = settings.theme;

  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const autoSent = useRef(false);

  const connected = hasAiConfigured(settings);
  const today = todayISO();
  const progress = dailyProgress(tasks);
  const todaysEvents = eventsForDay(events, today);
  const activeGoals = goals.filter((g) => !g.completed);
  const avgGoal = averageGoalProgress(goals);
  const streak = calculateStreak(tasks);

  const suggestions: { text: string; icon: typeof Sun }[] = [
    { text: t('suggestDay'), icon: Sun },
    { text: t('suggestWeek'), icon: CalendarRange },
    { text: t('suggestGoals'), icon: Target },
    { text: t('suggestAdvice'), icon: Timer },
  ];

  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || typing) return;
      addMessage({ role: 'user', text });
      setInput('');
      setTyping(true);

      const state = useApp.getState();
      const result = await requestAssistant(text, {
        user: state.user,
        tasks: state.tasks,
        events: state.events,
        goals: state.goals,
        notes: state.notes,
        messages: state.messages,
        settings: state.settings,
      });

      addMessage({ role: 'assistant', text: result.text, simulated: result.simulated });
      setTyping(false);
      if (result.failed) {
        toast({ title: t('errorFallback'), tone: 'error' });
      }
    },
    [addMessage, t, toast, typing],
  );

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [messages.length, typing]);

  useEffect(() => {
    const prompt = searchParams.get('prompt');
    if (!prompt || autoSent.current) return;
    autoSent.current = true;
    const map: Record<string, string> = {
      day: t('suggestDay'),
      week: t('suggestWeek'),
      goals: t('suggestGoals'),
      advice: t('suggestAdvice'),
    };
    void send(map[prompt] ?? t('suggestDay'));
    setSearchParams({}, { replace: true });
  }, [searchParams, send, setSearchParams, t]);

  const handleKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void send(input);
    }
  };

  const resize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  };

  const firstName = user.name.split(' ')[0] || user.name;

  return (
    <div>
      <PageHeader
        eyebrow={t('workspace')}
        title={t('assistantTitle')}
        subtitle={t('assistantSubtitle')}
        actions={
          <>
            <span
              className={cn(
                'chip',
                connected ? 'chip-success' : 'chip-brand',
              )}
            >
              {connected ? <Wifi size={11} /> : <WifiOff size={11} />}
              {connected ? t('connectedBadge') : t('simulatedBadge')}
            </span>
            {messages.length > 0 ? (
              <button
                type="button"
                onClick={() => {
                  clearMessages();
                  toast({ title: t('tClearedChat'), tone: 'info' });
                }}
                className="btn btn-soft btn-sm"
              >
                <Trash2 size={13} />
                {t('clearChat')}
              </button>
            ) : null}
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_310px] lg:gap-5">
        {/* Chat */}
        <section className="card flex h-[calc(100dvh-250px)] min-h-[540px] flex-col overflow-hidden">
          <div className="flex items-center justify-between gap-3 border-b border-line/[0.07] px-4 py-3 sm:px-5">
            <div className="flex min-w-0 items-center gap-3">
              <span className="relative grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-400 via-violet-500 to-sky-400 text-white shadow-[0_8px_24px_-8px_rgba(124,92,255,.9)]">
                <Sparkles size={17} />
                <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-[var(--surface)] bg-emerald-400" />
              </span>
              <div className="min-w-0">
                <p className="truncate text-[13px] font-bold leading-tight">SMART LIFE AI</p>
                <p className="truncate text-[10.5px] text-muted">
                  {connected ? t('connectedNote') : t('contextUsed')}
                </p>
              </div>
            </div>
            <span className="chip chip-muted hidden sm:inline-flex">
              <ShieldCheck size={11} />
              {connected ? t('ai') : t('simulatedBadge')}
            </span>
          </div>

          <div ref={scrollRef} className="scroll-thin flex-1 overflow-y-auto px-4 py-5 sm:px-5">
            {messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center py-2 text-center">
                <div className="relative mb-5">
                  <div className="absolute inset-0 animate-pulse-ring rounded-3xl" />
                  <div className="relative grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br from-violet-400 via-violet-500 to-sky-400 text-white shadow-[0_20px_50px_-15px_rgba(124,92,255,.9)]">
                    <Sparkles size={27} />
                  </div>
                </div>
                <h2 className="font-display text-xl font-extrabold tracking-tight sm:text-2xl">
                  {t('assistantWelcome', { name: firstName })}
                </h2>
                <p className="mt-2 max-w-md text-[12.5px] leading-relaxed text-muted">
                  {t('assistantWelcomeText')}
                </p>

                <div className="mt-6 grid w-full max-w-xl gap-2 sm:grid-cols-2">
                  {suggestions.map((s) => {
                    const Icon = s.icon;
                    return (
                      <button
                        key={s.text}
                        type="button"
                        onClick={() => void send(s.text)}
                        className="group flex items-center gap-2.5 rounded-2xl border border-line/[0.08] bg-line/[0.025] px-3.5 py-3 text-left transition hover:border-brand/30 hover:bg-brand/[0.07]"
                      >
                        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand/12 text-violet-300 transition group-hover:bg-brand/20">
                          <Icon size={15} />
                        </span>
                        <span className="min-w-0 flex-1 text-[11.5px] font-medium leading-snug">{s.text}</span>
                        <ArrowUpRight size={13} className="shrink-0 text-muted/40 transition group-hover:text-brand" />
                      </button>
                    );
                  })}
                </div>

                <div className="mt-5 flex flex-wrap items-center justify-center gap-2 text-[10.5px] text-muted">
                  <span className="chip chip-muted">
                    <ListChecks size={10} /> {tasks.filter((x) => !x.completed).length} {t('tasks').toLowerCase()}
                  </span>
                  <span className="chip chip-muted">
                    <CalendarRange size={10} /> {todaysEvents.length} {t('events').toLowerCase()}
                  </span>
                  <span className="chip chip-muted">
                    <Target size={10} /> {avgGoal}%
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <span className="rounded-full border border-line/[0.07] bg-line/[0.03] px-2.5 py-0.5 text-[9.5px] font-medium uppercase tracking-wider text-muted">
                    {formatDate(today, lang, { weekday: 'long', day: 'numeric', month: 'long' })}
                  </span>
                </div>

                {messages.map((m) => {
                  const isUser = m.role === 'user';
                  return (
                    <div key={m.id} className={cn('flex gap-2.5', isUser && 'justify-end')}>
                      {!isUser ? (
                        <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-400 via-violet-500 to-sky-400 text-white shadow-[0_6px_18px_-6px_rgba(124,92,255,.9)]">
                          <Sparkles size={14} />
                        </span>
                      ) : null}
                      <div className={cn('max-w-[88%] sm:max-w-[80%]', isUser && 'order-1')}>
                        <div
                          className={cn(
                            'rounded-2xl px-4 py-3',
                            isUser
                              ? 'rounded-br-md bg-gradient-to-br from-violet-500 to-indigo-600 text-white shadow-[0_14px_36px_-18px_rgba(124,92,255,.9)]'
                              : 'rounded-bl-md border border-line/[0.08] bg-line/[0.035]',
                          )}
                        >
                          {isUser ? (
                            <p className="whitespace-pre-wrap text-[13px] leading-relaxed">{m.text}</p>
                          ) : (
                            <MarkdownLite text={m.text} />
                          )}
                        </div>
                        <div className={cn('mt-1.5 flex items-center gap-2 px-1', isUser && 'justify-end')}>
                          <span className="text-[9.5px] text-muted/70">
                            {formatClock(new Date(m.createdAt))}
                          </span>
                          {!isUser && m.simulated ? (
                            <span className="rounded-md border border-line/[0.08] bg-line/[0.03] px-1.5 py-0.5 text-[8.5px] font-semibold uppercase tracking-wide text-muted">
                              {t('simulatedBadge')}
                            </span>
                          ) : null}
                          {!isUser && !m.simulated ? (
                            <span className="flex items-center gap-1 rounded-md border border-emerald-400/20 bg-emerald-500/10 px-1.5 py-0.5 text-[8.5px] font-semibold uppercase tracking-wide text-emerald-300">
                              <CheckCircle2 size={8} />
                              AI
                            </span>
                          ) : null}
                        </div>
                      </div>
                      {isUser ? <Avatar emoji={user.avatar} size={32} ring={false} className="mt-0.5" /> : null}
                    </div>
                  );
                })}

                {typing ? (
                  <div className="flex gap-2.5">
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-400 via-violet-500 to-sky-400 text-white">
                      <Sparkles size={14} />
                    </span>
                    <div className="rounded-2xl rounded-bl-md border border-line/[0.08] bg-line/[0.035] px-4 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className="flex gap-1">
                          <span className="h-1.5 w-1.5 animate-blink rounded-full bg-violet-300" />
                          <span className="h-1.5 w-1.5 animate-blink rounded-full bg-violet-300 [animation-delay:.2s]" />
                          <span className="h-1.5 w-1.5 animate-blink rounded-full bg-violet-300 [animation-delay:.4s]" />
                        </span>
                        <span className="text-[10.5px] text-muted">{t('thinking')}...</span>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            )}
          </div>

          {messages.length > 0 ? (
            <div className="scroll-thin flex gap-1.5 overflow-x-auto border-t border-line/[0.05] px-3 py-2">
              {suggestions.map((s) => (
                <button
                  key={s.text}
                  type="button"
                  onClick={() => void send(s.text)}
                  disabled={typing}
                  className="whitespace-nowrap rounded-full border border-line/[0.08] bg-line/[0.025] px-2.5 py-1.5 text-[10.5px] font-medium text-muted transition hover:border-brand/30 hover:text-ink disabled:opacity-50"
                >
                  {s.text}
                </button>
              ))}
            </div>
          ) : null}

          <div className="border-t border-line/[0.07] p-3 sm:p-4">
            <div className="flex items-end gap-2 rounded-2xl border border-line/[0.09] bg-line/[0.035] p-1.5 pl-3 transition focus-within:border-brand/40 focus-within:shadow-[0_0_0_4px_rgba(139,92,246,.09)]">
              <textarea
                ref={textareaRef}
                rows={1}
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  resize();
                }}
                onKeyDown={handleKey}
                placeholder={t('chatPlaceholder')}
                className="max-h-[120px] min-h-[36px] w-full resize-none bg-transparent py-2 text-[13px] leading-relaxed text-ink outline-none placeholder:text-muted/60"
              />
              <button
                type="button"
                onClick={() => void send(input)}
                disabled={!input.trim() || typing}
                className="btn btn-primary h-9 w-9 shrink-0 rounded-xl p-0 disabled:opacity-40"
                aria-label={t('send')}
              >
                <Send size={15} />
              </button>
            </div>
            <p className="mt-2 flex items-center justify-center gap-1.5 text-center text-[9.5px] leading-relaxed text-muted/70">
              <ShieldCheck size={10} />
              {t('assistantDisclaimer')}
            </p>
          </div>
        </section>

        {/* Context rail */}
        <aside className="space-y-4">
          <div className="card card-pad">
            <div className="flex items-center gap-2">
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-brand/12 text-violet-300">
                <Sparkles size={13} />
              </span>
              <p className="font-display text-[12.5px] font-bold">{t('contextUsed')}</p>
            </div>
            <div className="mt-3 space-y-2">
              <div className="flex items-center justify-between rounded-xl border border-line/[0.06] bg-line/[0.02] px-3 py-2">
                <span className="flex items-center gap-1.5 text-[11px] text-muted">
                  <ListChecks size={12} /> {t('tasksToday')}
                </span>
                <span className="text-[11.5px] font-bold">
                  {progress.done}/{progress.total}
                </span>
              </div>
              <div className="flex items-center justify-between rounded-xl border border-line/[0.06] bg-line/[0.02] px-3 py-2">
                <span className="flex items-center gap-1.5 text-[11px] text-muted">
                  <CalendarRange size={12} /> {t('eventsThisDay')}
                </span>
                <span className="text-[11.5px] font-bold">{todaysEvents.length}</span>
              </div>
              <div className="flex items-center justify-between rounded-xl border border-line/[0.06] bg-line/[0.02] px-3 py-2">
                <span className="flex items-center gap-1.5 text-[11px] text-muted">
                  <Flame size={12} /> {t('streak')}
                </span>
                <span className="text-[11.5px] font-bold">
                  {streak} {t('streakUnit')}
                </span>
              </div>
            </div>

            <div className="mt-4">
              <div className="flex items-center justify-between text-[10.5px] text-muted">
                <span>{t('avgProgressLabel')}</span>
                <span className="font-semibold text-ink">{avgGoal}%</span>
              </div>
              <div className="mt-1.5">
                <ProgressBar value={avgGoal} height={5} />
              </div>
              <p className="mt-2 text-[10px] text-muted">
                {activeGoals.length} · {t('activeGoals')}
              </p>
            </div>
          </div>

          <div
            className={cn(
              'card card-pad',
              connected ? 'border-emerald-400/20' : 'border-brand/20',
            )}
          >
            <div className="flex items-center justify-between">
              <span className="eyebrow">{t('aiIntegration')}</span>
              <span className={cn('chip', connected ? 'chip-success' : 'chip-brand')}>
                {connected ? t('aiStatusConnected') : t('simulatedBadge')}
              </span>
            </div>
            <p className="mt-2.5 text-[11px] leading-relaxed text-muted">
              {connected ? t('connectedNote') : t('simulatedNote')}
            </p>
            <Link to="/profile" className="btn btn-soft btn-sm mt-3 w-full">
              <Settings2 size={12} />
              {t('openAiSettings')}
            </Link>
          </div>

          <div className="card card-pad">
            <p className="eyebrow">{t('quickActions')}</p>
            <div className="mt-2.5 space-y-1">
              <Link
                to="/tasks"
                className="flex items-center justify-between rounded-xl px-2 py-2 text-[11.5px] text-muted transition hover:bg-line/[0.04] hover:text-ink"
              >
                <span className="flex items-center gap-2">
                  <ListChecks size={13} /> {t('navTasks')}
                </span>
                <span>{tasks.filter((x) => !x.completed).length}</span>
              </Link>
              <Link
                to="/goals"
                className="flex items-center justify-between rounded-xl px-2 py-2 text-[11.5px] text-muted transition hover:bg-line/[0.04] hover:text-ink"
              >
                <span className="flex items-center gap-2">
                  <Target size={13} /> {t('navGoals')}
                </span>
                <span>{goals.length}</span>
              </Link>
              <Link
                to="/stats"
                className="flex items-center justify-between rounded-xl px-2 py-2 text-[11.5px] text-muted transition hover:bg-line/[0.04] hover:text-ink"
              >
                <span className="flex items-center gap-2">
                  <BarChart3 size={13} /> {t('navStats')}
                </span>
                <ArrowUpRight size={12} />
              </Link>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
