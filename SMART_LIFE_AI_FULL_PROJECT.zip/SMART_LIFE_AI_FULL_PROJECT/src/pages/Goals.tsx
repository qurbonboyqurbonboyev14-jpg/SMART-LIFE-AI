import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  CheckCircle2,
  Flag,
  Minus,
  PartyPopper,
  Pencil,
  Plus,
  Sparkles,
  Target,
  Trash2,
  Trophy,
} from 'lucide-react';
import { useApp, type NewGoal } from '../lib/store';
import { useT } from '../lib/i18n';
import { cn } from '../lib/cn';
import { averageGoalProgress } from '../lib/analytics';
import { diffDays, formatDate, todayISO } from '../lib/date';
import type { Category, Goal } from '../lib/types';
import { CATEGORIES } from '../lib/types';
import { CATEGORY_COLORS } from '../lib/analytics';
import {
  CategoryTag,
  ConfirmDialog,
  EmptyState,
  Modal,
  PageHeader,
  ProgressBar,
} from '../components/ui';
import { useToast } from '../components/Toast';

export default function Goals() {
  const { t, lang } = useT();
  const toast = useToast();

  const goals = useApp((s) => s.goals);
  const addGoal = useApp((s) => s.addGoal);
  const updateGoal = useApp((s) => s.updateGoal);
  const deleteGoal = useApp((s) => s.deleteGoal);
  const setGoalProgress = useApp((s) => s.setGoalProgress);

  const [editor, setEditor] = useState<{ mode: 'new' | 'edit'; goal?: Goal } | null>(null);
  const [deleting, setDeleting] = useState<Goal | null>(null);
  const [celebrating, setCelebrating] = useState<Goal | null>(null);

  const active = goals.filter((g) => !g.completed);
  const completed = goals.filter((g) => g.completed);
  const avg = averageGoalProgress(goals);

  const changeProgress = (goal: Goal, delta: number) => {
    const next = Math.max(0, Math.min(100, goal.progress + delta));
    setGoalProgress(goal.id, next);
    if (next >= 100 && goal.progress < 100) {
      setCelebrating({ ...goal, progress: 100 });
      toast({ title: t('goalCompletedToast'), tone: 'celebrate' });
    }
  };

  const completeGoal = (goal: Goal) => {
    setGoalProgress(goal.id, 100);
    setCelebrating({ ...goal, progress: 100 });
    toast({ title: t('goalCompletedToast'), tone: 'celebrate' });
  };

  const handleSave = (values: NewGoal) => {
    if (editor?.mode === 'edit' && editor.goal) {
      updateGoal(editor.goal.id, {
        title: values.title,
        description: values.description,
        category: values.category,
        targetDate: values.targetDate,
      });
      setGoalProgress(editor.goal.id, values.progress);
      toast({ title: t('goalUpdatedToast'), description: values.title });
    } else {
      addGoal(values);
      toast({ title: t('goalAddedToast'), description: values.title });
    }
    setEditor(null);
  };

  return (
    <div>
      <PageHeader
        eyebrow={t('workspace')}
        title={t('goalsTitle')}
        subtitle={t('goalsSubtitle')}
        actions={
          <button type="button" className="btn btn-primary" onClick={() => setEditor({ mode: 'new' })}>
            <Plus size={15} />
            {t('newGoal')}
          </button>
        }
      />

      <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="card card-pad flex items-center gap-4">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/25 to-violet-500/5 text-violet-300">
            <Target size={20} />
          </span>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted">{t('activeGoalsLabel')}</p>
            <p className="mt-1 font-display text-2xl font-extrabold leading-none">{active.length}</p>
          </div>
        </div>
        <div className="card card-pad flex items-center gap-4">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-emerald-500/25 to-emerald-500/5 text-emerald-300">
            <Trophy size={20} />
          </span>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted">{t('completedGoalsLabel')}</p>
            <p className="mt-1 font-display text-2xl font-extrabold leading-none">{completed.length}</p>
          </div>
        </div>
        <div className="card card-pad">
          <div className="flex items-center justify-between">
            <p className="text-[10px] uppercase tracking-wider text-muted">{t('avgProgressLabel')}</p>
            <span className="text-[12px] font-bold">{avg}%</span>
          </div>
          <div className="mt-3">
            <ProgressBar value={avg} height={7} />
          </div>
          <p className="mt-2 text-[10.5px] text-muted">
            {t('goalsDoneCount', { done: completed.length, total: goals.length })}
          </p>
        </div>
      </div>

      {goals.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={Target}
            title={t('noGoalsTitle')}
            text={t('noGoalsText')}
            action={
              <button type="button" className="btn btn-primary" onClick={() => setEditor({ mode: 'new' })}>
                <Plus size={14} />
                {t('addFirstGoal')}
              </button>
            }
          />
        </div>
      ) : (
        <>
          {active.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {active.map((goal) => {
                const days = diffDays(goal.targetDate, todayISO());
                const color = CATEGORY_COLORS[goal.category];
                return (
                  <article key={goal.id} className="card card-hover group relative overflow-hidden p-4 sm:p-5">
                    <div
                      className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-20 blur-3xl transition-opacity group-hover:opacity-35"
                      style={{ background: color }}
                    />
                    <div className="relative">
                      <div className="flex items-start justify-between gap-2">
                        <CategoryTag category={goal.category} />
                        <div className="flex gap-0.5 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100">
                          <button
                            type="button"
                            onClick={() => setEditor({ mode: 'edit', goal })}
                            className="rounded-lg p-1.5 text-muted transition hover:bg-line/[0.07] hover:text-ink"
                            aria-label={t('edit')}
                          >
                            <Pencil size={13} />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleting(goal)}
                            className="rounded-lg p-1.5 text-muted transition hover:bg-rose-500/10 hover:text-rose-400"
                            aria-label={t('delete')}
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>

                      <h3 className="mt-2.5 font-display text-[15px] font-bold leading-snug">{goal.title}</h3>
                      <p className="mt-1 line-clamp-2 min-h-[32px] text-[11.5px] leading-relaxed text-muted">
                        {goal.description}
                      </p>

                      <div className="mt-4 flex items-end justify-between">
                        <div>
                          <p className="text-[9.5px] uppercase tracking-wider text-muted">{t('progress')}</p>
                          <p className="font-display text-[26px] font-extrabold leading-none tracking-tight">
                            {goal.progress}
                            <span className="text-xs font-bold text-muted">%</span>
                          </p>
                        </div>
                        <span className={cn('chip', days < 0 ? 'chip-danger' : 'chip-muted')}>
                          <Flag size={10} />
                          {days >= 0 ? t('daysLeft', { n: days }) : t('deadlinePassed')}
                        </span>
                      </div>

                      <div className="mt-2.5">
                        <ProgressBar value={goal.progress} height={7} />
                      </div>

                      <div className="mt-4 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => changeProgress(goal, -10)}
                          disabled={goal.progress <= 0}
                          className="icon-btn h-8 w-8 disabled:opacity-30"
                          aria-label={t('reduceProgress')}
                          title={t('reduceProgress')}
                        >
                          <Minus size={13} />
                        </button>
                        <button
                          type="button"
                          onClick={() => changeProgress(goal, 10)}
                          disabled={goal.progress >= 100}
                          className="icon-btn h-8 w-8 disabled:opacity-30"
                          aria-label={t('addProgress')}
                          title={t('addProgress')}
                        >
                          <Plus size={13} />
                        </button>
                        <button
                          type="button"
                          onClick={() => completeGoal(goal)}
                          className="btn btn-soft btn-sm ml-auto"
                          title={t('markGoalComplete')}
                        >
                          <CheckCircle2 size={13} />
                          <span className="hidden sm:inline">{t('markGoalComplete')}</span>
                          <span className="sm:hidden">100%</span>
                        </button>
                      </div>

                      <p className="mt-3 text-[9.5px] text-muted/70">
                        {formatDate(goal.targetDate, lang, { day: 'numeric', month: 'long', year: 'numeric' })}
                      </p>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : null}

          {completed.length > 0 ? (
            <div className="mt-6">
              <div className="mb-3 flex items-center gap-2">
                <Trophy size={15} className="text-amber-300" />
                <h2 className="font-display text-[15px] font-bold">
                  {t('completedGoalsLabel')}
                </h2>
                <span className="chip chip-success">{completed.length}</span>
              </div>
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {completed.map((goal) => (
                  <article
                    key={goal.id}
                    className="card group relative overflow-hidden border-emerald-400/15 p-4"
                  >
                    <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-emerald-400/10 blur-2xl" />
                    <div className="relative flex items-start gap-3">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-emerald-500/15 text-emerald-300">
                        <CheckCircle2 size={17} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="truncate text-[13px] font-semibold">{goal.title}</h3>
                          <span className="chip chip-success shrink-0">{t('goalCompletedBadge')}</span>
                        </div>
                        <div className="mt-2">
                          <ProgressBar value={100} height={5} />
                        </div>
                        <p className="mt-1.5 text-[10px] text-muted">
                          {goal.completedAt
                            ? formatDate(goal.completedAt.slice(0, 10), lang, { day: 'numeric', month: 'long' })
                            : formatDate(goal.targetDate, lang)}
                        </p>
                      </div>
                      <div className="flex shrink-0 gap-0.5">
                        <button
                          type="button"
                          onClick={() => setDeleting(goal)}
                          className="rounded-lg p-1.5 text-muted transition hover:bg-rose-500/10 hover:text-rose-400"
                          aria-label={t('delete')}
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          ) : null}
        </>
      )}

      <GoalEditor
        open={Boolean(editor)}
        mode={editor?.mode ?? 'new'}
        goal={editor?.goal}
        onClose={() => setEditor(null)}
        onSave={handleSave}
      />

      <ConfirmDialog
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={() => {
          if (deleting) {
            deleteGoal(deleting.id);
            toast({ title: t('goalDeletedToast'), tone: 'info' });
          }
        }}
        title={t('deleteGoalTitle')}
        text={t('deleteGoalText', { title: deleting?.title ?? '' })}
      />

      <Celebration goal={celebrating} onClose={() => setCelebrating(null)} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Goal editor                                                        */
/* ------------------------------------------------------------------ */
function GoalEditor({
  open,
  mode,
  goal,
  onClose,
  onSave,
}: {
  open: boolean;
  mode: 'new' | 'edit';
  goal?: Goal;
  onClose: () => void;
  onSave: (values: NewGoal) => void;
}) {
  const { t } = useT();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Category>('personal');
  const [targetDate, setTargetDate] = useState('');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTitle(goal?.title ?? '');
    setDescription(goal?.description ?? '');
    setCategory(goal?.category ?? 'personal');
    setTargetDate(goal?.targetDate ?? '');
    setProgress(goal?.progress ?? 0);
    setError(false);
  }, [open, goal]);

  const submit = () => {
    if (!title.trim() || !targetDate) {
      setError(true);
      return;
    }
    onSave({
      title: title.trim(),
      description: description.trim(),
      category,
      targetDate,
      progress,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={mode === 'edit' ? t('editGoal') : t('newGoal')}
      subtitle={t('goalsSubtitle')}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            {t('cancel')}
          </button>
          <button type="button" className="btn btn-primary" onClick={submit}>
            <Target size={14} />
            {mode === 'edit' ? t('goalUpdateBtn') : t('goalAddedBtn')}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="field-label" htmlFor="goal-title">
            {t('goalName')} *
          </label>
          <input
            id="goal-title"
            autoFocus
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              setError(false);
            }}
            placeholder={t('goalNamePlaceholder')}
            className="field"
          />
        </div>

        <div>
          <label className="field-label" htmlFor="goal-desc">
            {t('goalDesc')} <span className="normal-case tracking-normal opacity-60">({t('optional')})</span>
          </label>
          <textarea
            id="goal-desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={t('goalDescPlaceholder')}
            rows={3}
            className="field"
          />
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="field-label" htmlFor="goal-date">
              {t('goalTargetDate')} *
            </label>
            <input
              id="goal-date"
              type="date"
              value={targetDate}
              onChange={(e) => {
                setTargetDate(e.target.value);
                setError(false);
              }}
              className="field"
            />
          </div>
          <div>
            <span className="field-label">{t('taskCategory')}</span>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
              className="field"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {t(c)}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <span className="field-label">{t('progress')}</span>
            <span className="text-[12px] font-bold">{progress}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={5}
            value={progress}
            onChange={(e) => setProgress(Number(e.target.value))}
            className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-line/10 accent-violet-500"
          />
          <div className="mt-1.5">
            <ProgressBar value={progress} height={6} />
          </div>
        </div>

        <div className="flex items-center gap-2 rounded-xl border border-line/[0.06] bg-line/[0.02] px-3 py-2.5">
          <Sparkles size={13} className="text-brand" />
          <p className="text-[10.5px] leading-relaxed text-muted">{t('goalDescPlaceholder')}</p>
        </div>

        {error ? <p className="text-[11.5px] text-rose-400">{t('goalName')} / {t('goalTargetDate')}</p> : null}
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ */
/*  Celebration                                                        */
/* ------------------------------------------------------------------ */
export function Celebration({ goal, onClose }: { goal: Goal | null; onClose: () => void }) {
  const { t } = useT();
  const pieces = useMemo(
    () =>
      Array.from({ length: 54 }, (_, i) => ({
        left: Math.random() * 100,
        delay: Math.random() * 2.2,
        duration: 2.4 + Math.random() * 2,
        color: ['#a78bfa', '#7dd3fc', '#f0abfc', '#fbbf24', '#34d399'][i % 5],
        drift: `${Math.random() * 200 - 100}px`,
        rotate: Math.random() * 360,
      })),
    [],
  );

  if (!goal) return null;

  return createPortal(
    <div className="fixed inset-0 z-[130] flex items-center justify-center p-5">
      <div className="absolute inset-0 overflow-hidden bg-black/70 backdrop-blur-md" onClick={onClose}>
        {pieces.map((p, i) => (
          <span
            key={i}
            className="confetti-piece"
            style={{
              left: `${p.left}%`,
              background: p.color,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
              ['--drift' as string]: p.drift,
              transform: `rotate(${p.rotate}deg)`,
            }}
          />
        ))}
      </div>
      <div className="relative w-full max-w-sm overflow-hidden rounded-[28px] border border-brand/25 bg-[var(--sidebar)] p-7 text-center shadow-[0_40px_120px_-20px_rgba(124,92,255,.6)] backdrop-blur-2xl animate-pop">
        <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-brand/40 blur-3xl" />
        <div className="relative">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br from-violet-400 via-violet-500 to-sky-400 text-white shadow-[0_20px_50px_-12px_rgba(124,92,255,.9)]">
            <PartyPopper size={28} />
          </div>
          <h2 className="mt-4 font-display text-xl font-extrabold">{t('celebrateTitle')}</h2>
          <p className="mt-2 text-[12.5px] leading-relaxed text-muted">
            {t('celebrateText', { title: goal.title })}
          </p>
          <div className="mt-4 rounded-2xl border border-line/[0.08] bg-line/[0.03] p-3">
            <CategoryTag category={goal.category} />
            <p className="mt-2 font-display text-[30px] font-extrabold leading-none grad-text">100%</p>
            <p className="mt-1 text-[10px] uppercase tracking-wider text-muted">{t('goalCompletedBadge')}</p>
          </div>
          <button type="button" className="btn btn-primary mt-5 w-full" onClick={onClose}>
            {t('celebrateCta')}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
