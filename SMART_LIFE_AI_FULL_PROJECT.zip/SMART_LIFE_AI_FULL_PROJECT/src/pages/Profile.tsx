import { useEffect, useMemo, useRef, useState, type ChangeEvent, type ReactNode } from 'react';
import {
  BellRing, Check, Copy, Crop, Eye, EyeOff, Globe2, KeyRound, Link2, Loader2,
  Mail, Moon, Palette, Save, ShieldAlert, Sparkles, Sun, Trash2, Unlink, Upload, UserRound, type LucideIcon,
} from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { useApp, hasAiConfigured } from '../lib/store';
import { useT } from '../lib/i18n';
import { cn } from '../lib/cn';
import { formatDate } from '../lib/date';
import type { AppData, Lang, Theme } from '../lib/types';
import { AVATARS } from '../lib/types';
import { Avatar, ConfirmDialog, DisplayName, FRAME_STYLES, PageHeader, USERNAME_EFFECTS, VIP_ONLY_EFFECTS, VIP_ONLY_FRAMES } from '../components/ui';
import { Crown } from 'lucide-react';
import { useToast } from '../components/Toast';

function dataUrlFromFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(typeof r.result === 'string' ? r.result : '');
    r.onerror = () => reject(new Error('read_failed'));
    r.readAsDataURL(file);
  });
}

async function cropToDataUrl(src: string, zoom: number, offsetY: number, rotate = 0): Promise<string> {
  const img = new Image();
  img.src = src;
  await new Promise((res, rej) => { img.onload = res; img.onerror = rej; });
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) return src;
  const base = Math.max(size / img.width, size / img.height) * zoom;
  const w = img.width * base;
  const h = img.height * base;
  ctx.fillStyle = '#0b0b14';
  ctx.fillRect(0, 0, size, size);
  ctx.save();
  ctx.translate(size / 2, size / 2 + offsetY);
  ctx.rotate((rotate * Math.PI) / 180);
  ctx.drawImage(img, -w / 2, -h / 2, w, h);
  ctx.restore();
  return canvas.toDataURL('image/jpeg', 0.9);
}

function CropModal({ src, onClose, onSave, savingLabel }: { src: string; onClose: () => void; onSave: (dataUrl: string) => Promise<void> | void; savingLabel?: string }) {
  const { t } = useT();
  const [zoom, setZoom] = useState(1);
  const [offsetY, setOffsetY] = useState(0);
  const [rotate, setRotate] = useState(0);
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(src);

  useEffect(() => {
    let active = true;
    const id = window.setTimeout(async () => {
      try { const out = await cropToDataUrl(src, zoom, offsetY, rotate); if (active) setPreview(out); } catch { /* ignore */ }
    }, 60);
    return () => { active = false; window.clearTimeout(id); };
  }, [src, zoom, offsetY, rotate]);

  const save = async () => {
    setBusy(true);
    try { await onSave(await cropToDataUrl(src, zoom, offsetY, rotate)); } finally { setBusy(false); }
  };

  return (
    <div className="crop-modal" role="dialog" aria-modal="true">
      <div className="crop-card">
        <h3 className="font-display text-[15px] font-bold">{t('profilePicture')}</h3>
        <p className="mt-1 text-[11px] text-muted">Preview, crop, zoom, rotate and reposition before saving.</p>
        <div className="crop-preview mt-3"><img src={preview} alt="" /></div>
        <label className="mt-3 block"><span className="field-label">Zoom</span><input type="range" min={1} max={3} step={0.01} value={zoom} onChange={(e)=>setZoom(Number(e.target.value))} className="w-full" /></label>
        <label className="mt-2 block"><span className="field-label">Position</span><input type="range" min={-220} max={220} step={1} value={offsetY} onChange={(e)=>setOffsetY(Number(e.target.value))} className="w-full" /></label>
        <label className="mt-2 block"><span className="field-label">Rotate</span><input type="range" min={-180} max={180} step={1} value={rotate} onChange={(e)=>setRotate(Number(e.target.value))} className="w-full" /></label>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" className="btn btn-soft" onClick={onClose} disabled={busy}>{t('cancel')}</button>
          <button type="button" className="btn btn-primary" disabled={busy} onClick={save}>{busy?<Loader2 size={14} className="animate-spin"/>:<Crop size={14}/>} {savingLabel || t('save')}</button>
        </div>
      </div>
    </div>
  );
}

export default function Profile() {
  const { t, lang } = useT();
  const toast = useToast();
  const authUser = useAuth((s) => s.user);
  const refresh = useAuth((s) => s.refresh);
  const logout = useAuth((s) => s.logout);

  const user = useApp((s) => s.user);
  const settings = useApp((s) => s.settings);
  const tasks = useApp((s) => s.tasks);
  const goals = useApp((s) => s.goals);
  const notes = useApp((s) => s.notes);
  const updateUser = useApp((s) => s.updateUser);
  const updateSettings = useApp((s) => s.updateSettings);

  const [firstName, setFirstName] = useState(user.firstName || '');
  const [lastName, setLastName] = useState(user.lastName || '');
  const [username, setUsername] = useState(user.username || '');
  const [email, setEmail] = useState(user.email || '');
  const [bio, setBio] = useState(user.bio || '');
  const [interests, setInterests] = useState(user.interests || '');
  const [avatar, setAvatar] = useState(user.avatar || '🦋');
  const [profileFrame, setProfileFrame] = useState((user as any).selectedFrameId || (user as any).profileFrame || 'none');
  const [usernameEffect, setUsernameEffect] = useState((user as any).selectedNicknameEffect || (user as any).usernameEffect || 'none');
  const [usernameColor, setUsernameColor] = useState((user as any).selectedNicknameColor || (user as any).usernameColor || '#a78bfa');
  const [appliedFrame, setAppliedFrame] = useState((user as any).selectedFrameId || (user as any).profileFrame || 'none');
  const [appliedEffect, setAppliedEffect] = useState((user as any).selectedNicknameEffect || (user as any).usernameEffect || 'none');
  const [appliedColor, setAppliedColor] = useState((user as any).selectedNicknameColor || (user as any).usernameColor || '#a78bfa');
  const [borderColor, setBorderColor] = useState((user as any).borderColor || '#8b5cf6');
  const [glowEffect, setGlowEffect] = useState((user as any).glowEffect || 'none');
  const [profileTheme, setProfileTheme] = useState((user as any).profileTheme || 'default');
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [savingAppearance, setSavingAppearance] = useState(false);

  const [aiKey, setAiKey] = useState(settings.aiKey);
  const [aiBase, setAiBase] = useState(settings.aiBase);
  const [aiModel, setAiModel] = useState(settings.aiModel);
  const [showKey, setShowKey] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNew, setConfirmNew] = useState('');
  const [pwBusy, setPwBusy] = useState(false);

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleteText, setDeleteText] = useState('');
  const [deletePass, setDeletePass] = useState('');
  const [deleteBusy, setDeleteBusy] = useState(false);

  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setFirstName(user.firstName || '');
    setLastName(user.lastName || '');
    setUsername(user.username || '');
    setEmail(user.email || '');
    setBio(user.bio || '');
    setInterests(user.interests || '');
    setAvatar(user.avatar || '🦋');
    const pf = (user as any).selectedFrameId || (user as any).profileFrame || 'none';
    const ne = (user as any).selectedNicknameEffect || (user as any).usernameEffect || 'none';
    const nc = (user as any).selectedNicknameColor || (user as any).usernameColor || '#a78bfa';
    setProfileFrame(pf); setUsernameEffect(ne); setUsernameColor(nc);
    setAppliedFrame(pf); setAppliedEffect(ne); setAppliedColor(nc);
    setBorderColor((user as any).borderColor || '#8b5cf6'); setGlowEffect((user as any).glowEffect || 'none'); setProfileTheme((user as any).profileTheme || 'default');
  }, [user.firstName, user.lastName, user.username, user.email, user.bio, user.interests, user.avatar, (user as any).profileFrame, (user as any).usernameEffect, (user as any).usernameColor, (user as any).selectedFrameId, (user as any).selectedNicknameEffect, (user as any).selectedNicknameColor, (user as any).borderColor, (user as any).glowEffect, (user as any).profileTheme]);

  useEffect(() => { setAiKey(settings.aiKey); setAiBase(settings.aiBase); setAiModel(settings.aiModel); }, [settings.aiKey, settings.aiBase, settings.aiModel]);

  const fullName = useMemo(() => [firstName.trim(), lastName.trim()].filter(Boolean).join(' ').trim(), [firstName, lastName]);

  const copyId = async () => {
    if (!user.userCode) return;
    try { await navigator.clipboard.writeText(user.userCode); toast({ title: t('idCopied'), tone: 'success' }); } catch { toast({ title: user.userCode, tone: 'info' }); }
  };

  const onPickPhoto = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!/^image\/(jpeg|jpg|png|webp)$/i.test(file.type)) { toast({ title: 'Please choose a JPG, PNG or WEBP image.', tone: 'error' }); return; }
    if (file.size > 12 * 1024 * 1024) { toast({ title: 'Image is too large. Please choose a smaller file.', tone: 'error' }); return; }
    try { setCropSrc(await dataUrlFromFile(file)); } catch { toast({ title: 'Could not read image', tone: 'error' }); }
  };

  const saveProfile = async () => {
    if (fullName.length < 2) { toast({ title: t('fullName') + ' *', tone: 'error' }); return; }
    setSaving(true);
    try {
      const res = await api.updateProfile({ name: fullName, firstName: firstName.trim(), lastName: lastName.trim(), username: username.trim(), email: email.trim(), bio, interests, avatar });
      updateUser(res.user as any);
      await refresh();
      toast({ title: t('profileSaved'), tone: 'success' });
    } catch (e: any) { toast({ title: e?.message || 'Save failed', tone: 'error' }); }
    finally { setSaving(false); }
  };

  const applyAppearance = async (overrides?: { profileFrame?: string; usernameEffect?: string; usernameColor?: string }) => {
    const ov = overrides || {};
    const pf = ov.profileFrame !== undefined ? ov.profileFrame : profileFrame;
    const ne = ov.usernameEffect !== undefined ? ov.usernameEffect : usernameEffect;
    const nc = ov.usernameColor !== undefined ? ov.usernameColor : usernameColor;
    if (!pf || !ne) { toast({ title: 'Please select an option before applying.', tone: 'error' }); return; }
    if (!overrides && pf === appliedFrame && ne === appliedEffect && nc === appliedColor) { toast({ title: 'No new customization selected to apply.', tone: 'info' }); return; }
    setSavingAppearance(true);
    try {
      const res = await api.updateProfile({ selectedFrameId: pf, selectedNicknameEffect: ne, selectedNicknameColor: nc, profileFrame: pf, usernameEffect: ne, usernameColor: nc, borderColor, glowEffect, profileTheme });
      updateUser(res.user as any);
      const apf = (res.user as any).selectedFrameId || (res.user as any).profileFrame || 'none';
      const ane = (res.user as any).selectedNicknameEffect || (res.user as any).usernameEffect || 'none';
      const anc = (res.user as any).selectedNicknameColor || (res.user as any).usernameColor || '#a78bfa';
      setProfileFrame(apf); setUsernameEffect(ane); setUsernameColor(anc);
      setAppliedFrame(apf); setAppliedEffect(ane); setAppliedColor(anc);
      await refresh();
      toast({ title: 'Customization applied and saved.', tone: 'success' });
    } catch (e: any) { toast({ title: e?.message || 'Could not apply customization', tone: 'error' }); }
    finally { setSavingAppearance(false); }
  };

  const removeFrame = async () => {
    setProfileFrame('none');
    await applyAppearance({ profileFrame: 'none' });
  };

  const savePassword = async () => {
    if (!newPassword || newPassword.length < 8) { toast({ title: t('newPassword'), tone: 'error' }); return; }
    if (newPassword !== confirmNew) { toast({ title: t('passwordsNoMatch'), tone: 'error' }); return; }
    if (user.authProvider === 'local' && !currentPassword) { toast({ title: t('currentPassword'), tone: 'error' }); return; }
    setPwBusy(true);
    try {
      await api.updateProfile({ currentPassword: user.authProvider === 'local' ? currentPassword : undefined, newPassword });
      setCurrentPassword(''); setNewPassword(''); setConfirmNew('');
      toast({ title: t('passwordUpdated'), tone: 'success' });
    } catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); }
    finally { setPwBusy(false); }
  };

  const doDeleteAccount = async () => {
    if (deleteText !== 'DELETE') { toast({ title: t('deleteAccountType'), tone: 'error' }); return; }
    if (user.authProvider === 'local' && !deletePass) { toast({ title: t('passwordLabel'), tone: 'error' }); return; }
    setDeleteBusy(true);
    try {
      await api.deleteAccount({ confirm: 'DELETE', password: user.authProvider === 'local' ? deletePass : undefined });
      await logout();
    } catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); setDeleteBusy(false); }
  };

  const saveAi = () => {
    if (!aiKey.trim() || !aiBase.trim()) { toast({ title: t('aiRequired'), tone: 'error' }); return; }
    updateSettings({ aiKey: aiKey.trim(), aiBase: aiBase.trim(), aiModel: aiModel.trim() });
    toast({ title: t('aiSaved'), tone: 'success' });
  };

  const disconnectAi = () => { updateSettings({ aiKey: '' }); setAiKey(''); toast({ title: t('aiDisconnected'), tone: 'info' }); };
  const connected = hasAiConfigured(settings);

  return (
    <div>
      {cropSrc ? <CropModal src={cropSrc} onClose={()=>setCropSrc(null)} savingLabel={t('saveChanges')} onSave={async (dataUrl) => {
        try {
          const blob = await (await fetch(dataUrl)).blob();
          const file = new File([blob], 'profile.jpg', { type: 'image/jpeg' });
          const up: any = await api.uploadMedia(file);
          const uploadedUrl = String(up?.url || up?.imageUrl || up?.secure_url || up?.data?.url || '').trim();
          if (!uploadedUrl || !(uploadedUrl.startsWith('/api/media/') || uploadedUrl.startsWith('http://') || uploadedUrl.startsWith('https://') || uploadedUrl.startsWith('data:image'))) {
            throw new Error('Upload did not return a valid image URL');
          }
          const res = await api.updateProfile({ avatar: uploadedUrl });
          setAvatar(uploadedUrl);
          updateUser(res.user as any);
          await refresh();
          setCropSrc(null);
          toast({ title: t('profileSaved'), tone: 'success' });
        } catch (e: any) {
          toast({ title: e?.message || 'Could not upload profile picture', tone: 'error' });
        }
      }} /> : null}
      <PageHeader eyebrow={t('workspace')} title={t('profileTitle')} subtitle={t('profileSubtitle')} />

      <div className="grid gap-4 lg:grid-cols-[330px_minmax(0,1fr)] lg:gap-5">
        <div className="space-y-4">
          <section className="card overflow-hidden">
            <div className="relative h-24 bg-gradient-to-br from-violet-600/50 via-indigo-600/35 to-sky-500/25" />
            <div className="px-5 pb-5">
              <div className="-mt-8 flex items-end justify-between">
                <Avatar emoji={avatar} size={68} className="border-2 border-[var(--surface)]" frame={profileFrame} glowEffect={glowEffect} borderColor={borderColor} />
                <span className="chip chip-success mb-1">{t('active')}</span>
              </div>
              <h2 className="mt-3 font-display text-lg font-extrabold leading-tight"><DisplayName name={user.name} isVip={(user as any).isVip} isOwner={(user as any).isOwner} effect={(user as any).selectedNicknameEffect || (user as any).usernameEffect} color={(user as any).selectedNicknameColor || (user as any).usernameColor} /></h2>
              <p className="mt-0.5 text-[11.5px] text-muted">@{user.username}</p>
              <p className="mt-2 flex items-center gap-1.5 truncate text-[10.5px] text-muted"><Mail size={11} /> {user.email}</p>
              <p className="mt-1 text-[10px] text-muted/70">{t('memberSince', { date: formatDate(user.joinedAt, lang, { month: 'long', year: 'numeric' }) })}</p>
              <div className="mt-4 rounded-xl border border-brand/20 bg-brand/[0.06] p-3">
                <p className="text-[10px] uppercase tracking-wider text-muted">{t('uniqueId')}</p>
                <div className="mt-1 flex items-center justify-between gap-2">
                  <p className="font-display text-lg font-extrabold grad-text">{user.userCode || '—'}</p>
                  <button type="button" onClick={copyId} className="btn btn-soft btn-sm"><Copy size={13}/> {t('copyId')}</button>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 border-t border-line/[0.07] pt-4 text-center">
                <div><p className="font-display text-lg font-extrabold">{tasks.length}</p><p className="text-[9px] uppercase tracking-wider text-muted">{t('statTasks')}</p></div>
                <div className="border-x border-line/[0.07]"><p className="font-display text-lg font-extrabold">{goals.length}</p><p className="text-[9px] uppercase tracking-wider text-muted">{t('statGoals')}</p></div>
                <div><p className="font-display text-lg font-extrabold">{notes.length}</p><p className="text-[9px] uppercase tracking-wider text-muted">{t('statNotes')}</p></div>
              </div>
            </div>
          </section>
        </div>

        <div className="space-y-4">
          <SettingsCard icon={UserRound} title={t('personalInfo')} hint={t('personalInfoHint')}>
            <div className="mb-4 flex flex-wrap items-center gap-3">
              <Avatar emoji={avatar} size={64} />
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={()=>fileRef.current?.click()} className="btn btn-soft btn-sm"><Upload size={13}/> {t('uploadPhoto')}</button>
                <button type="button" onClick={async ()=>{ try { const res = await api.updateProfile({ avatar: '🦋' }); setAvatar('🦋'); updateUser(res.user as any); await refresh(); toast({ title: t('saved'), tone: 'success' }); } catch(e:any){ toast({ title: e?.message || 'Failed', tone:'error' }); } }} className="btn btn-soft btn-sm"><Trash2 size={13}/> Remove photo</button>
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={onPickPhoto} />
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block"><span className="field-label">{t('firstName')}</span><input className="field" value={firstName} onChange={(e)=>setFirstName(e.target.value)} /></label>
              <label className="block"><span className="field-label">{t('lastName')}</span><input className="field" value={lastName} onChange={(e)=>setLastName(e.target.value)} /></label>
              <label className="block"><span className="field-label">{t('usernameLabel')}</span><input className="field" value={username} onChange={(e)=>setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g,''))} /></label>
              <label className="block"><span className="field-label">{t('emailLabel')}</span><input className="field" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} /></label>
              <label className="block sm:col-span-2"><span className="field-label">{t('bio')}</span><input className="field" value={bio} onChange={(e)=>setBio(e.target.value)} /></label>
              <label className="block sm:col-span-2"><span className="field-label">{t('interests')} <span className="text-muted font-normal">({t('interestsHint')})</span></span><input className="field" value={interests} onChange={(e)=>setInterests(e.target.value)} /></label>
            </div>
            <div className="mt-3">
              <span className="field-label">{t('avatarLabel')}</span>
              <div className="flex flex-wrap gap-2">
                {AVATARS.map((emoji) => (
                  <button key={emoji} type="button" onClick={() => setAvatar(emoji)} className={cn('grid h-10 w-10 place-items-center rounded-xl border text-lg transition', avatar === emoji ? 'border-brand/60 bg-brand/15' : 'border-line/[0.08] bg-line/[0.025] hover:border-brand/30')}>{emoji}</button>
                ))}
              </div>
            </div>
            <div className="mt-4 flex justify-end"><button type="button" disabled={saving} onClick={saveProfile} className="btn btn-primary">{saving?<Loader2 size={14} className="animate-spin"/>:<Save size={14}/>} {t('saveChanges')}</button></div>
          </SettingsCard>

          <SettingsCard icon={Crown} title="Profile Appearance" hint="Select a frame or nickname effect to see a live preview, then click APPLY to save it to your real profile. VIP-only styles are verified server-side.">
            <div className="rounded-2xl border border-line/[0.08] bg-line/[0.02] p-4 mb-4">
              <p className="text-[10px] uppercase tracking-wider text-muted mb-2">Live preview (before apply)</p>
              <div className="flex items-center gap-4 flex-wrap">
                <Avatar emoji={avatar} size={72} frame={profileFrame} glowEffect={glowEffect} borderColor={borderColor} />
                <div>
                  <p className="text-lg font-bold"><DisplayName name={fullName || user.name} isVip={(user as any).isVip} isOwner={(user as any).isOwner} effect={usernameEffect} color={usernameColor} /></p>
                  <p className="text-[11px] text-muted">@{username || user.username} · {user.userCode || ''}</p>
                  <p className="text-[10px] text-muted/70 mt-1">Applied: frame <b>{appliedFrame}</b> · effect <b>{appliedEffect}</b></p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2"><span className="field-label mb-0">Profile frame</span><button type="button" className="btn btn-soft btn-sm" onClick={removeFrame} disabled={savingAppearance}>Remove frame</button></div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {FRAME_STYLES.map((f) => {
                    const vip = VIP_ONLY_FRAMES.has(f as any);
                    const locked = vip && !(user as any).isVip;
                    const selected = profileFrame === f;
                    const applied = appliedFrame === f;
                    const label = ({none:'Default (no frame)','neon-purple':'Neon purple','electric-blue':'Electric blue','golden-vip':'Golden VIP','rainbow-glow':'Rainbow glow','cyber-frame':'Cyber frame','diamond-frame':'Diamond frame','premium-black':'Premium black'} as any)[f] || f;
                    return (
                      <button key={f} type="button" disabled={locked || savingAppearance} onClick={() => setProfileFrame(f)}
                        className={cn('relative rounded-xl border p-2.5 text-left transition', selected ? 'border-brand/60 bg-brand/15' : 'border-line/[0.08] bg-line/[0.02] hover:border-brand/30', locked && 'opacity-50 cursor-not-allowed')}>
                        <div className="flex justify-center mb-2"><Avatar emoji={avatar} size={44} frame={f} glowEffect={glowEffect} borderColor={borderColor} /></div>
                        <div className="text-[10.5px] font-medium leading-tight">{label}</div>
                        <div className="mt-1 flex items-center gap-1 text-[9px] text-muted">{vip ? <span className="text-amber-300">VIP</span> : <span>Free</span>}{applied ? <span className="ml-auto text-emerald-300 font-semibold">Applied</span> : selected ? <span className="ml-auto text-violet-300 font-semibold">Selected</span> : null}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <span className="field-label">Nickname color effects</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {USERNAME_EFFECTS.map((eff) => {
                    const vip = VIP_ONLY_EFFECTS.has(eff as any);
                    const locked = vip && !(user as any).isVip;
                    const selected = usernameEffect === eff;
                    const applied = appliedEffect === eff;
                    const label = ({none:'None', rainbow:'Rainbow animated gradient', 'purple-neon':'Neon purple', 'blue-electric':'Electric blue', 'golden-vip':'Golden VIP', 'red-glow':'Red glow', 'green-glow':'Green glow', static:'Custom static color'} as any)[eff] || eff;
                    return (
                      <button key={eff} type="button" disabled={locked || savingAppearance} onClick={() => setUsernameEffect(eff)}
                        className={cn('relative rounded-xl border p-3 text-left transition', selected ? 'border-brand/60 bg-brand/15' : 'border-line/[0.08] bg-line/[0.02] hover:border-brand/30', locked && 'opacity-50 cursor-not-allowed')}>
                        <div className="text-[13px] font-semibold"><DisplayName name={fullName || user.name || 'Preview'} isVip={false} effect={eff} color={usernameColor} /></div>
                        <div className="mt-1 flex items-center gap-1 text-[10px] text-muted"><span>{label}</span>{vip ? <span className="text-amber-300">VIP</span> : null}{applied ? <span className="ml-auto text-emerald-300 font-semibold">Applied</span> : selected ? <span className="ml-auto text-violet-300 font-semibold">Selected</span> : null}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <label className="block"><span className="field-label">Custom static color</span><input className="field h-10" type="color" value={usernameColor} onChange={(e)=>setUsernameColor(e.target.value)} /></label>
                <label className="block"><span className="field-label">Border color</span><input className="field h-10" type="color" value={borderColor} onChange={(e)=>setBorderColor(e.target.value)} /></label>
              </div>
              <p className="text-[10.5px] text-muted">Choose "Custom static color" effect to use your selected color. Preview updates immediately; click APPLY to save.</p>
            </div>

            <div className="mt-4 flex flex-wrap justify-end gap-2">
              <button type="button" disabled={savingAppearance} onClick={removeFrame} className="btn btn-soft">{savingAppearance?<Loader2 size={14} className="animate-spin"/>:null} Remove frame</button>
              <button type="button" disabled={savingAppearance} onClick={() => applyAppearance()} className="btn btn-primary">{savingAppearance?<Loader2 size={14} className="animate-spin"/>:<Save size={14}/>} APPLY</button>
            </div>
            {(user as any).isVip || (user as any).isOwner ? <p className="mt-3 text-[11px] text-amber-300">VIP/Owner access verified: exclusive frames and effects are available.</p> : <p className="mt-3 text-[11px] text-muted">Some frames/effects are VIP-only. Access is verified on the server.</p>}
          </SettingsCard>

          <div className="grid gap-4 xl:grid-cols-2">
            <SettingsCard icon={Palette} title={t('appearance')} hint={t('appearanceHint')}>
              <div className="grid grid-cols-2 gap-2.5">
                {([{ key: 'dark' as Theme, label: t('dark'), icon: Moon }, { key: 'light' as Theme, label: t('light'), icon: Sun }]).map((theme) => {
                  const active = settings.theme === theme.key; const Icon = theme.icon;
                  return <button key={theme.key} type="button" onClick={() => updateSettings({ theme: theme.key })} className={cn('rounded-2xl border p-3 text-left transition', active ? 'border-brand/50 bg-brand/[0.09]' : 'border-line/[0.08] hover:border-line/20')}><div className="flex items-center gap-1.5"><Icon size={13} /><span className="text-[11.5px] font-semibold">{theme.label}</span>{active ? <Check size={12} className="ml-auto text-brand" /> : null}</div></button>;
                })}
              </div>
              <div className="mt-4 border-t border-line/[0.06] pt-3">
                <div className="flex items-center gap-1.5 text-[11px] font-semibold"><Globe2 size={12} /> {t('languageLabel')}</div>
                <div className="mt-2 grid grid-cols-3 gap-1.5">
                  {([{ key: 'uz' as Lang, label: "O'zbekcha" }, { key: 'ru' as Lang, label: 'Русский' }, { key: 'en' as Lang, label: 'English' }]).map((l) => (
                    <button key={l.key} type="button" onClick={() => updateSettings({ language: l.key })} className={cn('rounded-xl border px-2 py-2 text-[10.5px] font-medium transition', settings.language === l.key ? 'border-brand/50 bg-brand/15 text-ink' : 'border-line/[0.08] text-muted hover:text-ink')}>{l.label}</button>
                  ))}
                </div>
              </div>
            </SettingsCard>

            <SettingsCard icon={BellRing} title={t('notificationSettings')} hint={t('notificationHint')}>
              <div className="space-y-3">
                <ToggleRow label={t('notifTasks')} hint={t('notifTasksHint')} checked={settings.notifications} onChange={(v) => updateSettings({ notifications: v })} />
                <ToggleRow label={t('notifSummary')} hint={t('notifSummaryHint')} checked={settings.dailySummary} onChange={(v) => updateSettings({ dailySummary: v })} />
                <ToggleRow label={t('notifSound')} hint={t('notifSoundHint')} checked={settings.sound} onChange={(v) => updateSettings({ sound: v })} />
              </div>
            </SettingsCard>
          </div>

          <SettingsCard icon={Sparkles} title={t('aiIntegration')} hint={t('aiIntegrationHint')}>
            <div className="flex flex-wrap items-center gap-2">
              <span className={cn('chip', connected ? 'chip-success' : 'chip-brand')}>{connected ? t('aiStatusConnected') : t('aiStatusDisconnected')}</span>
              {connected ? <button type="button" onClick={disconnectAi} className="btn btn-danger btn-sm"><Unlink size={12} /> {t('disconnectAi')}</button> : null}
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="field-label" htmlFor="ai-key">{t('apiKey')}</label>
                <div className="relative">
                  <KeyRound size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
                  <input id="ai-key" type={showKey ? 'text' : 'password'} value={aiKey} onChange={(e) => setAiKey(e.target.value)} placeholder={t('apiKeyPlaceholder')} className="field pl-9 pr-10 font-mono text-[12px]" autoComplete="off" />
                  <button type="button" onClick={() => setShowKey((v) => !v)} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1 text-muted hover:text-ink">{showKey ? <EyeOff size={14} /> : <Eye size={14} />}</button>
                </div>
              </div>
              <div><label className="field-label" htmlFor="ai-base">{t('apiBase')}</label><div className="relative"><Link2 size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input id="ai-base" value={aiBase} onChange={(e) => setAiBase(e.target.value)} placeholder="https://api.openai.com/v1" className="field pl-9 text-[12px]" /></div></div>
              <div><label className="field-label" htmlFor="ai-model">{t('apiModel')}</label><input id="ai-model" value={aiModel} onChange={(e) => setAiModel(e.target.value)} placeholder="gpt-4o-mini" className="field text-[12px]" /></div>
            </div>
            <p className="mt-3 flex items-start gap-1.5 text-[9.5px] leading-relaxed text-muted"><ShieldAlert size={12} className="mt-0.5 shrink-0 text-amber-300" /> {t('aiKeyPrivacy')}</p>
            <div className="mt-3 flex justify-end"><button type="button" onClick={saveAi} className="btn btn-primary btn-sm"><Save size={13} /> {t('saveAi')}</button></div>
          </SettingsCard>

          <SettingsCard icon={KeyRound} title={t('accountSecurity')} hint={user.authProvider === 'google' ? t('googleSignInDesc') : t('profileSubtitle')}>
            {user.authProvider === 'google' ? <p className="text-[12px] text-muted">{t('googleSignInDesc')}</p> : (
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="block sm:col-span-2"><span className="field-label">{t('currentPassword')}</span><input className="field" type="password" value={currentPassword} onChange={(e)=>setCurrentPassword(e.target.value)} autoComplete="current-password" /></label>
                <label className="block"><span className="field-label">{t('newPassword')}</span><input className="field" type="password" value={newPassword} onChange={(e)=>setNewPassword(e.target.value)} autoComplete="new-password" /></label>
                <label className="block"><span className="field-label">{t('confirmNewPassword')}</span><input className="field" type="password" value={confirmNew} onChange={(e)=>setConfirmNew(e.target.value)} autoComplete="new-password" /></label>
                <div className="sm:col-span-2 flex justify-end"><button type="button" disabled={pwBusy} onClick={savePassword} className="btn btn-soft">{pwBusy?<Loader2 size={14} className="animate-spin"/>:<Save size={14}/>} {t('updatePassword')}</button></div>
              </div>
            )}
          </SettingsCard>

          <section className="card border-rose-400/20 p-4 sm:p-5">
            <div className="flex items-start gap-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-rose-500/12 text-rose-400"><ShieldAlert size={17} /></span>
              <div className="flex-1">
                <h3 className="font-display text-[13px] font-bold">{t('dangerZone')}</h3>
                <p className="mt-1 text-[10.5px] leading-relaxed text-muted">{t('deleteAccountDesc')}</p>
                <button type="button" onClick={()=>setConfirmDelete(true)} className="btn btn-danger btn-sm mt-3"><Trash2 size={13}/> {t('deleteAccount')}</button>
              </div>
            </div>
          </section>
        </div>
      </div>

      {confirmDelete ? (
        <div className="crop-modal" role="dialog" aria-modal="true">
          <div className="crop-card">
            <h3 className="font-display text-[15px] font-bold text-rose-300">{t('deleteAccount')}</h3>
            <p className="mt-2 text-[12px] text-muted leading-relaxed">{t('deleteAccountConfirm')} {t('deleteAccountDesc')}</p>
            <label className="mt-3 block"><span className="field-label">{t('deleteAccountType')}</span><input className="field" value={deleteText} onChange={(e)=>setDeleteText(e.target.value.toUpperCase())} placeholder="DELETE" /></label>
            {user.authProvider === 'local' ? <label className="mt-2 block"><span className="field-label">{t('passwordLabel')}</span><input className="field" type="password" value={deletePass} onChange={(e)=>setDeletePass(e.target.value)} /></label> : null}
            <div className="mt-4 flex justify-end gap-2">
              <button type="button" className="btn btn-soft" onClick={()=>setConfirmDelete(false)}>{t('cancel')}</button>
              <button type="button" className="btn btn-danger" disabled={deleteBusy || deleteText !== 'DELETE'} onClick={doDeleteAccount}>{deleteBusy?<Loader2 size={14} className="animate-spin"/>:<Trash2 size={14}/>} {t('deleteAccount')}</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function SettingsCard({ icon: Icon, title, hint, children }: { icon: LucideIcon; title: string; hint: string; children: ReactNode }) {
  return (
    <section className="card p-4 sm:p-5">
      <div className="mb-4 flex items-start gap-2.5">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-brand/12 text-violet-300"><Icon size={15} /></span>
        <div><h2 className="font-display text-[13.5px] font-bold leading-tight">{title}</h2><p className="mt-0.5 text-[10px] leading-relaxed text-muted">{hint}</p></div>
      </div>
      {children}
    </section>
  );
}

function ToggleRow({ label, hint, checked, onChange }: { label: string; hint: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <div><p className="text-[11.5px] font-medium">{label}</p><p className="mt-0.5 text-[9.5px] leading-relaxed text-muted">{hint}</p></div>
      <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={cn('relative h-6 w-11 shrink-0 rounded-full border transition-all duration-300', checked ? 'border-transparent bg-gradient-to-r from-violet-500 to-indigo-500' : 'border-line/[0.12] bg-line/[0.08]')}>
        <span className={cn('absolute top-[3px] h-4 w-4 rounded-full bg-white shadow transition-all duration-300', checked ? 'left-[23px]' : 'left-[3px]')} />
      </button>
    </div>
  );
}
