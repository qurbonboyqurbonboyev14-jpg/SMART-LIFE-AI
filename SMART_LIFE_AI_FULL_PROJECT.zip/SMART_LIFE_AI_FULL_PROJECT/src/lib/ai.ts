import type { AppData, Lang } from './types';
import {
  activeCategoryCounts,
  averageGoalProgress,
  calculateStreak,
  dailyProgress,
  eventsForDay,
  upcomingEvents,
  weekCompleted,
  weekSeries,
} from './analytics';
import { addDaysISO, formatDate, formatLongDate, todayISO } from './date';

type Intent = 'day' | 'week' | 'goals' | 'advice' | 'stats' | 'greet' | 'motivate' | 'general';

const content = {
  uz: {
    dayTitle: 'Bugungi shaxsiy reja',
    weekTitle: 'Haftalik strategiya',
    goalsTitle: 'Maqsadlaringiz holati',
    statsTitle: 'Natijalar tahlili',
    adviceTitle: 'Vaqtni boshqarish bo\'yicha 5 ta maslahat',
    plan: 'Kunlik fokus',
    upcoming: 'Muhim uchrashuvlar',
    tasks: 'Vazifalar',
    progress: 'Jarayon',
    avgGoal: "O'rtacha jarayon",
    tip: 'Kun oxirida 5 daqiqa ajratib, bugungi natijani yozib qo\'ying — bu ertangi rejani ancha osonlashtiradi.',
    motivation: 'Siz bugun allaqachon {done} ta vazifani bajardingiz. Kichik qadamlar katta natijaga aylanadi — davom eting!',
    advice: [
      '**1. Vaqt bloklari.** Ertalab eng qiyin vazifaga 90 daqiqa ajrating va telefonni uzoqroqqa qo\'ying.',
      '**2. 2 daqiqa qoidasi.** Agar ish 2 daqiqadan kam vaqt olsa — darhol bajaring, ro\'yxatga qo\'shmang.',
      '**3. Uchta asosiy vazifa.** Har kuni faqat 3 ta muhim ishni tanlang. Qolganlari ixtiyoriy.',
      '**4. Pomodoro.** 25 daqiqa ish + 5 daqiqa tanaffus. 4 tsikldan keyin 20 daqiqa dam oling.',
      '**5. Energiya jadvali.** Diqqat cho\'qqisini kuzatib boring: og\'ir ishlarni eng kuchli vaqtga qo\'ying.',
    ],
    general: 'Mana bir nechta amaliy yo\'nalish. Aniqroq yordam uchun "bugungi rejamni tuz", "haftalik reja" yoki "maqsadlarim" deb yozing.',
    noTasks: 'Bugun uchun vazifa qo\'shilmagan. Eng muhim 1 ta ishni tanlang va uni birinchi bo\'lib bajaring.',
    noGoals: 'Hali maqsad qo\'shmagansiz. "Maqsadlar" bo\'limida 1 ta aniq natijani belgilang.',
    overdue: 'muddati o\'tgan',
    left: 'qoldi',
    doneWord: 'bajarildi',
    weekFocus: 'Hafta fokusi',
    upcomingWeek: 'Kelgusi 7 kun',
    goalsIntro: 'Bugungi holat: o\'rtacha jarayon {avg}%. Faol maqsadlar soni — {count}.',
    statsIntro: 'Bugun {todayDone}/{todayTotal} vazifa bajarildi, haftada jami {week} ta. Ketma-ketlik: {streak} kun.',
    bestCat: 'Eng faol kategoriya — {cat}.',
    greeting: 'Salom! Tanishganimizdan xursandman. Men reja tuzish, vaqtni boshqarish va maqsadlarni kuzatishda yordam beraman.',
    closing: 'Yana savolingiz bo\'lsa, yozing — birga hal qilamiz.',
    planIntro: 'Bugun uchun tayyor reja. Eng muhim ishlarni ertalabga qo\'ydim:',
    weeklyIntro: 'Kelgusi 7 kun uchun reja. Har kunga 1-2 ta asosiy fokus:',
    emptyDay: 'bo\'sh kun',
    andMore: 'yana {n} ta',
  },
  ru: {
    dayTitle: 'Личный план на сегодня',
    weekTitle: 'Стратегия недели',
    goalsTitle: 'Состояние ваших целей',
    statsTitle: 'Анализ результатов',
    adviceTitle: '5 советов по управлению временем',
    plan: 'Фокус дня',
    upcoming: 'Важные встречи',
    tasks: 'Задачи',
    progress: 'Прогресс',
    avgGoal: 'Средний прогресс',
    tip: 'В конце дня уделите 5 минут записи результатов — это сильно упростит план на завтра.',
    motivation: 'Сегодня вы уже выполнили {done} задач. Маленькие шаги складываются в большой результат — продолжайте!',
    advice: [
      '**1. Блоки времени.** Утром выделите 90 минут на самую сложную задачу и уберите телефон подальше.',
      '**2. Правило 2 минут.** Если дело занимает меньше 2 минут — сделайте сразу, не добавляйте в список.',
      '**3. Три главных задачи.** Каждый день выбирайте только 3 важных дела. Остальное — опционально.',
      '**4. Помодоро.** 25 минут работы + 5 минут отдыха. После 4 циклов — 20 минут отдыха.',
      '**5. График энергии.** Отслеживайте пики внимания: тяжёлую работу ставьте на самое сильное время.',
    ],
    general: 'Вот несколько практических направлений. Для точной помощи напишите «план на сегодня», «план на неделю» или «мои цели».',
    noTasks: 'На сегодня задач нет. Выберите одно главное дело и сделайте его первым.',
    noGoals: 'Вы ещё не добавили цели. В разделе «Цели» задайте один конкретный результат.',
    overdue: 'просрочено',
    left: 'осталось',
    doneWord: 'выполнено',
    weekFocus: 'Фокус недели',
    upcomingWeek: 'Следующие 7 дней',
    goalsIntro: 'Текущий статус: средний прогресс {avg}%. Активных целей — {count}.',
    statsIntro: 'Сегодня выполнено {todayDone}/{todayTotal}, за неделю — {week}. Серия: {streak} дн.',
    bestCat: 'Самая активная категория — {cat}.',
    greeting: 'Привет! Рад знакомству. Я помогаю планировать, управлять временем и следить за целями.',
    closing: 'Если остались вопросы — напишите, решим вместе.',
    planIntro: 'Готовый план на сегодня. Самые важные дела я поставил на утро:',
    weeklyIntro: 'План на ближайшие 7 дней. По 1–2 главных фокуса на день:',
    emptyDay: 'свободный день',
    andMore: 'ещё {n}',
  },
  en: {
    dayTitle: 'Your plan for today',
    weekTitle: 'Your weekly strategy',
    goalsTitle: 'Goal status',
    statsTitle: 'Your results in numbers',
    adviceTitle: '5 time-management tips',
    plan: 'Focus of the day',
    upcoming: 'Important meetings',
    tasks: 'Tasks',
    progress: 'Progress',
    avgGoal: 'Average progress',
    tip: 'Spend 5 minutes at the end of the day writing down what you achieved — tomorrow’s plan becomes much easier.',
    motivation: 'You already completed {done} tasks today. Small steps add up to big results — keep going!',
    advice: [
      '**1. Time blocks.** Give your hardest task 90 minutes each morning and keep your phone out of reach.',
      '**2. The 2-minute rule.** If something takes under two minutes, do it now instead of adding it to a list.',
      '**3. Three priorities.** Pick only three important tasks per day. The rest is optional.',
      '**4. Pomodoro.** 25 minutes of focus + a 5-minute break. After four cycles, rest for 20 minutes.',
      '**5. Energy mapping.** Track your attention peaks and schedule deep work at your strongest hours.',
    ],
    general: 'Here are a few practical directions. For precise help, write “plan my day”, “weekly plan” or “my goals”.',
    noTasks: 'No tasks for today. Choose the single most important thing and do it first.',
    noGoals: 'You haven’t added any goals yet. In the Goals section, define one concrete outcome.',
    overdue: 'overdue',
    left: 'left',
    doneWord: 'done',
    weekFocus: 'Focus of the week',
    upcomingWeek: 'Next 7 days',
    goalsIntro: 'Current status: average progress {avg}%. Active goals: {count}.',
    statsIntro: 'Today you completed {todayDone}/{todayTotal}, this week {week}. Streak: {streak} days.',
    bestCat: 'Your most active category is {cat}.',
    greeting: 'Hi! Great to meet you. I help with planning, time management and keeping your goals on track.',
    closing: 'If you have another question, just write — we’ll solve it together.',
    planIntro: 'Here’s your plan for today. I put the most important work in the morning:',
    weeklyIntro: 'A plan for the next 7 days, with 1–2 core focuses per day:',
    emptyDay: 'a free day',
    andMore: '{n} more',
  },
} as const;

const detectIntent = (text: string): Intent => {
  const q = text.toLowerCase();
  const has = (words: string[]) => words.some((w) => q.includes(w));

  if (has(['hafta', 'week', 'недел', '7 kun', '7 day'])) return 'week';
  if (has(['maqsad', 'goal', 'цел', 'target'])) return 'goals';
  if (has(['statist', 'natija', 'analiz', 'progress', 'прогресс', 'result'])) return 'stats';
  if (has(['vaqt', 'time', 'врем', 'maslahat', 'advice', 'совет', 'tip', 'fokus'])) return 'advice';
  if (has(['reja', 'plan', 'план', 'kun', 'day', 'bugun', 'today'])) return 'day';
  if (has(['salom', 'hello', 'hi ', 'привет', 'qalay'])) return 'greet';
  if (has(['motiv', 'ruhlant', 'inspir', 'мотив'])) return 'motivate';
  return 'general';
};

const fmtTask = (title: string, meta: string) => `- **${title}** · ${meta}`;

export function simulatedReply(prompt: string, lang: Lang, data: AppData): string {
  const L = content[lang] ?? content.uz;
  const intent = detectIntent(prompt);
  const today = todayISO();
  const progress = dailyProgress(data.tasks);
  const active = data.tasks.filter((t) => !t.completed);
  const urgent = [...active].sort((a, b) => {
    const p = { high: 0, medium: 1, low: 2 };
    return p[a.priority] - p[b.priority] || a.due.localeCompare(b.due);
  });
  const todayEvents = eventsForDay(data.events, today);
  const nextEvents = upcomingEvents(data.events, 3);
  const dish = activeCategoryCounts(data.tasks).sort((a, b) => b.value - a.value)[0];
  const catLabel = dish
    ? ({ study: lang === 'uz' ? "O'qish" : lang === 'ru' ? 'Учёба' : 'Study', work: lang === 'uz' ? 'Ish' : lang === 'ru' ? 'Работа' : 'Work', personal: lang === 'uz' ? 'Shaxsiy' : lang === 'ru' ? 'Личное' : 'Personal', other: lang === 'uz' ? 'Boshqa' : lang === 'ru' ? 'Другое' : 'Other' } as Record<string, string>)[dish.key]
    : '-';

  const header = (title: string) => `### ${title}\n`;

  if (intent === 'greet') {
    return `${header(L.greeting)}\n${lang === 'uz' ? `Bugun sizda **${progress.total} ta vazifa** va **${todayEvents.length} ta tadbir** bor.` : lang === 'ru' ? `Сегодня у вас **${progress.total} задач** и **${todayEvents.length} событий**.` : `You have **${progress.total} tasks** and **${todayEvents.length} events** today.`}\n\n${L.general}`;
  }

  if (intent === 'motivate') {
    return `${header(lang === 'uz' ? 'Motivatsiya zaryadi ⚡' : lang === 'ru' ? 'Заряд мотивации ⚡' : 'A boost of motivation ⚡')}\n${L.motivation.replace('{done}', String(progress.done))}\n\n${L.closing}`;
  }

  if (intent === 'advice') {
    return `${header(L.adviceTitle)}\n${L.advice.join('\n\n')}\n\n> ${L.tip}`;
  }

  if (intent === 'stats') {
    const week = weekCompleted(data.tasks);
    const streak = calculateStreak(data.tasks);
    const avg = averageGoalProgress(data.goals);
    return `${header(L.statsTitle)}\n${L.statsIntro
      .replace('{todayDone}', String(progress.done))
      .replace('{todayTotal}', String(progress.total))
      .replace('{week}', String(week))
      .replace('{streak}', String(streak))}\n\n- ${L.avgGoal}: **${avg}%**\n- ${L.bestCat.replace('{cat}', catLabel)}\n\n${L.closing}`;
  }

  if (intent === 'goals') {
    if (!data.goals.length) return `${header(L.goalsTitle)}\n${L.noGoals}`;
    const avg = averageGoalProgress(data.goals);
    const lines = data.goals
      .slice(0, 6)
      .map((g) => {
        const barDone = Math.round(g.progress / 10);
        const bar = '█'.repeat(barDone) + '░'.repeat(10 - barDone);
        return `- **${g.title}**\n  \`${bar}\` ${g.progress}%${g.completed ? ' ✓' : ''}`;
      })
      .join('\n');
    return `${header(L.goalsTitle)}\n${L.goalsIntro.replace('{avg}', String(avg)).replace('{count}', String(data.goals.filter((g) => !g.completed).length))}\n\n${lines}\n\n> ${L.tip}`;
  }

  if (intent === 'week') {
    const days: string[] = [];
    for (let i = 0; i < 7; i++) {
      const iso = addDaysISO(today, i);
      const dayTasks = active.filter((t) => t.due === iso);
      const dayEvents = eventsForDay(data.events, iso);
      const heading = `**${formatDate(iso, lang, { weekday: 'long', day: 'numeric', month: 'short' })}**`;
      const taskLines = dayTasks.length
        ? dayTasks.slice(0, 3).map((t) => fmtTask(t.title, `${L.tasks.toLowerCase()} · ${t.priority}`)).join('\n')
        : `- ${L.emptyDay}`;
      const eventLines = dayEvents.length
        ? `\n  ${L.upcoming}: ${dayEvents.map((e) => `${e.start} ${e.title}`).join(', ')}`
        : '';
      days.push(`${heading}\n${taskLines}${eventLines}`);
    }
    return `${header(L.weekTitle)}\n${L.weeklyIntro}\n\n${days.join('\n\n')}\n\n> ${L.tip}`;
  }

  if (intent === 'day') {
    const todays = [...data.tasks.filter((t) => t.due === today)].sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      const p = { high: 0, medium: 1, low: 2 };
      return p[a.priority] - p[b.priority];
    });
    if (!todays.length) return `${header(L.dayTitle)}\n${L.noTasks}`;

    const blocks: string[] = [];
    let startMinutes = 9 * 60;
    todays
      .filter((t) => !t.completed)
      .slice(0, 4)
      .forEach((t) => {
        const end = startMinutes + 60;
        const time = `${String(Math.floor(startMinutes / 60)).padStart(2, '0')}:00–${String(Math.floor(end / 60)).padStart(2, '0')}:${String(end % 60).padStart(2, '0')}`;
        blocks.push(`**${time}** — ${t.title}  \n  \`${t.category}\` · \`${t.priority}\``);
        startMinutes = end + 15;
      });

    const eventLines = todayEvents.length
      ? `\n\n#### ${L.upcoming}\n${todayEvents.map((e) => `- **${e.start}–${e.end}** — ${e.title}`).join('\n')}`
      : '';
    const overdue = active.filter((t) => t.due < today);
    const overdueLine = overdue.length
      ? `\n\n⚠️ **${overdue.length}** ${L.overdue}: ${overdue.map((t) => t.title).join(', ')}`
      : '';
    return `${header(L.dayTitle)}\n${formatLongDate(new Date(), lang)}\n\n${L.planIntro}\n\n${blocks.join('\n\n')}${eventLines}${overdueLine}\n\n#### ${L.progress}\n\`${'█'.repeat(Math.round(progress.percent / 10))}${'░'.repeat(10 - Math.round(progress.percent / 10))}\` ${progress.done}/${progress.total} ${L.doneWord}\n\n> ${L.tip}`;
  }

  // general — still grounded in the user's data
  const lines = urgent.slice(0, 3).map((t) => fmtTask(t.title, `${formatDate(t.due, lang, { day: 'numeric', month: 'short' })} · ${t.priority}`));
  return `${header(lang === 'uz' ? 'Sizga qanday yordam bera olaman?' : lang === 'ru' ? 'Чем я могу помочь?' : 'How can I help?')}\n${L.general}\n\n${lines.length ? `**${L.tasks}:**\n${lines.join('\n')}\n\n` : ''}${nextEvents.length ? `**${L.upcoming}:** ${nextEvents[0].title} — ${nextEvents[0].start}\n\n` : ''}> ${L.tip}`;
}

const languageName: Record<Lang, string> = {
  uz: "Uzbek (Latin script)",
  ru: 'Russian',
  en: 'English',
};

const systemPrompt = (lang: Lang, data: AppData) => `You are SMART LIFE AI, a premium personal productivity assistant inside a dashboard.
Always answer in ${languageName[lang]}.
Be warm, concise and practical. Use markdown: "###" for section titles, "-" for bullets, **bold** for key ideas.
Reference the user's real data below (do not invent tasks or events). If a plan is requested, build a realistic time-blocked plan.
Keep answers under 320 words.

USER CONTEXT (JSON):
${JSON.stringify({
  name: data.user.name,
  today: todayISO(),
  tasks: data.tasks.filter((t) => !t.completed).slice(0, 18).map((t) => ({ title: t.title, due: t.due, priority: t.priority, category: t.category })),
  events: data.events.filter((e) => e.date >= todayISO()).slice(0, 10).map((e) => ({ title: e.title, date: e.date, start: e.start, end: e.end })),
  goals: data.goals.map((g) => ({ title: g.title, progress: g.progress, target: g.targetDate, done: g.completed })),
  stats: { todayDone: dailyProgress(data.tasks).done, weekDone: weekCompleted(data.tasks), streak: calculateStreak(data.tasks) },
})}`;

export async function requestAssistant(
  prompt: string,
  data: AppData,
): Promise<{ text: string; simulated: boolean; failed?: boolean }> {
  const { settings } = data;
  const fallback = () => simulatedReply(prompt, settings.language, data);

  if (!settings.aiKey.trim() || !settings.aiBase.trim()) {
    await new Promise((r) => setTimeout(r, 650 + Math.random() * 500));
    return { text: fallback(), simulated: true };
  }

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 25000);

  try {
    const base = settings.aiBase.trim().replace(/\/+$/, '');
    const history = data.messages.slice(-9);
    // The current prompt is added explicitly below; avoid sending it twice.
    if (history[history.length - 1]?.role === 'user') history.pop();

    const res = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${settings.aiKey.trim()}`,
      },
      body: JSON.stringify({
        model: settings.aiModel.trim() || 'gpt-4o-mini',
        temperature: 0.6,
        max_tokens: 900,
        messages: [
          { role: 'system', content: systemPrompt(settings.language, data) },
          ...history.map((m) => ({ role: m.role, content: m.text })),
          { role: 'user', content: prompt },
        ],
      }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    const text = json?.choices?.[0]?.message?.content;
    if (typeof text !== 'string' || !text.trim()) throw new Error('Empty response');
    return { text: text.trim(), simulated: false };
  } catch {
    return { text: fallback(), simulated: true, failed: true };
  } finally {
    window.clearTimeout(timeout);
  }
}
