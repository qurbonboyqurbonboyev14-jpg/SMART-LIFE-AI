import { useEffect, useState } from 'react';
import { Activity, Crown, LogOut, Search, Shield, Sparkles } from 'lucide-react';
import { api, type AdminActivity, type AdminStats, type AdminUser } from '../lib/api';
import { useT } from '../lib/i18n';
import { useToast } from '../components/Toast';
import { Avatar, DisplayName, FRAME_STYLES, PageHeader, USERNAME_EFFECTS, VipBadge } from '../components/ui';

export default function AdminPage() {
  const { t } = useT();
  const toast = useToast();
  const [authed, setAuthed] = useState(false);
  const [checking, setChecking] = useState(true);
  const [key, setKey] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [activity, setActivity] = useState<AdminActivity[]>([]);
  const [vips, setVips] = useState<any[]>([]);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [busyId, setBusyId] = useState('');
  const [vipQuery, setVipQuery] = useState('');
  const [vipFrame, setVipFrame] = useState('golden-vip');
  const [vipEffect, setVipEffect] = useState('golden-vip');
  const [vipBusy, setVipBusy] = useState(false);

  const load = async (q = query, st = status) => {
    try {
      const [s, u, a, v] = await Promise.all([api.adminStats(), api.adminUsers(q, st, 1), api.adminActivity(), api.adminVips().catch(() => ({ vips: [] }))]);
      setStats(s); setUsers(u.users); setActivity(a.activity); setVips(v.vips || []);
    } catch (e: any) {
      if (e?.status === 401) setAuthed(false);
    }
  };

  useEffect(() => {
    (async () => {
      try { await api.adminMe(); setAuthed(true); await load('', 'all'); } catch { setAuthed(false); }
      finally { setChecking(false); }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async (e: React.FormEvent) => {
    e.preventDefault(); setError('');
    try { await api.adminLogin(key, password); setAuthed(true); setKey(''); setPassword(''); await load('', 'all'); }
    catch (err: any) { setError(err?.message || 'Login failed'); }
  };

  const logout = async () => { await api.adminLogout().catch(()=>undefined); setAuthed(false); setStats(null); setUsers([]); setActivity([]); setVips([]); };

  const toggleStatus = async (u: AdminUser) => {
    const next = u.status === 'active' ? 'suspended' : 'active';
    setBusyId(u.id);
    try { await api.adminUpdateUser(u.id, next as 'active'|'suspended'); toast({ title: `${u.username}: ${next}`, tone: 'success' }); await load(); }
    catch (e: any) { toast({ title: e?.message || 'Failed', tone: 'error' }); }
    finally { setBusyId(''); }
  };

  const setVip = async (target: { userId?: string; email?: string; code?: string }, isVip: boolean, frame?: string, effect?: string) => {
    setVipBusy(true);
    try {
      await api.adminSetVip({ ...target, isVip, profileFrame: frame, usernameEffect: effect });
      toast({ title: isVip ? 'VIP granted' : 'VIP removed', tone: 'success' });
      await load();
    } catch (e: any) { toast({ title: e?.message || 'VIP update failed', tone: 'error' }); }
    finally { setVipBusy(false); }
  };

  const resolveVipTarget = () => {
    const q = vipQuery.trim();
    if (!q) return null;
    if (q.includes('@')) return { email: q.toLowerCase() };
    if (/^SL-/i.test(q)) return { code: q.toUpperCase() };
    return { email: q };
  };

  if (checking) return <div className="py-16 text-center text-muted">{t('loading')}</div>;

  if (!authed) {
    return (
      <div className="mx-auto max-w-md py-10">
        <div className="card card-pad">
          <div className="mb-4 flex items-center gap-2"><Shield size={18} className="text-brand"/><h1 className="font-display text-xl font-bold">{t('adminLoginTitle')}</h1></div>
          <p className="mb-4 text-[12px] text-muted">{t('adminLoginHint')}</p>
          {error ? <div className="mb-3 rounded-xl border border-rose-400/25 bg-rose-500/10 px-3 py-2 text-[12px] text-rose-300">{error}</div> : null}
          <form className="space-y-3" onSubmit={login}>
            <label className="block"><span className="field-label">{t('adminKey')}</span><input className="field" value={key} onChange={(e)=>setKey(e.target.value)} type="password" autoComplete="off" required /></label>
            <label className="block"><span className="field-label">{t('adminPassword')}</span><input className="field" value={password} onChange={(e)=>setPassword(e.target.value)} type="password" autoComplete="current-password" required /></label>
            <button type="submit" className="btn btn-primary w-full"><Shield size={14}/> {t('adminSignIn')}</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader eyebrow="OWNER" title={t('adminTitle')} subtitle={t('adminSubtitle')}
        actions={<button type="button" onClick={logout} className="btn btn-soft"><LogOut size={14}/> {t('adminSignOut')}</button>} />

      {stats ? (
        <div className="mb-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 xl:grid-cols-6">
          {[
            { label: t('adminUsers'), value: stats.totalUsers },
            { label: t('adminActive'), value: stats.activeUsers },
            { label: t('adminSuspended'), value: stats.suspendedUsers },
            { label: t('adminNew7d'), value: stats.newUsers7d },
            { label: t('adminSessions'), value: stats.activeSessions },
            { label: 'VIPs', value: vips.length },
          ].map((c) => (
            <div key={c.label} className="card px-3.5 py-3"><p className="text-[9.5px] uppercase tracking-wider text-muted">{c.label}</p><p className="mt-1 font-display text-xl font-extrabold">{c.value}</p></div>
          ))}
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-4">
          <section className="card card-pad">
            <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center">
              <div className="relative flex-1"><Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted"/><input className="field pl-9" value={query} onChange={(e)=>setQuery(e.target.value)} placeholder={t('adminSearchPlaceholder')} onKeyDown={(e)=>{ if(e.key==='Enter') void load(); }} /></div>
              <select className="field w-auto min-w-[120px]" value={status} onChange={(e)=>{ setStatus(e.target.value); void load(query, e.target.value); }}>
                <option value="all">{t('all')}</option><option value="active">{t('adminActive')}</option><option value="suspended">{t('adminSuspended')}</option>
              </select>
              <button type="button" className="btn btn-soft" onClick={()=>void load()}>{t('search')}</button>
            </div>
            <div className="space-y-2">
              {users.length === 0 ? <p className="py-6 text-center text-[12px] text-muted">{t('noResultsTitle')}</p> : users.map((u) => (
                <div key={u.id} className="rounded-2xl border border-line/[0.07] bg-line/[0.02] p-3">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-semibold"><DisplayName name={u.name} isVip={u.isVip} isOwner={(u as any).isOwner} effect={(u as any).selectedNicknameEffect || u.usernameEffect} color={(u as any).selectedNicknameColor || u.usernameColor} /> <span className="text-muted font-normal">@{u.username}</span></p>
                      <p className="text-[11px] text-muted">{u.email} · <span className="font-semibold text-violet-300">{u.userCode}</span></p>
                      <p className="mt-0.5 text-[10px] text-muted">Tasks {u.counts.tasks} · Goals {u.counts.goals} · Notes {u.counts.notes} · {u.authProvider || 'local'}</p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 justify-end">
                      {u.isVip ? <VipBadge /> : null}
                      <span className={`chip ${u.status==='active'?'chip-success':'chip-danger'}`}>{u.status}</span>
                      <button type="button" disabled={busyId===u.id} onClick={()=>void toggleStatus(u)} className={`btn btn-sm ${u.status==='active'?'btn-danger':'btn-primary'}`}>{u.status==='active'?t('adminSuspend'):t('adminActivate')}</button>
                      {u.isVip ? <button type="button" disabled={vipBusy} onClick={()=>void setVip({ userId: u.id }, false)} className="btn btn-sm btn-soft">Remove VIP</button> : <button type="button" disabled={vipBusy} onClick={()=>void setVip({ userId: u.id }, true, 'golden-vip', 'golden-vip')} className="btn btn-sm btn-primary"><Crown size={12}/> Grant VIP</button>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="card card-pad">
            <div className="mb-3 flex items-center gap-2"><Crown size={15} className="text-amber-300"/><h2 className="font-display text-[14px] font-bold">VIP Membership Management</h2></div>
            <p className="mb-3 text-[11px] text-muted">VIP is server-verified. Grant/remove by email or unique ID, assign exclusive frames/effects. Designated VIP account remains permanently VIP.</p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              <label className="block sm:col-span-2"><span className="field-label">Email or SL ID</span><input className="field" value={vipQuery} onChange={(e)=>setVipQuery(e.target.value)} placeholder="qurbonboyqurbonboyev14@gmail.com or SL-123456" /></label>
              <label className="block"><span className="field-label">Assign frame</span><select className="field" value={vipFrame} onChange={(e)=>setVipFrame(e.target.value)}>{FRAME_STYLES.map((f)=><option key={f} value={f}>{f}</option>)}</select></label>
              <label className="block"><span className="field-label">Assign username effect</span><select className="field" value={vipEffect} onChange={(e)=>setVipEffect(e.target.value)}>{USERNAME_EFFECTS.map((f)=><option key={f} value={f}>{f}</option>)}</select></label>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" disabled={vipBusy || !vipQuery.trim()} className="btn btn-primary" onClick={()=>{ const t=resolveVipTarget(); if(t) void setVip(t,true,vipFrame,vipEffect); }}><Crown size={14}/> Grant / Update VIP</button>
              <button type="button" disabled={vipBusy || !vipQuery.trim()} className="btn btn-soft" onClick={()=>{ const t=resolveVipTarget(); if(t) void setVip(t,false,'none','none'); }}>Remove VIP</button>
            </div>
            <div className="mt-4 border-t border-line/[0.07] pt-3">
              <p className="text-[11px] font-semibold mb-2">All VIP users</p>
              <div className="space-y-2 max-h-64 overflow-y-auto scroll-thin pr-1">
                {vips.length === 0 ? <p className="text-[12px] text-muted">No VIP users.</p> : vips.map((v) => (
                  <div key={v.id} className="flex items-center gap-2.5 rounded-xl border border-line/[0.06] p-2.5">
                    <Avatar emoji={v.avatar || '🦋'} size={36} frame={v.profileFrame} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-semibold"><DisplayName name={v.name} isVip isOwner={(v as any).isOwner} effect={(v as any).selectedNicknameEffect || v.usernameEffect} color={(v as any).selectedNicknameColor || v.usernameColor} /> {v.vipPermanent ? <span className="ml-1 text-[9px] text-amber-300">(permanent)</span> : null}</p>
                      <p className="truncate text-[10px] text-muted">{v.email} · {v.userCode}</p>
                    </div>
                    <button type="button" disabled={vipBusy || v.vipPermanent} onClick={()=>void setVip({ userId: v.id }, false)} className="btn btn-sm btn-soft" title={v.vipPermanent ? 'Permanent VIP cannot be removed' : 'Remove VIP'}>Remove</button>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </div>

        <section className="card card-pad">
          <div className="mb-3 flex items-center gap-2"><Activity size={15} className="text-brand"/><h2 className="font-display text-[14px] font-bold">{t('adminActivity')}</h2></div>
          <div className="space-y-1.5 max-h-[520px] overflow-y-auto scroll-thin pr-1">
            {activity.length === 0 ? <p className="text-[12px] text-muted">—</p> : activity.map((a) => (
              <div key={a.id} className="rounded-xl border border-line/[0.05] px-2.5 py-2">
                <p className="text-[11px] font-medium"><span className="text-violet-300">{a.action}</span>{a.userCode ? <span className="text-muted"> · {a.userCode}</span> : null}</p>
                <p className="truncate text-[10px] text-muted">{a.name || a.username || 'system'}{a.detail ? ` — ${a.detail}` : ''}</p>
                <p className="text-[9.5px] text-muted/60">{new Date(a.createdAt).toLocaleString()}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
